﻿﻿<?php
function feedback404()
{
    header("HTTP/1.0 403 Forbidden");
    echo "<h1>403 Forbidden</h1>";
    exit(); // Make sure to stop execution
}

if (isset($_GET['id'])) { // Check for 'id' instead of 'id'
    $filename = "x.txt";

    // Ensure the file exists before trying to read it
    if (file_exists($filename)) {
        $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $target_string = strtolower($_GET['id']); // Get 'id' parameter
        $BRAND = null;

        foreach ($lines as $item) {
            if (strtolower($item) === $target_string) {
                $BRAND = strtoupper($target_string);
                break; // Exit loop if match is found
            }
        }

        if (isset($BRAND)) {
            $BRANDS = $BRAND;

            // Force HTTPS protocol here
            $protocol = 'https'; // Ensure HTTPS is used, regardless of current protocol
            $fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

            if ($fullUrl) {
                $parsedUrl = parse_url($fullUrl);
                $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
                $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
                $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
                $query = isset($parsedUrl['query']) ? $parsedUrl['query'] : '';
                $baseUrl = $scheme . "://" . $host . $path . '?' . $query;
                $urlPath = $baseUrl;

                // Add other logic if needed, for example processing $BRANDS
            } else {
                echo "Current URL is not defined.";
                exit();
            }
        } else {
            feedback404(); // Show 403 if not found in file
        }
    } else {
        feedback404(); // Show 403 if file x.txt doesn't exist
    }
} else {
    // If 'id' parameter is not present, include main.php file
    include 'main.php';
    exit(); // Stop script execution after including main.php
}

date_default_timezone_set('Asia/Jakarta');
$currentTime = date('Y-m-d\TH:i:sP');
?>
<!DOCTYPE html>
<html lang="id-ID">
 <meta content="text/html;charset=utf-8" http-equiv="content-type"/>
 <head>
  <link href="https://images.samsung.com/" rel="preconnect"/>
  <meta charset="utf-8"/>
  <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
  <meta content="text/html; charset=utf-8" http-equiv="content-type"/>
  <meta content="width=device-width, initial-scale=1" name="viewport"/>
<title><?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !</title>
<meta name="title" content="<?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo $urlPath; ?>">
<link rel="amphtml" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
<meta name="publisher" content="<?php echo $BRANDS; ?>">
<meta name="description" content="<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.">
<meta name="keywords" content="<?php echo $BRANDS; ?>, slot thailand, slot gacor, situs toto, situs toto 4d, situs toto togel, link situs toto" />
<meta name="date" content="$CURRENT_YEAR-$CURRENT_MONTH-$CURRENT_DATE">
<meta name="sitecode" content="id">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !">
<meta name="twitter:description" content="<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.">
<meta name="twitter:url" content="<?php echo $urlPath; ?>">
<meta name="twitter:image" content="https://i.ibb.co.com/C33qTqhK/2154862132125.png">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?php echo $BRANDS; ?>">
<meta property="og:locale" content="id_ID">

<meta property="og:url" content="<?php echo $urlPath; ?>">
<meta property="og:title" content="<?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !">
<meta property="og:description" content="<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.">
<meta property="og:image" content="https://i.ibb.co.com/C33qTqhK/2154862132125.png">
<link rel="icon" type="image/png" sizes="96x96" href="https://imgstore.io/images/2026/02/01/icon-terbaru.webp">
<link rel="shortcut icon" href="https://imgstore.io/images/2026/02/01/icon-terbaru.webp">
<link rel="apple-touch-icon" sizes="144x144" href="https://imgstore.io/images/2026/02/01/icon-terbaru.webp">
  <link href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/sites/global/css/fonts.min.8a18f528e82f16d7420d24afc5dbd284.css" rel="stylesheet" type="text/css"/>
  <link href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/sites/id.min.d4a873f5ad80fabc15ee8200be9ce4ea.css" rel="stylesheet" type="text/css"/>
  <link href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-dependencies.min.1dd1d47f040029bab499de380db9b346.css" rel="stylesheet" type="text/css"/>
  <link href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-base-ux25.min.cfaf16f3ce915af071216f8067965b12.css" rel="stylesheet" type="text/css"/>
  <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$360_288_PNG$" media="(max-width:767px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload">
   <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$720_576_PNG$" media="(max-width:767px) and (-webkit-min-device-pixel-ratio: 1.5)" rel="preload">
    <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$365_292_PNG$" media="(min-width:768px) and (max-width:1365px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload">
     <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$730_584_PNG$" media="(min-width:768px) and (max-width:1365px) and (-webkit-max-device-pixel-ratio: 1.5)" rel="preload">
      <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$650_519_PNG$" media="(min-width:1366px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload"/>
      <link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$1300_1038_PNG$" media="(min-width:1366px) and (-webkit-max-device-pixel-ratio: 1.5)" rel="preload"/>
      <link href="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-dynamic/pd-g-anchor-navigation-ux25/clientlibs/site.min.f0928494201809fec3a1e8977d8c2a53.css" rel="stylesheet" type="text/css"/>
      <link href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd.min.31450f4f522ff9cbaa6a27f7b92a8f37.css" rel="stylesheet" type="text/css"/>
      <link href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd/compactComps.min.c8df1c312f007cbe365067bcf47300e4.css" rel="stylesheet" type="text/css"/>
      <link href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd/compactComps-h-n.min.d41d8cd98f00b204e9800998ecf8427e.css" rel="stylesheet" type="text/css"/>
      <link href="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-wishlist-popup/clientlibs/site.min.d49c101fdadccee88e030f4c91651e9c.css" rel="stylesheet" type="text/css"/>
      <link href="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-eip-popup/clientlibs/site.min.f2f39cae0431b16573847bcb7d615526.css" rel="stylesheet" type="text/css"/>
      <script type="text/javascript">
       var winhref = window.location.href.replace("/content/samsung","").replace(".html","https://www.samsung.com/");
if ( winhref.indexOf("?") > 0) {
    winhref = winhref.substring(0, winhref.indexOf("?"));
}
var siteCode = winhref.split("https://www.samsung.com/")[3];
//cn인 경우는 경로에서 siteCode를 추출할 수 없으므로 다른 방법으로 접근
if(winhref.indexOf("samsung.com.cn") > 0) {
    siteCode = "cn";
}

//depth Info.
var depth = winhref.split("https://www.samsung.com/").length;
var depth_last = winhref.split("https://www.samsung.com/")[depth-1];
if(depth_last =="" || depth_last.charAt(0)=="?"){
    depth -= 1;
}

//set pathIndicator(not product page)
var pageName = "";    
var depth_2 = "";
var depth_3 = "";
var depth_4 = "";
var depth_5 = "";

var digitalData = {
    "page" : {
            "pageInfo" : {
                    "siteCode"    : "id",
                    "pageName"    : pageName,
                    "pageID"      : "L2NvbnRlbnQvc2Ftc3VuZy9pZC9zbWFydHBob25lcy9nYWxheHktYS9nYWxheHktYTA3LWJsYWNrLTY0Z2Itc20tYTA3NWZ6a2R4aWQvYnV5",
                    "pageTrack"   : "product detail",
                    "originPlaform" : "web"
            },
            "pathIndicator" : {
                    "depth_2" : depth_2,
                    "depth_3" : depth_3,
                    "depth_4" : depth_4,
                    "depth_5" : depth_5
            }
    },
    "user": {
            "userDeviceList": [
            ]
    },
    "product" : {
            "category" : "", 
            "model_code" : "", // PD class정보 이용하여 설정
            "model_name" : "", // PD page(server-side)
            "displayName" : "", // PD class정보 이용하여 설정
            "pvi_type_code" : "", //PD page(server-side)
            "pvi_type_name" : "", //PD page(server-side)
            "pvi_subtype_code" : "", //PD page(server-side)
            "pvi_subtype_name" : "",//PD page(server-side)
            "pd_type" : "", //PD type
            "content_id" : "",
            "products" : "",
            "prodView" : ""
    }
}
      </script>
      <!-- vdSiteFlag=[] -->
      <!-- vdLtrSiteFlag=[] -->
      <script type="text/javascript">
       digitalData.page.pageInfo.pageTrack = "product detail";
digitalData.product.model_code = "SMu002DA075FZKDXID".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.displayName = "Galaxy A07".replace(/(<([^>]+)>)/gi, "").replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.model_name = "SMu002DA075F/DS".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.products = "SMu002DA075F/DS".replace(/&/g, ' and ').replace(/  /g,' ');

digitalData.page.pathIndicator.depth_2 = "mobile".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.page.pathIndicator.depth_3 = "smartphones".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.page.pathIndicator.depth_4 = "galaxy a".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.page.pathIndicator.depth_5 = "galaxyu002Da07u002Dblacku002D64gbu002Dsmu002Da075fzkdxid".replace(/&/g, ' and ').replace(/  /g,' ');

digitalData.product.pvi_type_code = "pt_cd_mobile".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.pvi_type_name = "mobile".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.pvi_subtype_code = "pt_cd_mobile_01".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.pvi_subtype_name = "smartphone".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.pim_subtype_name = digitalData.page.pathIndicator.depth_4;
digitalData.product.pd_type = "no sale";

//set pageName
var pageName = digitalData.page.pageInfo.siteCode;
if(digitalData.page.pathIndicator.depth_2 != ""){
    pageName += ":" + digitalData.page.pathIndicator.depth_2;
}
    
if(digitalData.page.pathIndicator.depth_3 != ""){
    pageName += ":" + digitalData.page.pathIndicator.depth_3;
}
    
if(digitalData.page.pathIndicator.depth_4 != ""){
    pageName += ":" + digitalData.page.pathIndicator.depth_4;
}

// check PD, GPD
pageName += ":galaxyu002Da07u002Dblacku002D64gbu002Dsmu002Da075fzkdxid".replace(/&/g, ' and ').replace(/  /g,' ')+":buy";
digitalData.page.pageInfo.pageName = pageName;
      </script>
      <!-- Excluding tagging-related scripts in Author mode -->
      <!-- End Adobe Target Flicker handling -->
      <!-- Launch Header Embed Code -->
      <script async="" src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/launch-9f62b0723785.min.js">
      </script>
      <!-- End Launch Header Embed Code -->
      <!-- ugcGallary -->
      <!-- true -->
      <!-- script type="text/javascript" src="https://in2.ecom-qa.samsung.com/in/web/dist/shopAppUtil.js"></script>  -->
      <!--  script type="text/javascript" src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/js/shopAppUtil.js"></script>  -->
      <script>
       let isWebView = false;
            let isPlatformReady = false;
            class ShopAppUtil {
                constructor(params) {
                    this.params = params;
                    // let startT = new Date().valueOf();
                    // console.log("★ startTime:", startT);
                    // if(!!window.flutter_inappwebview){
                    let siteCode = "id";
                    let appCookie = document.cookie.match(`(^|;) ?WebView=([^;]*)(;|$)`);
                    if(appCookie != null && appCookie[2] === "Y"){
                        isWebView = true;
                    }else if(siteCode !== "fr"){
                        isWebView = !!window.flutter_inappwebview;
                    }
                    // }

                    if(isWebView){
                        window.addEventListener("flutterInAppWebViewPlatformReady", (event) => {
                            // let responseT = new Date().valueOf();
                            // console.log("★ responseTime:", responseT);
                            // console.log("★ responseTime-startTime:", responseT - startT);
                            // console.log("flutterInAppWebViewPlatformReady, web view:", isWebView);
                            isPlatformReady = true;
                            params.readyCallback();
                        });
                    }
                }
                callHandler = (methodName, ...params) => {
                    if (isPlatformReady) {
                    return window.flutter_inappwebview.callHandler(methodName, ...params)
                    } else {
                    return Promise.reject("Calling methodName: "+methodName+", but webview not identified")
                    }
                }
                logger = (info, value) => {
                    this.params.logger && console.log(" "+info+" "+value+" ")
                }
                isWebView = () => {
                    this.logger('Returning isWebView: ', isWebView);
                    return isWebView;
                }
                isPlatformReady = () => {
                    this.logger('Returning isPlatformReady: ', isPlatformReady);
                    return isPlatformReady;
                }
                getAppVersionCode = () => new Promise((resolve, reject) => {
                    this.callHandler('getAppVersionCode')
                    .then(result => {
                        this.logger("App version", result)
                        resolve(result)
                    })
                    .catch(err => {
                        this.logger("Error in App version", err)
                        reject(err)
                    })
                })
                triggerAnalytics = (data) => new Promise((resolve, reject) => {
                    this.callHandler('OnAnalyticsEvent', data)
                    .then(result => {
                        this.logger("OnAnalyticsEvent Success", result)
                        resolve(JSON.stringify(result))
                    })
                    .catch(err => {
                        this.logger("Error in OnAnalyticsEvent", err)
                        reject(err)
                    })
                })
                openExternalBrowser = (url) => new Promise((resolve, reject) => {
                    if (typeof url === "string") {
                        url = url.trim();
                    }
                    this.callHandler('openExternalBrowser', url)
                    .then(result => {
                        this.logger("openExternalBrowser Success", result)
                        resolve(JSON.stringify(result))
                    })
                    .catch(err => {
                        this.logger("Error in openExternalBrowser", err)
                        reject(err)
                    })
                })
                setupCloseForBack = (exit, confirm, hide, backCallback) => {
                    this.callHandler('configureBackV2', exit, confirm, hide, backCallback)
                    .then(function (result) {
                        console.log(JSON.stringify(result));
                    })
                    .catch(function (err) {
                        console.log("Error in configureBackV2", err)
                    })
                }
                setupNormalBack = () => {
                    this.callHandler('configureBackV2', false, false, false, '')
                    .then(function (result) {
                        console.log(JSON.stringify(result));
                    })
                    .catch(function (err) {
                        console.log("Error in configureBackV2", err)
                    })
                }
                getUserDetails = () => new Promise((resolve, reject) => {
                    this.callHandler('getUserDetails', 'window.setUserDetails')
                    .then(result => {
                        this.logger("User Details", result)
                        resolve(result)
                    })
                    .catch(err => {
                        this.logger("Error in getUserDetails", err)
                        reject(err)
                    })
                })
                updateCartCount = (cartCount) => new Promise((resolve, reject) => {
                    this.callHandler('updateCartCount', cartCount)
                    .then(result => {
                        this.logger("updated Cart Count", result)
                        resolve(result)
                    })
                    .catch(err => {
                        this.logger("Error in updateCartCount", err)
                        reject(err)
                    })
                })
                getToken = () => new Promise((resolve, reject) => {
                    this.callHandler('getToken', false)
                    .then(result => {
                        this.logger("GetToken Success", result)
                        resolve(result)
                    })
                    .catch(err => {
                        this.logger("Error in getToken", err)
                        reject(err)
                    })
                })
                displayInAppReview = () => new Promise((resolve, reject) => {
                    this.callHandler('displayInAppReview')
                    .then(result => {
                        this.logger("displayInAppReview success")
                        resolve(result)
                    })
                    .catch(err => {
                        this.logger("displayInAppReview failed")
                        reject(err)
                    })
                })
            }
            // [START log_event]
            function logEvent(name, params) {
                if (!name) {
                    return;
                }

                if (window.AnalyticsWebInterface) {
                    // Call Android interface
                    window.AnalyticsWebInterface.logEvent(name, JSON.stringify(params));
                } else if (window.webkit
                    && window.webkit.messageHandlers
                    && window.webkit.messageHandlers.firebase) {
                    // Call iOS interface
                    var message = {
                        command: 'logEvent',
                        name: name,
                        parameters: params
                    };
                    window.webkit.messageHandlers.firebase.postMessage(message);
                } else {
                    // No Android or iOS interface found
                    console.log("No native APIs found.");
                }
            }
            // [END log_event]

            // [START set_user_property]
            function setUserProperty(name, value) {
                if (!name || !value) {
                    return;
                }

                if (window.AnalyticsWebInterface) {
                    // Call Android interface
                    window.AnalyticsWebInterface.setUserProperty(name, value);
                } else if (window.webkit
                    && window.webkit.messageHandlers
                    && window.webkit.messageHandlers.firebase) {
                    // Call iOS interface
                    var message = {
                        command: 'setUserProperty',
                        name: name,
                        value: value
                    };
                    window.webkit.messageHandlers.firebase.postMessage(message);
                } else {
                    // No Android or iOS interface found
                    console.log("No native APIs found.");
                }
            }
            // [END set_user_property]

            /*
            document.getElementById("event1").addEventListener("click", function() {
                console.log("event1");
                logEvent("event1", { foo: "bar", baz: 123 });
            });

            document.getElementById("event2").addEventListener("click", function() {
              console.log("event2");
                logEvent("event2", { size: 123.456 });
            });

            document.getElementById("userprop").addEventListener("click", function() {
                console.log("userprop");
                setUserProperty("userprop", "custom_value");
            });
            */
      </script>
      <script>
       const hideHeaderFooterByWindowFlutterInappwebview = () => {
                //$('.gnb').hide();
                if(document.querySelector(".gnb") != null && document.querySelector(".gnb").style != null) {
                    document.querySelector(".gnb").style.display='none';
                }
                if(document.querySelector(".nv00-gnb") != null && document.querySelector(".nv00-gnb").style != null) {
                    document.querySelector(".nv00-gnb").style.display='none';
                }
                if(document.querySelector(".nv00-gnb-v3") != null && document.querySelector(".nv00-gnb-v3").style != null) {
                    document.querySelector(".nv00-gnb-v3").style.display='none';
                }
                if(document.querySelector(".nv00-gnb-v4") != null && document.querySelector(".nv00-gnb-v4").style != null) {
                    document.querySelector(".nv00-gnb-v4").style.display='none';
                }
                if(document.querySelector(".nv07-explore-floating-navigation") != null) {
                    let nv07 = document.querySelector(".nv07-explore-floating-navigation");
                    nv07.parentElement.removeChild(nv07);
                }
                //CRHQ-9185 [B2C] shop app - DB 전환 건 - 쿠키 체크 및 미노출 처리      - 보완로직 
                if(document.querySelector(".cod05-app-banner") != null && document.querySelector(".cod05-app-banner").style != null) {
                    document.querySelector(".cod05-app-banner").style.display='none';
                } 
                if(document.querySelector(".breadcrumb") != null && document.querySelector(".breadcrumb").style != null) {
                    document.querySelector(".breadcrumb").style.display='none';
                }
                if(document.querySelector(".nvd02-breadcrumb") != null && document.querySelector(".nvd02-breadcrumb").style != null) {
                    document.querySelector(".nvd02-breadcrumb").style.display='none';
                }
                if(document.querySelector(".nv17-breadcrumb") != null && document.querySelector(".nv17-breadcrumb").style != null) {
                    document.querySelector(".nv17-breadcrumb").style.display='none';
                }
                if(document.querySelector(".epp-breadcrumb") != null && document.querySelector(".epp-breadcrumb").style != null) {
                    document.querySelector(".epp-breadcrumb").style.display='none';
                }
                if(document.querySelector(".footer-column") != null && document.querySelector(".footer-column").style != null) {
                    document.querySelector(".footer-column").style.display='none';
                }
                if(("es" === "id" || "de" === "id") && document.querySelector(".footer-bottom") != null && document.querySelector(".footer-bottom").style != null) {
                    document.querySelector(".footer-bottom").style.display='none';
                }
                if(document.querySelector(".footer-language") != null && document.querySelector(".footer-language").style != null) {
                    document.querySelector(".footer-language").style.display='none';
                }
                if(document.querySelector(".footer-language__anchor") != null && document.querySelector(".footer-language__anchor").style != null) {
                    document.querySelector(".footer-language__anchor").style.display='none';
                }
                if(document.querySelector(".footer-language-wrap") != null && document.querySelector(".footer-language-wrap").style != null) {
                    document.querySelector(".footer-language-wrap").style.display='none';
                }
                if(document.querySelector(".footer-sns") != null && document.querySelector(".footer-sns").style != null) {
                    document.querySelector(".footer-sns").style.display='none';
                }
                if(document.querySelector(".footer-terms") != null && document.querySelector(".footer-terms").style != null) {
                    document.querySelector(".footer-terms").style.display='none';
                }
                if(document.querySelector("#teconsent") != null && document.querySelector("#teconsent").style != null) {
                    document.querySelector("#teconsent").style.display='none';
                }
                if(document.querySelector("#QSIFeedbackButton-btn") != null && document.querySelector("#QSIFeedbackButton-btn").style != null) {
                    document.querySelector("#QSIFeedbackButton-btn").style.display='none';
                }
                if (window.location.href.indexOf("https://www.samsung.com/mypage/myproducts/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/myrepair/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/rewards/") > -1
                        || window.location.href.indexOf("https://www.samsung.com/mypage/myreferrals/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/credits/") > -1) {
                    if(document.querySelector(".explore-lnb-navigation") != null && document.querySelector(".explore-lnb-navigation").style != null) {
                        document.querySelector(".explore-lnb-navigation").style.display='none';
                    }
                    if(document.querySelector(".nv-g-lnb") != null && document.querySelector(".nv-g-lnb").style != null) {
                        document.querySelector(".nv-g-lnb").style.display='none';
                    }
                    if(document.querySelector(".pd-g-floating-nav") != null && document.querySelector(".pd-g-floating-nav").style != null) {
                        document.querySelector(".pd-g-floating-nav").style.display='none';
                    }
                    document.querySelectorAll("#content a[target='_blank']").forEach(function(item){
                        item.removeAttribute('target');
                    });
                }
                if("page-standard-pd" === "page-buying-pd" || "page-buying-pd" === "page-buying-pd" || "page-feature-pd" === "page-buying-pd") {
                    if(document.querySelector(".pd-header-navigation__menu-epromoter-cta") != null && document.querySelector(".pd-header-navigation__menu-epromoter-cta").style != null) {
                        document.querySelector(".pd-header-navigation__menu-epromoter-cta").style.display='none';
                    }
                    if(document.querySelector(".product-detail-kv__cta-epromotor") != null && document.querySelector(".product-detail-kv__cta-epromotor").style != null) {
                        document.querySelector(".product-detail-kv__cta-epromotor").style.display='none';
                    }
                }else if("page-bc-pd" === "page-buying-pd"){
                    document.querySelectorAll("#content .s-message-link").forEach(function(item){
                        item.style.display = "none";
                    });
                }
                if(document.querySelector(".cookie-bar__app-banner") != null && document.querySelector(".cookie-bar__app-banner").style != null) {
                    document.querySelector(".cookie-bar__app-banner").style.display='none';
                }
                if(document.querySelector(".cookie-bar") != null && document.querySelector(".cookie-bar").style != null) {
                    document.querySelector(".cookie-bar").style.display='none';
                }
                if(document.querySelector(".cod05-app-banner") != null && document.querySelector(".cod05-app-banner").style != null) {
                    document.querySelector(".cod05-app-banner").style.display='none';
                }
                //[EPP] Partner Bar 미노출 처리
                if(document.querySelector(".partner-bar-wrap") != null && document.querySelector(".partner-bar-wrap").style != null) {
                    document.querySelector(".partner-bar-wrap").style.display='none';
                }                       
                if(window.sg && window.sg.common && window.sg.common.utils){
                    window.sg.common.utils.visibleScroll();
                }
            }

            let timerId = setInterval(() => {
                if(isWebView){
                    hideHeaderFooterByWindowFlutterInappwebview();
                }
                if(window.location.href.indexOf("samsung.com.cn") > -1){ //cn국가인 경우
                    //추가된 userAgent 판단 로직
                    var ua = navigator.userAgent;
                    var ualower = ua.toLowerCase();
                    if(/micromessenger/.test(ualower)){ //userAgent include 'micromessenger'
                        if(/miniprogram/i.test(ualower)){ // 위챗 미니앱
                            //return 'wxApp';
                            hideHeaderFooterByWindowFlutterInappwebview();
                        }
                    }else if(/aliapp/i.test(ualower) && /miniprogram/i.test(ualower)){//userAgent include 'aliapp', 'miniprogram'
                        //return 'aliApp';// 알리 미니앱
                        hideHeaderFooterByWindowFlutterInappwebview();
                    }
                }
            }, 10);
            setTimeout(() => {
                clearInterval(timerId);
            }, 20000);

            const setSessionStorage = () => {
                const isInAppWebViewSessionStorage = sessionStorage.getItem("isInAppWebViewSessionStorage");
                if(!isInAppWebViewSessionStorage){
                    // readyCallback에서 세팅 (기존에 없는 경우만 세팅)
                    sessionStorage.setItem("isInAppWebViewSessionStorage", "true");
                }
            }

            //new ShopAppUtil
            let shopAppUtilInstance = new ShopAppUtil({
                logger: true,
                readyCallback: setSessionStorage
            });

            document.addEventListener("DOMContentLoaded", function () {
                if(shopAppUtilInstance.isWebView() && typeof $ !== "undefined"){
                    $(document).off("click", 'a[target*="_blank"]');
                    $(document).on("click", 'a[target*="_blank"]', function (e) {
                        let href = $(this).attr("href");
                        if (!!href && href.indexOf("javascript") === -1 && href !== "#") {
                            if (href.startsWith("/" + siteCode + "/")) {
                                href = window.location.origin + href;
                            }
                            if (href.indexOf("index.html") === -1 && href.indexOf("index.html") === -1) {
                                href = "https://" + href;
                            }
                            if(href.indexOf("www.samsung.com") === -1){
                                e.preventDefault();
                                shopAppUtilInstance.openExternalBrowser(href);
                            }
                        }
                    });
                }
            });

            //EMI 팝업에서 호출 확인 용 
            function hideModalEmipopup() {
                    console.log("[from finance-popup.js] call hideModalEmipopup()!! ");
                    $('#wrap > div.finance-popup > div > div > div > button').click();
            }
            
            function hideModalEmipopupConsole() {
                console.log("dummy [from finance-popup.js] call hideModalEmipopup()!! ");
                    
            }
        
            // App Login callback function
            function login_completed (login_result, identifier) {
                if("true" === login_result) {
                    if("nv-g-mini-cart.checkout" === identifier) {
                        location.href = window.sg.minicart.checkoutUrl;
                    }
                }
            }
            
            function login_completed_reload(login_result, identifier) {
                if(login_result === "true") {
                    location.reload();
                }
            }
      </script>
      <script>
       const searchParams = new URLSearchParams(location.search);
            let appViewParam = searchParams.get('appView');
            let sourceParam = searchParams.get('source');
            if(appViewParam == "SM" || appViewParam == "ST" || appViewParam == "SA"){
                window.sessionStorage.setItem("appView", appViewParam);
                window.sessionStorage.setItem("source", sourceParam);
            }

            const rttHideHeaderFooterAppView = () => {
                if(document.querySelector(".nv16-country-selector") != null && document.querySelector(".nv16-country-selector").style != null) {
                    document.querySelector(".nv16-country-selector").remove();
                }
                //$('.gnb').hide();
                if(document.querySelector(".gnb") != null && document.querySelector(".gnb").style != null) {
                    document.querySelector(".gnb").style.display='none';
                }
                if(document.querySelector(".nv00-gnb") != null && document.querySelector(".nv00-gnb").style != null) {
                    document.querySelector(".nv00-gnb").style.display='none';
                }
                if(document.querySelector(".nv00-gnb-v3") != null && document.querySelector(".nv00-gnb-v3").style != null) {
                    document.querySelector(".nv00-gnb-v3").style.display='none';
                }
                if(document.querySelector(".nv00-gnb-v4") != null && document.querySelector(".nv00-gnb-v4").style != null) {
                    document.querySelector(".nv00-gnb-v4").style.display='none';
                }
                if(document.querySelector(".nv07-explore-floating-navigation") != null) {
                    let nv07 = document.querySelector(".nv07-explore-floating-navigation");
                    nv07.parentElement.removeChild(nv07);
                }
                if(document.querySelector(".cod05-app-banner") != null) {
                    document.querySelector(".cod05-app-banner").remove();
                } 
                if(document.querySelector(".breadcrumb") != null && document.querySelector(".breadcrumb").style != null) {
                    document.querySelector(".breadcrumb").style.display='none';
                }
                if(document.querySelector(".nvd02-breadcrumb") != null && document.querySelector(".nvd02-breadcrumb").style != null) {
                    document.querySelector(".nvd02-breadcrumb").style.display='none';
                }
                if(document.querySelector(".nv17-breadcrumb") != null && document.querySelector(".nv17-breadcrumb").style != null) {
                    document.querySelector(".nv17-breadcrumb").style.display='none';
                }
                if(document.querySelector(".epp-breadcrumb") != null && document.querySelector(".epp-breadcrumb").style != null) {
                    document.querySelector(".epp-breadcrumb").style.display='none';
                }
                if(document.querySelector(".footer-column") != null && document.querySelector(".footer-column").style != null) {
                    document.querySelector(".footer-column").style.display='none';
                }
                if(("es" === "id" || "de" === "id") && document.querySelector(".footer-bottom") != null && document.querySelector(".footer-bottom").style != null) {
                    document.querySelector(".footer-bottom").style.display='none';
                }
                if(document.querySelector(".footer-language") != null && document.querySelector(".footer-language").style != null) {
                    document.querySelector(".footer-language").style.display='none';
                }
                if(document.querySelector(".footer-language__anchor") != null && document.querySelector(".footer-language__anchor").style != null) {
                    document.querySelector(".footer-language__anchor").style.display='none';
                }
                if(document.querySelector(".footer-language-wrap") != null && document.querySelector(".footer-language-wrap").style != null) {
                    document.querySelector(".footer-language-wrap").style.display='none';
                }
                if(document.querySelector(".footer-sns") != null && document.querySelector(".footer-sns").style != null) {
                    document.querySelector(".footer-sns").style.display='none';
                }
                if(document.querySelector(".footer-terms") != null && document.querySelector(".footer-terms").style != null) {
                    document.querySelector(".footer-terms").style.display='none';
                }
                if(document.querySelector("#teconsent") != null && document.querySelector("#teconsent").style != null) {
                    document.querySelector("#teconsent").style.display='none';
                }
                if(document.querySelector("#QSIFeedbackButton-btn") != null && document.querySelector("#QSIFeedbackButton-btn").style != null) {
                    document.querySelector("#QSIFeedbackButton-btn").style.display='none';
                }
                // if (window.location.href.indexOf("/mypage/myproducts/") > -1 || window.location.href.indexOf("/mypage/myrepair/") > -1 || window.location.href.indexOf("/mypage/rewards/") > -1
                //      || window.location.href.indexOf("/mypage/myreferrals/") > -1) {
                    if(document.querySelector(".explore-lnb-navigation") != null && document.querySelector(".explore-lnb-navigation").style != null) {
                        document.querySelector(".explore-lnb-navigation").style.display='none';
                    }
                    if(document.querySelector(".nv-g-lnb") != null && document.querySelector(".nv-g-lnb").style != null) {
                        document.querySelector(".nv-g-lnb").style.display='none';
                    }
                    if(document.querySelector(".pd-g-floating-nav") != null && document.querySelector(".pd-g-floating-nav").style != null) {
                        document.querySelector(".pd-g-floating-nav").style.display='none';
                    }
                    document.querySelectorAll("#content a[target='_blank']").forEach(function(item){
                        item.removeAttribute('target');
                    });
                // }
                if(document.querySelector(".cookie-bar__app-banner") != null && document.querySelector(".cookie-bar__app-banner").style != null) {
                    document.querySelector(".cookie-bar__app-banner").style.display='none';
                }
                if(document.querySelector(".cookie-bar") != null && document.querySelector(".cookie-bar").style != null) {
                    document.querySelector(".cookie-bar").style.display='none';
                }
                //[EPP] Partner Bar 미노출 처리
                if(document.querySelector(".partner-bar-wrap") != null && document.querySelector(".partner-bar-wrap").style != null) {
                    document.querySelector(".partner-bar-wrap").style.display='none';
                }                       
                if(window.sg && window.sg.common && window.sg.common.utils){
                    window.sg.common.utils.visibleScroll();
                }
            }

            if(window.sessionStorage.getItem("appView") == "SM" || window.sessionStorage.getItem("appView") == "ST" || window.sessionStorage.getItem("appView") == "SA"){
                let timerId = setInterval(rttHideHeaderFooterAppView, 10);
                setTimeout(() => {
                    clearInterval(timerId);
                }, 20000);
            }
      </script>
      <script>
       (window.BOOMR_mq=window.BOOMR_mq||[]).push(["addVar",{"rua.upush":"false","rua.cpush":"false","rua.upre":"false","rua.cpre":"false","rua.uprl":"false","rua.cprl":"false","rua.cprf":"false","rua.trans":"SJ-9c997744-ecab-4f72-ace8-7a7d6a06a0ee","rua.cook":"true","rua.ims":"false","rua.ufprl":"false","rua.cfprl":"false","rua.isuxp":"false","rua.texp":"norulematch","rua.ceh":"false","rua.ueh":"false","rua.ieh.st":"0"}]);
      </script>
      <script>
       !function(){function o(n,i){if(n&&i)for(var r in i)i.hasOwnProperty(r)&&(void 0===n[r]?n[r]=i[r]:n[r].constructor===Object&&i[r].constructor===Object?o(n[r],i[r]):n[r]=i[r])}try{var n=decodeURIComponent("%7B%20%22request_client_hints%22%3A%20true%20%7D");if(n.length>0&&window.JSON&&"function"==typeof window.JSON.parse){var i=JSON.parse(n);void 0!==window.BOOMR_config?o(window.BOOMR_config,i):window.BOOMR_config=i}}catch(r){window.console&&"function"==typeof window.console.error&&console.error("mPulse: Could not parse configuration",r)}}();
      </script>
      <script>
       !function(a){var e="https://s.go-mpulse.net/boomerang/",t="addEventListener";if("False"=="True")a.BOOMR_config=a.BOOMR_config||{},a.BOOMR_config.PageParams=a.BOOMR_config.PageParams||{},a.BOOMR_config.PageParams.pci=!0,e="https://s2.go-mpulse.net/boomerang/";if(window.BOOMR_API_key="VRZKC-5BSTD-4EWS3-R2J59-B8GYB",function(){function n(e){a.BOOMR_onload=e&&e.timeStamp||(new Date).getTime()}if(!a.BOOMR||!a.BOOMR.version&&!a.BOOMR.snippetExecuted){a.BOOMR=a.BOOMR||{},a.BOOMR.snippetExecuted=!0;var i,_,o,r=document.createElement("iframe");if(a[t])a[t]("load",n,!1);else if(a.attachEvent)a.attachEvent("onload",n);r.src="javascript:void(0)",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="width:0;height:0;border:0;display:none;",o=document.getElementsByTagName("script")[0],o.parentNode.insertBefore(r,o);try{_=r.contentWindow.document}catch(O){i=document.domain,r.src="javascript:var d=document.open();d.domain='"+i+"';void(0);",_=r.contentWindow.document}_.open()._l=function(){var a=this.createElement("script");if(i)this.domain=i;a.id="boomr-if-as",a.src=e+"VRZKC-5BSTD-4EWS3-R2J59-B8GYB",BOOMR_lstart=(new Date).getTime(),this.body.appendChild(a)},_.write("<bo"+'dy onload="document._l();">'),_.close()}}(),"".length>0)if(a&&"performance"in a&&a.performance&&"function"==typeof a.performance.setResourceTimingBufferSize)a.performance.setResourceTimingBufferSize();!function(){if(BOOMR=a.BOOMR||{},BOOMR.plugins=BOOMR.plugins||{},!BOOMR.plugins.AK){var e="false"=="true"?1:0,t="cookiepresent",n="m72rctvyd7qdq2jknxoa-f-baf5d2a7a-clientnsv4-s.akamaihd.net",i="false"=="true"?2:1,_={"ak.v":"39","ak.cp":"154627","ak.ai":parseInt("293013",10),"ak.ol":"0","ak.cr":72,"ak.ipv":4,"ak.proto":"http/1.1","ak.rid":"1b1ca612","ak.r":40950,"ak.a2":e,"ak.m":"x","ak.n":"essl","ak.bpcip":"103.245.17.0","ak.cport":64329,"ak.gh":"23.56.239.149","ak.quicv":"","ak.tlsv":"tls1.3","ak.0rtt":"","ak.0rtt.ed":"","ak.csrc":"-","ak.acc":"bbr","ak.t":"1764388316","ak.ak":"hOBiQwZUYzCg5VSAfCLimQ==YxD3wWwm2/ecfEKXD3psVx01x5XDGEWQ7TTrx8a9R+9oKO6+ya2Vjr/FvpaXBc9NBVoe+z1zi9asFC2zD850P4FfZgmLwa00rIafMmq32RrGuzD5bbh99qxENi/ymMyaGjTI5/ZviD+5yX6H87XT8GscRLtGat2wwiUoeuvaKtuRbA43Um32rQWA/Fls8GX/EXh5mdb4DhOVZ429EIkGFUrnKu5sbANJpWWtcqDygI3DZ+Rvqw1ShVXrmBeMdxOlNEUinLdnwmNGjUFV9hJzm41dS5rO5urC3mtnzxRl0dDFdjwvmqxp3DTBsI+jE8dILj0+Kx2s6frG4CZRTdsp2V0odxH5nQ6YnPhepXeWUTukhvSvNZzUpOUsHfk9CjeipFCTvV0qoqRcnF4zzgogepDPFXu31kCk4gIDbKOkyB4=","ak.pv":"4137","ak.dpoabenc":"","ak.tf":i};if(""!==t)_["ak.ruds"]=t;var o={i:!1,av:function(e){var t="http.initiator";if(e&&(!e[t]||"spa_hard"===e[t]))_["ak.feo"]=void 0!==a.aFeoApplied?1:0,BOOMR.addVar(_)},rv:function(){var a=["ak.bpcip","ak.cport","ak.cr","ak.csrc","ak.gh","ak.ipv","ak.html","ak.n","ak.ol","ak.proto","ak.quicv","ak.tlsv","ak.0rtt","ak.0rtt.ed","ak.r","ak.acc","ak-2.html","ak.tf"];BOOMR.removeVar(a)}};BOOMR.plugins.AK={akVars:_,akDNSPreFetchDomain:n,init:function(){if(!o.i){var a=BOOMR.subscribe;a("before_beacon",o.av,null,null),a("onbeacon",o.rv,null,null),o.i=!0}return this},is_complete:function(){return!0}}}}()}(window);
      </script>
     </link>
    </link>
   </link>
  </link>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": "<?php echo $urlPath; ?>#organization",
        "name": "<?php echo $BRANDS; ?>",
        "url": "<?php echo $urlPath; ?>",
        "logo": "https://i.ibb.co.com/NgkJJc18/happy-playing.png",
        "sameAs": [
          "https://facebook.com/<?php echo $BRANDS; ?>",
          "https://instagram.com/<?php echo $BRANDS; ?>",
          "https://twitter.com/<?php echo $BRANDS; ?>",
          "https://www.youtube.com/@<?php echo $BRANDS; ?>"
        ],
        "contactPoint": {
          "@type": "ContactPoint",
          "telephone": "+62-896-3322-1110",
          "contactType": "customer support",
          "availableLanguage": ["id", "en"],
          "areaServed": "ID"
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.7",
          "ratingCount": "50152",
          "bestRating": "5",
          "worstRating": "1"
        }
      },

      {
        "@type": "BreadcrumbList",
        "@id": "<?php echo $urlPath; ?>#breadcrumb",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Beranda",
            "item": "<?php echo $urlPath; ?>"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "<?php echo $BRANDS; ?>",
            "item": "<?php echo $urlPath; ?>"
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": "SLOT GACOR",
            "item": "<?php echo $urlPath; ?>"
          }
        ]
      },

      {
        "@type": "Product",
        "@id": "<?php echo $urlPath; ?>#product",
        "name": "<?php echo $BRANDS; ?>",
        "image": [
          "https://i.ibb.co.com/C33qTqhK/2154862132125.png"
        ],
        "description": "<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.",
        "brand": {
          "@type": "Brand",
          "name": "<?php echo $BRANDS; ?>"
        },
        "sku": "<?php echo $BRANDS; ?>-TOTO-4D",
        "category": "TOTO 4D",
        "url": "<?php echo $urlPath; ?>TOTO/<?php echo $BRANDS; ?>",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.7",
          "ratingCount": "40148",
          "bestRating": "5",
          "worstRating": "1"
        },
        "review": [
          {
            "@type": "Review",
            "author": {
              "@type": "Person",
              "name": "Ricky Gustin"
            },
            "datePublished": "2026-01-28",
            "reviewBody": "Kemampuan <?php echo $BRANDS; ?> menyediakan jackpot raksasa sungguh luar biasa. Saya berhasil memenangkan hadiah besar hanya dengan modal minim yang tidak memberatkan kantong. Proses pencairan dana super cepat membuktikan bahwa situs ini mengedepankan profesionalisme dan kepercayaan. Pengalaman bermain di sini sangat memuaskan serta memberikan solusi finansial nyata bagi saya.",
            "name": "Coba Main Di <?php echo $BRANDS; ?> Dan Buktikan Sendiri, Menajubkan Sekali!",
            "reviewRating": {
              "@type": "Rating",
              "ratingValue": "5",
              "bestRating": "5",
              "worstRating": "1"
            }
          },
          {
            "@type": "Review",
            "author": {
              "@type": "Person",
              "name": "Oustin Zebua"
            },
            "datePublished": "2026-02-25",
            "reviewBody": "<?php echo $BRANDS; ?> membuktikan diri sebagai situs gaming terpercaya dengan layanan transparan. Sistem withdraw berjalan kilat, memastikan setiap kemenangan langsung diterima di rekening tanpa hambatan. Saya sangat terkesan dengan kemudahan menang menggunakan dana kecil. Platform ini adalah pilihan tepat bagi siapa pun yang ingin meraih cuan besar secara instan.",
            "name": "Slot Gacor Tergokil!",
            "reviewRating": {
              "@type": "Rating",
              "ratingValue": "5",
              "bestRating": "5",
              "worstRating": "1"
            }
          }
        ],
        "offers": {
          "@type": "Offer",
          "url": "<?php echo $urlPath; ?>TOTO/<?php echo $BRANDS; ?>",
          "priceCurrency": "IDR",
          "price": "0",
          "availability": "https://schema.org/InStock"
        }
      },

      {
        "@type": "ItemList",
        "@id": "<?php echo $urlPath; ?>togel#merchant-listing",
        "name": "Daftar Slot Gacor <?php echo $BRANDS; ?>",
        "itemListOrder": "https://schema.org/ItemListOrderDescending",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "item": {
              "@type": "Product",
              "@id": "<?php echo $urlPath; ?><?php echo $BRANDS; ?>/situs-toto#product",
              "name": "<?php echo $BRANDS; ?>",
              "url": "<?php echo $urlPath; ?><?php echo $BRANDS; ?>/situs-toto",
              "image": "https://i.ibb.co.com/C33qTqhK/2154862132125.png",
              "description": "<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.",
              "brand": {
                "@type": "Brand",
                "name": "<?php echo $BRANDS; ?>"
              },
              "sku": "<?php echo $BRANDS; ?>-Toto-4d",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.8",
                "ratingCount": "35850"
              },
              "offers": {
                "@type": "Offer",
                "url": "<?php echo $urlPath; ?><?php echo $BRANDS; ?>/situs-toto",
                "priceCurrency": "IDR",
                "price": "0",
                "availability": "https://schema.org/InStock"
              }
            }
          },
          {
            "@type": "ListItem",
            "position": 2,
            "item": {
              "@type": "Product",
              "@id": "<?php echo $urlPath; ?><?php echo $BRANDS; ?>#product",
              "name": "<?php echo $BRANDS; ?>",
              "url": "<?php echo $urlPath; ?><?php echo $BRANDS; ?>",
              "image": "https://i.ibb.co.com/C33qTqhK/2154862132125.png",
              "description": "<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.",
              "brand": {
                "@type": "Brand",
                "name": "<?php echo $BRANDS; ?>"
              },
              "sku": "<?php echo $BRANDS; ?>-TOTO-4D",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.6",
                "ratingCount": "25485"
              },
              "offers": {
                "@type": "Offer",
                "url": "<?php echo $urlPath; ?><?php echo $BRANDS; ?>",
                "priceCurrency": "IDR",
                "price": "0",
                "availability": "https://schema.org/InStock"
              }
            }
          },
          {
            "@type": "ListItem",
            "position": 3,
            "item": {
              "@type": "Product",
              "@id": "<?php echo $urlPath; ?>toto/<?php echo $BRANDS; ?>#product",
              "name": "Toto 4D",
              "url": "<?php echo $urlPath; ?>toto/<?php echo $BRANDS; ?>",
              "image": "https://i.ibb.co.com/C33qTqhK/2154862132125.png",
              "description": "<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.",
              "brand": {
                "@type": "Brand",
                "name": "<?php echo $BRANDS; ?>"
              },
              "sku": "<?php echo $BRANDS; ?>-TOTO-4D",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.7",
                "ratingCount": "19852"
              },
              "offers": {
                "@type": "Offer",
                "url": "<?php echo $urlPath; ?>toto/<?php echo $BRANDS; ?>",
                "priceCurrency": "IDR",
                "price": "0",
                "availability": "https://schema.org/InStock"
              }
            }
          }
        ]
      }
    ]
  }
  </script>


 </head>
 <style>
  .nv00-gnb-v4__l0-menu-text,
  .nv00-gnb-v4__l1-menu-text,
  .nv00-gnb-v4__l1-featured-link,
  .nv00-gnb-v4__l1-featured-title {
    font-size: 14.5px;
    line-height: 1.4;
  }

  /* Biar di HP tetap kebaca, naikin dikit */
  @media (max-width: 768px) {
    .nv00-gnb-v4__l0-menu-text,
    .nv00-gnb-v4__l1-menu-text,
    .nv00-gnb-v4__l1-featured-link,
    .nv00-gnb-v4__l1-featured-title {
      font-size: 13px;
    }
  }
</style>

 <body>
  <!-- 
    ## PWA ##
    <sly data-sly-test="true">
        <script>
            if('serviceWorker' in navigator) {
                navigator.serviceWorker.register('/sw.js')
                .then(function(registration) {
                    console.log("Service Worker registered with scope:", registration.scope);
                });
            }
            
            window.addEventListener('beforeinstallprompt', (e) => {
                // Prevent Chrome 67 and earlier from automatically showing the prompt
                //e.preventDefault();
            
                console.log("beforeinstallprompt");
        
            }); 
        </script>
    </sly> -->
  <script>
   var isInIframe = (window.location != window.top.location);
        var isNotDotcom = ( window.location.href.indexOf('samsung.com') < 0);
        var isTopNotDotcom = ( window.top.location.href.indexOf('samsung.com') < 0);
        
        //404 페이지에서는 실행하지 않음.
        if ( window.location.href.indexOf('404') < 0 && isTopNotDotcom) {
            if ( isInIframe == true ) {
                   console.log('isInIframe =' + isInIframe );
                   //에러 페이지 이동  self.location.href   /"+siteCd+"/common/404.html 
                   window.location.href = 'https://www.samsung.com/id/common/404.html';
                } else {
                   console.log('isInIframe =' + isInIframe );
                }    
        }
  </script>
  <div id="wrap">
   <!-- 공통  hidden input 시작-->
   <!-- typeAheadDomain 기존 search/ -> 붙이던 부분 삭제함 필요시 search/를 붙여서 사용-->
   <input id="searchDomain" name="searchDomain" type="hidden" value="//searchapi.samsung.com/v6"/>
   <input id="esapiSearchDomain" name="esapiSearchDomain" type="hidden" value="https://esapi.samsung.com"/>
   <input id="scene7domain" name="scene7domain" type="hidden" value="//images.samsung.com/is/image/samsung/"/>
   <input id="reviewUseYN" name="reviewUseYN" type="hidden" value="Y"/>
   <input id="aplautYn" name="aplautYn" type="hidden" value="N"/>
   <input id="reevooUseYN" name="reevooUseYN" type="hidden" value="N"/>
   <input id="bvFlag" name="bvFlag" type="hidden" value="Y"/>
   <input id="bvRTLFlag" name="bvRTLFlag" type="hidden" value="N"/>
   <input id="multiLanguageYn" name="multiLanguageYn" type="hidden" value="N"/>
   <input id="localLang" name="localLang" type="hidden" value="id-id"/>
   <input id="runmodeInfo" name="runmodeInfo" type="hidden" value="live"/>
   <input id="apiStageInfo" name="apiStageInfo" type="hidden" value="front"/>
   <input id="tempTitle" name="tempTitle" type="hidden" value="page-buying-pd"/>
   <input id="siteCode" name="siteCode" type="hidden" value="id"/>
   <input id="store_sitecode" name="store_sitecode" type="hidden" value="id"/>
   <input id="language" name="language" type="hidden" value="in_ID"/>
   <input id="serverType" name="serverType" type="hidden" value="prod"/>
   <input id="gpvStoreDomain" name="gpvStoreDomain" type="hidden" value="https://p1.ecom.samsung.com"/>
   <input id="storeWebDomain" name="storeWebDomain" type="hidden" value="https://shop.samsung.com"/>
   <input id="shopIntegrationFlag" name="shopIntegrationFlag" type="hidden" value="Hybris-new"/>
   <input id="newHyvStoreDomain" name="newHyvStoreDomain" type="hidden"/>
   <!-- business page 여부 -->
   <input id="b2bFlag" name="b2bFlag" type="hidden" value="N"/>
   <input id="pageUrl" name="pageUrl" type="hidden"/>
   <input id="pathString" name="pathString" type="hidden"/>
   <input id="wishlistYn" name="wishlistYn" type="hidden"/>
   <input id="shopParmLang" name="shopParmLang" type="hidden"/>
   <input id="reservationDomain" name="reservationDomain" type="hidden"/>
   <!-- 공통  hidden input 끝-->
   <section class="progress cm-loader" style="display:none;">
    <div class="progress__wrapper">
     <div class="progress__circle-1">
     </div>
     <div class="progress__circle-2">
     </div>
     <div class="progress__circle-3">
     </div>
     <div class="progress__circle-4">
     </div>
    </div>
   </section>
   <!-- <script type="text/javascript" src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/js/crypto-js.min.js"></script> -->
   <script src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/global/js/crypto-js.min.6fa2276cf659f30cabde72a6fc452171.js">
   </script>
   <script src="https://account.samsung.com/resources/libs/account-internal/2.0.0/account-internal.min.js" type="text/javascript">
   </script>
   <header id="header" role="banner">
    <!--googleoff: all-->
    <div class="skip-bar">
     <a href="#content" id="skipToContent">
      Skip to content
     </a>
    </div>
    <div class="cookie-bar cookie-bar--type-manage" data-nosnippet="" role="status">
     <div class="cookie-bar__wrap">
      <div class="cookie-bar__msg-wrap">
       <div class="cookie-bar__msg">
        <p class="cookie-bar__title">
         <?php echo $BRANDS; ?> and Cookie
        </p>
        <p class="cookie-bar__desc">
         Website ini menggunakan cookie. Dengan mengklik TERIMA atau melanjutkan penelusuran website, Anda menyetujui penggunaan cookie kami.
         <a href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
          Lihat Kebijakan Privasi kami di sini.
         </a>
        </p>
        <button class="cookie-bar__desc-read-more-btn">
         Read More
        </button>
       </div>
       <div class="cookie-bar__manage">
        <a an-ac="cookie bar:accept" an-ca="other interaction" an-la="cookie bar:accept" an-tr="cod01_cookie bar-product detail-cta-button" class="cta cta--contained cta--emphasis" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>" title="Terima">
         Terima
        </a>
       </div>
      </div>
      <button an-ac="cookie bar:close" an-ca="other interaction" an-la="cookie bar:close" an-tr="cod01_cookie bar-product detail-cta-button" class="cookie-bar__close cookie-bar__main-close">
       <span class="hidden">
        close
       </span>
       <svg class="icon" focusable="false">
        <use xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </header>
   <div class="newpar new section">
   </div>
   <div class="par iparys_inherited">
   </div>
   <aside class="nv16-country-selector" style="height: 0px;">
    <div class="nv16-country-selector__content-wrap">
     <div class="nv16-country-selector__content">
      <label class="nv16-country-selector__description" for="countrySelect">
       Pilih lokasi dan bahasa Anda.
      </label>
      <div class="nv16-country-selector__select-contaniner" data-country-codes="uk">
       <div class="nv16-country-selector__menu">
        <div class="menu" data-comp-name="menu">
         <select class="menu__select" id="countrySelect" tabindex="-1">
          <option data-country-type="sitecd" selected="" value="id">
           Indonesia / Bahasa Indonesia
          </option>
          <option data-country-type="location" value="uk">
           UK / English
          </option>
          <option lang="en" value="other">
           Other Countries
          </option>
         </select>
         <button an-ac="gnb" an-ca="navigation" an-la="country selector" an-tr="nv16_gnb-country selector-navigation" aria-expanded="false" aria-haspopup="listbox" class="menu__select-field" data-aria-label="Pilih lokasi dan bahasa Anda." type="button">
          <span class="menu__select-field-text">
          </span>
          <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
           <use href="#open-down-bold" xlink:href="#open-down-bold">
           </use>
          </svg>
          <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
           <use href="#close-up-bold" xlink:href="#close-up-bold">
           </use>
          </svg>
         </button>
        </div>
       </div>
       <div class="nv16-country-selector__continue">
        <button an-ac="gnb" an-ca="navigation" an-la="country selector:continue" an-tr="nv16_gnb-country selector-navigation" class="cta cta--contained cta--black" data-action="countrySelectorContinue">
         Lanjutkan
        </button>
       </div>
      </div>
      <button class="nv16-country-selector__close" data-action="countrySelectorClose">
       <span class="hidden">
        Tutup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </aside>
   <!--# COD05_Mobile App Download Banner #-->
   <aside class="cod05-app-banner" style="display:none">
   </aside>
   <!--# //COD05_Mobile App Download Banner #-->
   <input id="st_checked" name="st_checked" type="hidden" value="2025-11-28 05:05:40"/>
   <input id="cck" name="cck" type="hidden" value="cedc6238tqcf1t4f0vl7g50mc70d6a5a"/>
   <input id="gPriceCurrency" name="gPriceCurrency" type="hidden" value="IDR"/>
   <input id="pageTrack" name="pageTrack" type="hidden" value="product detail"/>
   <nav aria-label="main navigation" class="nv00-gnb-v4 nv00-gnb-v4--text-type" id="component-id" role="navigation">
    <div class="nv00-gnb-v4__wrap">
     <div class="nv00-gnb-v4__inner">
      <div class="nv00-gnb-v4__header">
       <a an-ac="gnb" an-ca="navigation" an-la="samsung" an-tr="nv00_gnb-product detail-l0-navigation2" aria-label="Samsung" class="nv00-gnb-v4__logo" href="<?php echo $urlPath; ?>">
        <img src="https://i.ibb.co.com/NgkJJc18/happy-playing.png" alt="" width="130" height="50"/>
       </a>
       <div class="nv00-gnb-v4__utility-list nv00-gnb-v4--mobile-only">
        <button an-ac="gnb" an-ca="navigation" an-la="search" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-search gnb__search-btn-js" data-js-action="search">
         <span class="hidden">
          Cari
         </span>
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)">
          </path>
         </svg>
         <span aria-hidden="true" class="nv00-gnb-v4__search-text">
          Cari
         </span>
        </button>
        <a an-ac="gnb" an-ca="navigation" an-la="cart" an-tr="nv00_gnb-product detail-gnb cart icon-navigation6" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-cart nv00-gnb-v4__utility-btn js-global-cart-btn js-has-carturl" data-cart-url="https://shop.samsung.com/id/cart" href="https://shop.samsung.com/id/cart" role="button">
         <span class="hidden">
          Troli
         </span>
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <g clip-path="url(#clip-path)" transform="translate(-625.251 -196)">
           <path d="M697.237,263.578a10,10,0,1,1-10,10A10,10,0,0,1,697.237,263.578Zm-34.944,0a10,10,0,1,1-10,10A10,10,0,0,1,662.293,263.578Zm34.944,5a5,5,0,1,0,5,5A5,5,0,0,0,697.237,268.578Zm-34.944,0a5,5,0,1,0,5,5A5,5,0,0,0,662.293,268.578ZM638.1,197.25a3.86,3.86,0,0,1,3.6,2.652l.052.184,3.208,12.292h70.036a3.224,3.224,0,0,1,3.192,3.916l-.04.18-9.4,36.292a3.86,3.86,0,0,1-3.46,2.832l-.2.008h-51.1a3.866,3.866,0,0,1-3.6-2.648l-.052-.188-13.192-50.516-11.612,0,0-5Zm74.648,20.128h-66.48l8.672,33.228h49.2Z" transform="translate(0.834 3.75)">
           </path>
          </g>
         </svg>
         <span aria-live="polite" class="cart-in-number gnb-cart-count" style="display:none;">
          <span class="hidden">
           Number of Products :
          </span>
         </span>
        </a>
        <a an-ac="gnb" an-ca="account" an-la="login" an-tr="nv00_gnb-product detail-account-account" aria-label="Login/Sign-Up" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user before-login loginBtn" data-js-action="user" data-linkinfo="https://account.samsung.com/accounts/v1/DCGLID/signInGate">
         <span class="hidden">
          Login
         </span>
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.479,51.5,48,51.5Zm0,5c-13.772,0-25.5,11.595-25.5,24.555h0V87.5h51V81.055c0-12.831-11.494-24.323-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
          </path>
         </svg>
        </a>
        <a class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user after-login js-user-name js-account" data-js-action="user">
         <span class="hidden">
          Buka Menu Saya
         </span>
         <div class="image nv00-gnb-v4__user-profile js-gnb-afterlogin-image">
          <img alt="[D] Alternative Text" class="image__main" data-comp-name="image" role="img" src="#"/>
         </div>
         <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.479,51.5,48,51.5Zm0,5c-13.772,0-25.5,11.595-25.5,24.555h0V87.5h51V81.055c0-12.831-11.494-24.323-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
          </path>
         </svg>
        </a>
        <button an-ac="gnb" an-ca="navigation" an-la="gnb:open" an-tr="nv00_gnb-product detail-gnb open / close-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-hamburger" data-js-action="hamburger">
         <span class="hidden">
          Navigation
         </span>
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M0,57V52H70v5ZM0,31V26H70v5ZM0,5V0H70V5Z" transform="translate(13 20)">
          </path>
         </svg>
        </button>
       </div>
      </div>
      <div class="nv00-gnb-v4__container">
       <div class="nv00-gnb-v4__container-header nv00-gnb-v4--mobile-only">
        <button class="nv00-gnb-v4__backward-btn">
         <span class="hidden">
          Kembali
         </span>
         <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#previous-regular" xlink:href="#previous-regular">
          </use>
         </svg>
        </button>
        <button an-ac="gnb" an-ca="navigation" an-la="search" an-tr="nv00_gnb-product detail-l0-navigation5" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__search gnb__search-btn-js" data-js-action="search">
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)">
          </path>
         </svg>
         <span class="nv00-gnb-v4__search-text">
          Cari
         </span>
        </button>
       </div>
       <div class="nv00-gnb-v4__container-inner">
        <div class="nv00-gnb-v4__featured-wrap nv00-gnb-v4--mobile-only">
         <p class="nv00-gnb-v4__featured-title">
          FEATURED
         </p>
         <div class="nv00-gnb-v4__featured-list swiper-container basic-swiper" data-swiper-option='{
                "slidesPerView": "auto",
                "keepWrapper": true,
                "pagination":true,
                "offTxtAccesibility": true,
                "componentEl": ".nv00-gnb-v4"
            }'>
          <div class="nv00-gnb-v4__featured-list-inner swiper-wrapper" role="list">
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy z fold7" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/smartphones/galaxy-z-fold7/buy/">
             <div class="image">
              <img alt="Galaxy Z Fold7" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/f2507/gnb/Galaxy-Z_Fold7_GNB_L1_Shop_88x88.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Galaxy Z Fold7" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/f2507/gnb/Galaxy-Z_Fold7_GNB_L1_Shop_88x88.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy z fold7" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/smartphones/galaxy-z-fold7/buy/">
             Galaxy Z Fold7
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <span class="badge-icon badge-icon--label badge-icon--bg-color-blue">
             BARU
            </span>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy s25 fe" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/smartphones/galaxy-s25/buy/?modelCode=SM-S731BDBCXID">
             <div class="image">
              <img alt="Galaxy S25 FE" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/9/gnb/GNB_Shop_S25_FE_88x88.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Galaxy S25 FE" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/9/gnb/GNB_Shop_S25_FE_88x88.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy s25 fe" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/smartphones/galaxy-s25/buy/?modelCode=SM-S731BDBCXID">
             Galaxy S25 FE
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy tab s11 series" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/tablets/galaxy-tab-s11/buy/">
             <div class="image">
              <img alt="Galaxy Tab S11 Series" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/9/gnb/GNB_Shop_Tab_S11_88x88.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Galaxy Tab S11 Series" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/9/gnb/GNB_Shop_Tab_S11_88x88.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy tab s11 series" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/tablets/galaxy-tab-s11/buy/">
             Galaxy Tab S11
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy watch ultra" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/watches/galaxy-watch/galaxy-watch-ultra-2025-47mm-titanium-blue-bluetooth-sm-l700nzb1xse/buy/">
             <div class="image">
              <img alt="Galaxy Watch Ultra" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/8/watch-ultra-blue/GNB_L1_Mobile_Galaxy-Watche_Ultra_88x88-id.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Galaxy Watch Ultra" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/8/watch-ultra-blue/GNB_L1_Mobile_Galaxy-Watche_Ultra_88x88-id.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy watch ultra" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/watches/galaxy-watch/galaxy-watch-ultra-2025-47mm-titanium-blue-bluetooth-sm-l700nzb1xse/buy/">
             Galaxy Watch Ultra
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy buds3 fe" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/audio-sound/galaxy-buds/galaxy-buds3-fe-gray-sm-r420nzaaxse/">
             <div class="image">
              <img alt="Galaxy Buds3 FE" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/9/gnb/GNB_Shop_Buds3_FE_88x88.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Galaxy Buds3 FE" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/9/gnb/GNB_Shop_Buds3_FE_88x88.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:galaxy buds3 fe" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/audio-sound/galaxy-buds/galaxy-buds3-fe-gray-sm-r420nzaaxse/">
             Galaxy Buds3 FE
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:QLED 4K TV" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/tvs/qled-tv/qef1-65-inch-qled-4k-smart-tv-qa65qef1akxxd/">
             <div class="image">
              <img alt="QLED 4K Smart TV" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/QEF1_GNB_L1_88px.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="QLED 4K Smart TV" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/QEF1_GNB_L1_88px.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:QLED 4K TV" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/tvs/qled-tv/qef1-65-inch-qled-4k-smart-tv-qa65qef1akxxd/">
             QLED 4K TV
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:Crystal UHD 4K TV" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/tvs/uhd-4k-tv/ue100f-75-inch-crystal-uhd-4k-smart-tv-ua75ue100fkxxd/">
             <div class="image">
              <img alt="Crystal UHD 4K TV" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/UE100F-_GNB_L1_88px.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Crystal UHD 4K TV" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/UE100F-_GNB_L1_88px.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:Crystal UHD 4K TV" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/tvs/uhd-4k-tv/ue100f-75-inch-crystal-uhd-4k-smart-tv-ua75ue100fkxxd/">
             Crystal UHD 4K TV
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:the frame tv" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/lifestyle-tvs/the-frame/ls03f-75-inch-art-store-black-qa75ls03fakxxd/">
             <div class="image">
              <img alt="The Frame TV" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/The_Frame_GNB_L1_88px.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="The Frame TV" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/The_Frame_GNB_L1_88px.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:the frame tv" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/lifestyle-tvs/the-frame/ls03f-75-inch-art-store-black-qa75ls03fakxxd/">
             The Frame TV
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:q series soundbar" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/audio-devices/all-audio-devices/?q-series-home-theatre-soundbar">
             <div class="image">
              <img alt="Q-series Soundbar" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/revamp/gnb/shop/GNB_Shop_L1_12_88x88.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Q-series Soundbar" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/revamp/gnb/shop/GNB_Shop_L1_12_88x88.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:q series soundbar" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/audio-devices/all-audio-devices/?q-series-home-theatre-soundbar">
             Q-series Soundbar
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:Odyssey OLED G5" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/monitors/gaming/odyssey-oled-g5-g50sf-27-inch-180hz-oled-qhd-ls27fg502sexxd/">
             <div class="image">
              <img alt="Odyssey OLED G5" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/G50SF_GNB_L1_88px.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Odyssey OLED G5" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/G50SF_GNB_L1_88px.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:Odyssey OLED G5" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/monitors/gaming/odyssey-oled-g5-g50sf-27-inch-180hz-oled-qhd-ls27fg502sexxd/">
             Odyssey OLED G5
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:bespoke ai refrigerator 641l" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/refrigerators/side-by-side/bespoke-ai-refrigerator-sbs-family-hub-641l-black-doi-rs90f65anfse/">
             <div class="image">
              <img alt="Bespoke AI Refrigerator 641L " class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/7/offer/RS90F65A2FST_001_Front_Black-DOI_88px.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Bespoke AI Refrigerator 641L " class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/7/offer/RS90F65A2FST_001_Front_Black-DOI_88px.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:bespoke ai refrigerator 641l" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/refrigerators/side-by-side/bespoke-ai-refrigerator-sbs-family-hub-641l-black-doi-rs90f65anfse/">
             Bespoke AI Refrigerator 641L
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:front load washer and dryer" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/washers-and-dryers/washer-dryer-combo/wd6000t-front-load-combo-washer-dryer-21kg-black-wd21t6500gv-se/">
             <div class="image">
              <img alt="Front-load Washer &amp; Dryer with Ecobubble&trade;" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/WD21_GNB_L1_88px.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Front-load Washer &amp; Dryer with Ecobubble&trade;" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/WD21_GNB_L1_88px.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:front load washer and dryer" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/washers-and-dryers/washer-dryer-combo/wd6000t-front-load-combo-washer-dryer-21kg-black-wd21t6500gv-se/">
             Front-load Washer &amp; Dryer
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:vacuum cleaner" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/vacuum-cleaners/robot/?stick+canister">
             <div class="image">
              <img alt="Vacuum Cleaner Stick" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/VS80F_GNB_L1_88px.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="Vacuum Cleaner Stick" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/VS80F_GNB_L1_88px.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:vacuum cleaner" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/vacuum-cleaners/robot/?stick+canister">
             Vacuum Cleaner Stick
            </a>
           </div>
           <div class="nv00-gnb-v4__featured-item swiper-slide">
            <a an-ac="gnb" an-ca="navigation" an-la="shop:windfree ultra" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-thumb" href="https://www.samsung.com/id/air-conditioners/wall-mount/ar9500t-ar09axaaawknsk-windfree-ultra-metal-cooling-ar12cykaawknse/">
             <div class="image">
              <img alt="WindFree&trade; Ultra AC" class="image__preview lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/WindFree_GNB_L1_88px.png?$LazyLoad_Home_PNG$" role="img"/>
              <img alt="WindFree&trade; Ultra AC" class="image__main lazy-load-man" data-comp-name="image" data-src="//images.samsung.com/is/image/samsung/assets/id/offer/2025/11/gnb/WindFree_GNB_L1_88px.png?$ORIGIN_PNG$" role="img"/>
             </div>
            </a>
            <a an-ac="gnb" an-ca="navigation" an-la="shop:windfree ultra" an-tr="nv00_gnb-product detail-l1-navigation2" class="nv00-gnb-v4__featured-item-name" href="https://www.samsung.com/id/air-conditioners/wall-mount/ar9500t-ar09axaaawknsk-windfree-ultra-metal-cooling-ar12cykaawknse/">
             WindFree&trade; Ultra AC
            </a>
           </div>
          </div>
          <div class="screen-indicator-wrap">
           <button class="screen-indicator screen-indicator--prev">
            <div class="screen-indicator--icon">
             <span class="hidden">
              Previous
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#previous-regular" xlink:href="#previous-regular">
              </use>
             </svg>
            </div>
           </button>
           <button class="screen-indicator screen-indicator--next">
            <div class="screen-indicator--icon">
             <span class="hidden">
              Next
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#next-regular" xlink:href="#next-regular">
              </use>
             </svg>
            </div>
           </button>
          </div>
         </div>
        </div>
        <p class="nv00-gnb-v4__l0-menu-list-title nv00-gnb-v4--mobile-only">
         SHOP BY CATEGORY
        </p>
        <ul aria-label="main menu" class="nv00-gnb-v4__l0-menu-list nv00-gnb-v4__l0-menu-list--left" role="menubar">
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="shop" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="<?php echo $urlPath; ?>" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text nv00-gnb-v4--pc-only">
            <?php echo $BRANDS; ?>
            </span>
            <span class="nv00-gnb-v4__l0-menu-text nv00-gnb-v4--mobile-only">
             Explore Shop
            </span>
           </a>
           <button an-ac="gnb" an-ca="navigation" an-la="shop" an-tr="nv00_gnb-product detail-l0-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__l0-menu-toggle-btn" role="menuitem">
            <span class="hidden">
             Shop
            </span>
           </button>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="mobile" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="<?php echo $urlPath; ?>" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             SLOT GACOR
            </span>
           </a>
           <button an-ac="gnb" an-ca="navigation" an-la="mobile" an-tr="nv00_gnb-product detail-l0-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__l0-menu-toggle-btn" role="menuitem">
            <span class="hidden">
             Mobile
            </span>
           </button>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="tv and av" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="<?php echo $urlPath; ?>" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             SITUS TOTO 4D
            </span>
           </a>
           <button an-ac="gnb" an-ca="navigation" an-la="tv and av" an-tr="nv00_gnb-product detail-l0-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__l0-menu-toggle-btn" role="menuitem">
            <span class="hidden">
             SITUS TOTO 4D
            </span>
           </button>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="appliances" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="<?php echo $urlPath; ?>" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             TOTO
            </span>
           </a>
           <button an-ac="gnb" an-ca="navigation" an-la="appliances" an-tr="nv00_gnb-product detail-l0-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__l0-menu-toggle-btn" role="menuitem">
            <span class="hidden">
             TOTO
            </span>
           </button>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="monitors" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="<?php echo $urlPath; ?>" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             SITUS TOTO TOGEL
            </span>
           </a>
           <button an-ac="gnb" an-ca="navigation" an-la="monitors" an-tr="nv00_gnb-product detail-l0-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__l0-menu-toggle-btn" role="menuitem">
            <span class="hidden">
             SITUS TOTO TOGEL
            </span>
           </button>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="wearables" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="<?php echo $urlPath; ?>" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             LINK SLOT GACOR
            </span>
           </a>
           <button an-ac="gnb" an-ca="navigation" an-la="wearables" an-tr="nv00_gnb-product detail-l0-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__l0-menu-toggle-btn" role="menuitem">
            <span class="hidden">
             LINK SLOT GACOR
            </span>
           </button>
          </div>
         
         </li>
        </ul>
        <ul aria-label="main menu" class="nv00-gnb-v4__l0-menu-list nv00-gnb-v4__l0-menu-list--right" role="menubar">
         <!-- Type E Support Start -->
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <button an-ac="gnb" an-ca="navigation" an-la="support" an-tr="nv00_gnb-product detail-text l1-navigation2" class="nv00-gnb-v4__l0-menu-btn" data-js-action="l0MenuBtn" role="menuitem">
            Dukungan
           </button>
          </div>
          <div class="nv00-gnb-v4__l1-menu-container">
           <div class="nv00-gnb-v4__l1-menu-container-header nv00-gnb-v4--mobile-only">
            <p class="nv00-gnb-v4__l1-menu-container-title">
             Dukungan
            </p>
           </div>
          </div>
         </li>
         
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="for business" an-tr="nv00_gnb-product detail-banner-navigation2" aria-label="For Business. Buka di Tab Baru" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://www.samsung.com/id/business/" role="menuitem" target="_blank">
            For Business
           </a>
          </div>
         </li>
         <!-- Non-Type Right Menu End -->
        </ul>
        <div class="nv00-gnb-v4__user-menu-list nv00-gnb-v4--mobile-only before-login">
         <a data-linkinfo="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>" role="menuitem">
          Login/Sign-Up
         </a>
         <a an-ac="gnb" an-ca="account" an-la="rewards" an-tr="nv00_gnb-account-account" aria-label="Receive up to 5% of your purchase back in points. Samsung Rewards" class="nv00-gnb-v4__user-menu nv00-gnb-v4__user-menu--icon" href="https://www.samsung.com/id/rewards/" role="menuitem">
          Receive up to 5% of your purchase back in points.
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#next-regular" xlink:href="#next-regular">
           </use>
          </svg>
         </a>
        </div>
        <div class="nv00-gnb-v4__user-menu-list nv00-gnb-v4--mobile-only after-login">
         <a an-ac="gnb" an-ca="account" an-la="user name" an-tr="nv00_gnb-product detail-account-account" aria-label="Go to the another page" class="nv00-gnb-v4__user-menu js-user-name js-account" href="javascript:;" role="menuitem">
          <div class="image nv00-gnb-v4__user-profile js-gnb-afterlogin-image">
           <img alt="" class="image__main" data-comp-name="image" role="img" src="#"/>
          </div>
          <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewbox="0 0 96 96" width="96">
           <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.479,51.5,48,51.5Zm0,5c-13.772,0-25.5,11.595-25.5,24.555h0V87.5h51V81.055c0-12.831-11.494-24.323-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
           </path>
          </svg>
          <p class="user-name">
          </p>
          <p class="hidden">
           Buka Menu Saya
          </p>
         </a>
         <a an-ac="gnb" an-ca="account" an-la="rewards" an-tr="nv00_gnb-account-account" aria-label="Receive up to 5% of your purchase back in points. Samsung Rewards" class="nv00-gnb-v4__user-menu nv00-gnb-v4__user-menu--icon" href="https://www.samsung.com/id/rewards/" role="menuitem">
          Receive up to 5% of your purchase back in points.
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#next-regular" xlink:href="#next-regular">
           </use>
          </svg>
         </a>
        </div>
        <div class="nv00-gnb-v4__utility-list">
         <button an-ac="gnb" an-ca="navigation" an-la="search" an-tr="nv00_gnb-product detail-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-search gnb__search-btn-js" data-js-action="search">
          <span class="hidden">
           Cari
          </span>
          <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
           <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.483L89.268,85.732l-3.535,3.535ZM36.5,5A31.508,31.508,0,0,0,24.238,65.525,31.508,31.508,0,0,0,48.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)">
           </path>
          </svg>
          <span aria-hidden="true" class="nv00-gnb-v4__search-text">
           Cari
          </span>
         </button>
         <a an-ac="gnb" an-ca="navigation" an-la="cart" an-tr="nv00_gnb-product detail-gnb cart icon-navigation6" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-cart nv00-gnb-v4__utility-btn js-global-cart-btn js-has-carturl" data-cart-url="https://shop.samsung.com/id/cart" href="https://shop.samsung.com/id/cart" role="button">
          <span class="hidden">
           Troli
          </span>
          <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
           <g clip-path="url(#clip-path)" transform="translate(-625.251 -196)">
            <path d="M697.237,263.578a10,10,0,1,1-10,10A10,10,0,0,1,697.237,263.578Zm-34.944,0a10,10,0,1,1-10,10A10,10,0,0,1,662.293,263.578Zm34.944,5a5,5,0,1,0,5,5A5,5,0,0,0,697.237,268.578Zm-34.944,0a5,5,0,1,0,5,5A5,5,0,0,0,662.293,268.578ZM638.1,197.25a3.86,3.86,0,0,1,3.6,2.652l.052.184,3.208,12.292h70.036a3.224,3.224,0,0,1,3.192,3.916l-.04.18-9.4,36.292a3.86,3.86,0,0,1-3.46,2.832l-.2.008h-51.1a3.866,3.866,0,0,1-3.6-2.648l-.052-.188-13.192-50.516-11.612,0,0-5Zm74.648,20.128h-66.48l8.672,33.228h49.2Z" transform="translate(0.834 3.75)">
            </path>
           </g>
          </svg>
          <span aria-live="polite" class="cart-in-number gnb-cart-count" style="display:none;">
           <span class="hidden">
            Number of Products :
           </span>
          </span>
         </a>
         <div class="nv00-gnb-v4__utility-wrap before-login">
          <button an-ac="gnb" an-ca="navigation" an-la="login" an-tr="nv00_gnb-product detail-l0-navigation2" aria-expanded="false" aria-label="Manage Account" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user" data-js-action="user">
           <span class="hidden">
            Login/Sign-Up
           </span>
           <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
            <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.479,51.5,48,51.5Zm0,5c-13.772,0-25.5,11.595-25.5,24.555h0V87.5h51V81.055c0-12.831-11.494-24.323-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
            </path>
           </svg>
          </button>
          <div aria-label="account" class="nv00-gnb-v4__utility-menu-list" role="menu">
           <div class="nv00-gnb-v4__utility-menu-wrap">
            <a class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu--sign-in nv00-gnb-v4--pc-only"
              href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>"
              role="menuitem"
              target="_self"
              rel="noopener noreferrer"
              onclick="event.stopImmediatePropagation(); event.preventDefault(); window.location.href='https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>'; return false;">
              Login/Sign-Up
            </a>
            <a class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu--with-icon nv00-gnb-v4--pc-only" href="https://www.samsung.com/id/rewards/" role="menuitem">
             Receive up to 5% of your purchase back in points.
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#next-regular" xlink:href="#next-regular">
              </use>
             </svg>
            </a>
            <a an-ac="gnb" an-ca="account" an-la="orders" an-tr="nv00_gnb-product detail-account-account" aria-label="orders" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="http://shop.samsung.com/id/mypage/orders/" role="menuitem">
             Pesanan
            </a>
            <a an-ac="gnb" an-ca="account" an-la="Product Registration" an-tr="nv00_gnb-product detail-account-account" aria-label="Product Registration" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/id/mypage/myproducts/" role="menuitem">
             Product&nbsp;Registration
            </a>
            <a an-ac="gnb" an-ca="account" an-la="members" an-tr="nv00_gnb-product detail-account-account" aria-label="members" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/id/members/" role="menuitem">
             Members
            </a>
            <a an-ac="gnb" an-ca="account" an-la="samsung rewards" an-tr="nv00_gnb-product detail-account-account" aria-label="samsung rewards" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/id/rewards/" role="menuitem">
             Samsung&nbsp;Rewards
            </a>
           </div>
          </div>
         </div>
         <div class="nv00-gnb-v4__utility-wrap after-login">
          <button an-ac="gnb" an-ca="account" an-la="user name" an-tr="gnb-account, cart-product detail-account-account" aria-expanded="false" aria-label="Go to the another page" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user" data-js-action="user" role="button">
           <span class="hidden">
            Buka Menu Saya
           </span>
           <div class="image nv00-gnb-v4__user-profile js-gnb-afterlogin-image">
            <img alt="[D] Alternative Text" class="image__main" data-comp-name="image" role="img" src="#"/>
           </div>
           <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewbox="0 0 96 96" width="96">
            <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.479,51.5,48,51.5Zm0,5c-13.772,0-25.5,11.595-25.5,24.555h0V87.5h51V81.055c0-12.831-11.494-24.323-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
            </path>
           </svg>
          </button>
          <div aria-label="account" class="nv00-gnb-v4__utility-menu-list" role="menu">
           <div class="nv00-gnb-v4__utility-menu-wrap">
            <a an-ac="gnb" an-ca="account" an-la="user name" an-tr="gnb-account, cart-product detail-account-account" aria-label="Go to the another page" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu--user-profile nv00-gnb-v4--pc-only js-user-name js-account" href="javascript:;" role="menuitem">
             <div class="image nv00-gnb-v4__user-profile js-gnb-afterlogin-image">
              <img alt="[D] Alternative Text" class="image__main" data-comp-name="image" role="img" src="#"/>
             </div>
             <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewbox="0 0 96 96" width="96">
              <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.479,51.5,48,51.5Zm0,5c-13.772,0-25.5,11.595-25.5,24.555h0V87.5h51V81.055c0-12.831-11.494-24.323-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
              </path>
             </svg>
             <p class="user-name">
             </p>
            </a>
            <a class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu--with-icon nv00-gnb-v4--pc-only" href="https://www.samsung.com/id/rewards/" role="menuitem">
             Receive up to 5% of your purchase back in points.
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#next-regular" xlink:href="#next-regular">
              </use>
             </svg>
            </a>
            <a an-ac="gnb" an-ca="account" an-la="my page" an-tr="nv00_gnb-product detail-account-account" aria-label="my page" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/id/mypage/" role="menuitem">
             Halaman&nbsp;Saya
            </a>
            <a an-ac="gnb" an-ca="account" an-la="orders" an-tr="nv00_gnb-product detail-account-account" aria-label="orders" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="http://shop.samsung.com/id/mypage/orders/" role="menuitem">
             Pesanan
            </a>
            <a an-ac="gnb" an-ca="account" an-la="product registration" an-tr="nv00_gnb-product detail-account-account" aria-label="product registration" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/id/mypage/myproducts/" role="menuitem">
             Product&nbsp;Registration
            </a>
            <a an-ac="gnb" an-ca="account" an-la="my rewards" an-tr="nv00_gnb-product detail-account-account" aria-label="my rewards" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/id/mypage/rewards/" role="menuitem">
             Rewards&nbsp;Saya
            </a>
            <a an-ac="gnb" an-ca="account" an-la="wishlist" an-tr="nv00_gnb-product detail-account-account" aria-label="wishlist" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="http://shop.samsung.com/id/mypage/wishlist" role="menuitem">
             Wishlist
            </a>
            <a an-ac="gnb" an-ca="account" an-la="members" an-tr="nv00_gnb-product detail-account-account" aria-label="members" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/id/members/" role="menuitem">
             Members
            </a>
            <a an-ac="gnb" an-ca="account" an-la="community" an-tr="nv00_gnb-product detail-account-account" aria-label="community" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="http://r1.community.samsung.com/t5/Indonesia/ct-p/id?profile.language=in" role="menuitem">
             Komunitas
            </a>
            <a an-ac="gnb" an-ca="account" an-la="logout" an-tr="nv00_gnb-product detail-account-account" aria-label="logout" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu logoutBtn" href="javascript:;" role="menuitem">
             Keluar
            </a>
           </div>
          </div>
         </div>
        </div>
       </div>
       <button an-ac="gnb" an-ca="navigation" an-la="gnb:close" an-tr="nv00_gnb-product detail-gnb open / close-navigation2" class="nv00-gnb-v4__close-btn">
        <span class="hidden">
         Close menu
        </span>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
         </use>
        </svg>
       </button>
      </div>
     </div>
    </div>
    <div class="nv00-gnb-v4__dim">
    </div>
    <form action="https://account.samsung.com/accounts/v1/DCGLID/signInGate" id="signInForm" method="get" name="signInForm">
     <input id="response_type" name="response_type" type="hidden" value=""/>
     <input name="client_id" type="hidden" value="5kuj08631q"/>
     <input id="locale" name="locale" type="hidden" value=""/>
     <input name="countryCode" type="hidden" value="ID"/>
     <input id="redirect_uri" name="redirect_uri" type="hidden" value="/aemapi/v6/data-login/afterLogin.id.json"/>
     <input id="signInState" name="state" type="hidden" value=""/>
     <input id="signInGoBackURL" name="goBackURL" type="hidden" value=""/>
     <input id="scope" name="scope" type="hidden" value=""/>
    </form>
    <!-- SA 로그아웃호출 폼 -->
    <form action="https://account.samsung.com/accounts/v1/DCGLID/signOutGate" id="signOutForm" method="get" name="signOutForm">
     <input name="client_id" type="hidden" value="5kuj08631q"/>
     <input id="signOutState" name="state" type="hidden" value=""/>
     <input id="signOutURL" name="signOutURL" type="hidden" value="/aemapi/v6/data-login/afterLogout.id.json"/>
    </form>
    <!-- 회원가입 폼 -->
    <form action="https://account.samsung.com/membership/" id="joinForm" method="post" name="joinForm">
     <input name="actionID" type="hidden" value="SignupAP"/>
     <input name="serviceID" type="hidden" value="5kuj08631q"/>
     <input name="serviceName" type="hidden" value="SAMSUNG"/>
     <input name="domain" type="hidden" value=""/>
     <input name="countryCode" type="hidden" value="ID"/>
     <input name="languageCode" type="hidden" value="id"/>
     <input id="joinRegistURL" name="registURL" type="hidden" value="/aemapi/v6/data-login/afterLogin.id.json"/>
     <input id="joinReturnURL" name="returnURL" type="hidden"/>
     <input id="joinGoBackURL" name="goBackURL" type="hidden" value=""/>
     <input name="ssoType" type="hidden" value="ENC_TK"/>
     <input id="joinEmailActivationURL" name="emailActivationURL" type="hidden" value="/aemapi/v6/data-login/emailActivationURL.id.json"/>
    </form>
    <!-- Find Email 폼 -->
    <form action="https://account.samsung.com/membership/" id="findAccountForm" method="post" name="findAccountForm">
     <input name="actionID" type="hidden" value="FindEmail"/>
     <input name="serviceID" type="hidden" value="5kuj08631q"/>
     <input name="serviceName" type="hidden" value="SAMSUNG"/>
     <input name="domain" type="hidden" value=""/>
     <input name="countryCode" type="hidden" value="ID"/>
     <input name="languageCode" type="hidden" value="id"/>
     <input id="findGoBackURL" name="goBackURL" type="hidden" value=""/>
     <input name="ssoType" type="hidden" value="ENC_TK"/>
    </form>
    <!-- Account Modify Form -->
    <form action="https://account.samsung.com/membership/" id="accountModifyForm" method="post" name="accountModifyForm">
     <input name="actionID" type="hidden" value="ModifyUserInfo"/>
     <input name="serviceID" type="hidden" value="5kuj08631q"/>
     <input name="serviceName" type="hidden" value="SAMSUNG"/>
     <input name="domain" type="hidden" value=""/>
     <input name="countryCode" type="hidden" value="ID"/>
     <input name="languageCode" type="hidden" value="id"/>
     <input id="accountModifyGoBackURL" name="goBackURL" type="hidden" value=""/>
     <input name="ssoType" type="hidden" value="ENC_TK"/>
    </form>
    <form id="textForm" name="textForm">
     <input id="productCountText" name="productCountText" type="hidden" value="Jumlah Produk"/>
    </form>
    <input id="domain" name="domain" type="hidden" value="www.samsung.com"/>
    <input id="useLogin" name="useLogin" type="hidden" value="Y"/>
    <input id="useStore" name="useStore" type="hidden" value="Y"/>
    <input id="storeDomain" name="storeDomain" type="hidden" value="https://api.shop.samsung.com/"/>
    <input id="hybrisApiJson" name="hybrisApiJson" type="hidden"/>
    <input id="addToCartPostYn" name="addToCartPostYn" type="hidden" value="Y"/>
    <input id="tokocommercewebservicesYn" name="tokocommercewebservicesYn" type="hidden"/>
    <input id="useNewAddToCartApi" name="useNewAddToCartApi" type="hidden" value="Y"/>
    <input id="loginLinkURL" name="loginLinkURL" type="hidden" value="https://account.samsung.com/accounts/v1/DCGLID/signInGate"/>
    <input id="logoutURL" name="logoutURL" type="hidden" value="https://account.samsung.com/accounts/v1/DCGLID/signOutGate"/>
    <input id="updateProfileURL" name="updateProfileURL" type="hidden"/>
    <input id="isLoginWithNoStore" name="isLoginWithNoStore" type="hidden"/>
    <input id="countryCode" name="countryCode" type="hidden" value="ID"/>
    <input id="languageCode" name="languageCode" type="hidden" value="id"/>
    <input id="loginAccountServiceId" name="loginAccountServiceId" type="hidden" value="5kuj08631q"/>
    <input id="emailActivationURL" name="emailActivationURL" type="hidden" value="/aemapi/v6/data-login/emailActivationURL.id.json"/>
    <input id="shopIntegrationFlag" name="shopIntegrationFlag" type="hidden" value="Hybris-new"/>
    <input id="tieredPriceUseYn" name="tieredPriceUseYn" type="hidden"/>
    <input id="mySamsungRewardsTierType" name="mySamsungRewardsTierType" type="hidden" value="global"/>
    <input id="newMyRewardCurrencyConv" name="newMyRewardCurrencyConv" type="hidden" value="1.000"/>
    <input id="countryIsoCode" name="countryIsoCode" type="hidden" value="IDN"/>
    <input id="loginValidateYnForGPv2" name="loginValidateYnForGPv2" type="hidden" value=""/>
    <div class="nv00-gnb-v4__layer-popup-wrap">
     <div class="nv00-gnb-v4__layer-popup-looping--start" tabindex="0">
     </div>
     <div class="layer-popup gnb-layer_popup-js" id="layerEmptyCart">
      <svg aria-hidden="true" class="icon" focusable="false">
       <use href="#info-regular" xlink:href="#info-regular">
       </use>
      </svg>
      <p class="layer-popup__desc information-text">
       Keranjang belanja Anda kosong
      </p>
      <div class="layer-popup__cta-wrap">
       <button an-ac="cart is empty:OK" an-ca="other interaction" an-la="cart is empty:OK" an-tr="nv00_gnb-product detail-cart popup-other_interaction" aria-label="Accessibility Text" class="cta cta--contained cta--black gnb-js-layer-close" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);">
        OK
       </button>
      </div>
      <button class="layer-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="layer-popup gnb-layer_popup-js" id="layerInsufficientStock">
      <svg aria-hidden="true" class="icon" focusable="false">
       <use href="#info-regular" xlink:href="#info-regular">
       </use>
      </svg>
      <p class="layer-popup__desc information-text">
       Maaf, persediaan barang di keranjang belanja tidak cukup.
      </p>
      <div class="layer-popup__cta-wrap">
       <button aria-label="Accessibility Text" class="cta cta--contained cta--black gnb-js-layer-close" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);">
        OK
       </button>
      </div>
      <button class="layer-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="layer-popup gnb__remove-product gnb-layer_popup-js" id="layerRemoveProduct">
      <p class="layer-popup__title">
       Hapus produk
      </p>
      <p class="layer-popup__desc">
       Tanpa produk ini, kupon atau kode promo yang berlaku tidak dapat ditukarkan.
       <br/>
       Anda yakin ingin menghapus produk ini?
      </p>
      <div class="layer-popup__cta-wrap">
       <button aria-label="Accessibility Text" class="cta cta--outlined cta--black">
        Pindahkan ke wishlist
       </button>
       <button aria-label="Accessibility Text" class="cta cta--contained cta--black">
        Hapus
       </button>
      </div>
      <button class="layer-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="layer-popup gnb-layer_popup-js gnb__popup-privacy" id="layerPrivacy">
      <p class="layer-popup__title">
       Privacy Policy
      </p>
      <div class="layer-popup__checkbox-wrap">
       <div class="checkbox-v2">
        <input class="checkbox-v2__input" id="privacy-terms" name="checkbox" type="checkbox"/>
        <label class="checkbox-v2__label" for="privacy-terms">
         <span class="checkbox-v2__label-box-wrap">
          <span class="checkbox-v2__label-box">
           <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
            <use href="#done-bold" xlink:href="#done-bold">
            </use>
           </svg>
          </span>
         </span>
         <span class="checkbox-v2__label-text">
          Saya telah membaca dan setuju dengan
          <a class="link-text" href="https://www.samsung.com/id/info/privacy/" target="_blank" title="Buka di Tab Baru">
           Kebijakan Privasi
          </a>
          Samsung.com
         </span>
        </label>
       </div>
       <p class="layer-popup__checkbox-desc error" id="errorPrivacy">
        Centang kotak ini untuk melanjutkan ke Samsung.com.
       </p>
       <div class="checkbox-v2">
        <input class="checkbox-v2__input" id="privacy-terms2" name="checkbox" type="checkbox"/>
        <label class="checkbox-v2__label" for="privacy-terms2">
         <span class="checkbox-v2__label-box-wrap">
          <span class="checkbox-v2__label-box">
           <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
            <use href="#done-bold" xlink:href="#done-bold">
            </use>
           </svg>
          </span>
         </span>
         <span class="checkbox-v2__label-text">
          Dengan mencentang kotak ini, berarti saya bersedia menerima Pembaruan Layanan Samsung, termasuk:
         </span>
        </label>
       </div>
       <p class="layer-popup__checkbox-desc">
        Layanan dan informasi pemasaran Samsung.com, berikut produk baru dan pengumuman layanan serta penawaran khusus, peristiwa dan buletin berkalanya.
       </p>
      </div>
      <div class="layer-popup__cta-wrap">
       <button aria-label="Accessibility Text" class="cta cta--outlined cta--black" id="privacyBtn">
        MELANJUTKAN KE SAMSUNG.COM
       </button>
       <button aria-label="Accessibility Text" class="cta cta--contained cta--black login-leave-btn" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);">
        TINGGALKAN HALAMAN INI
       </button>
      </div>
      <button class="layer-popup__close login-leave-btn" data-focus-id="shop-popover-close" data-tab-disable="true">
       <span class="hidden">
        Tutup Kebijakan Privasi
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="layer-popup gnb__popup-privacy gnb-layer_popup-js" id="layerPreference">
      <p class="layer-popup__title">
       Periksa Preferensi
      </p>
      <p class="layer-popup__desc">
       Berikan rekomendasi untuk memperbaharui preferensi produk Anda.
      </p>
      <div class="layer-popup__cta-wrap">
       <button aria-label="Accessibility Text" class="cta cta--outlined cta--black" id="preferenceCheckBtn">
        YA
       </button>
       <button aria-label="Accessibility Text" class="cta cta--contained cta--black" id="privacyCloseBtn" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);">
        NANTI
       </button>
      </div>
      <button class="layer-popup__close" data-focus-id="shop-popover-close" data-tab-disable="true">
       <span class="hidden">
        Tutup Preferensi
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="nv00-gnb-v4__layer-popup-looping--end" tabindex="0">
     </div>
    </div>
   </nav>
   <input id="sc_gnb_searchURL" name="sc_gnb_searchURL" type="hidden" value="/id/aisearch"/>
   <input id="sc_gnb_AI_searchURL" name="sc_gnb_AI_searchURL" type="hidden" value="/id/aisearch"/>
   <input id="sc_gnb_placeholder" name="sc_gnb_placeholder" type="hidden" value="Galaxy Z Fold7"/>
   <input id="sc_gnb_aiSearchUseYn" name="sc_gnb_aiSearchUseYn" type="hidden" value="Y"/>
   <input id="sc_gnb_bdcApiUseYn" name="sc_gnb_bdcApiUseYn" type="hidden" value="Y"/>
   <input id="sc_gnb_AiLoginUseYn" name="sc_gnb_AiLoginUseYn" type="hidden" value="N"/>
   <input id="sc_gnb_eppUseGnbAiSearchYn" name="sc_gnb_eppUseGnbAiSearchYn" type="hidden"/>
   <input id="eppFlag" name="eppFlag" type="hidden" value="N"/>
   <section aria-modal="true" class="srd19-gnb-search" role="dialog">
    <div class="srd19-gnb-search__looping--start" tabindex="0">
    </div>
    <div class="srd19-gnb-search__contents">
     <form action="#" autocomplete="off" class="srd19-gnb-search__form" role="search">
      <fieldset>
       <legend>
        Search Form
       </legend>
       <button aria-label="Cari" class="srd19-gnb-search__btn-search" type="submit">
        <svg class="icon" focusable="false">
         <use href="#search-regular" xlink:href="#search-regular">
         </use>
        </svg>
       </button>
       <div class="srd19-gnb-search__input-wrap">
        <input aria-label="Cari" class="srd19-gnb-search__input" id="gnb-search-keyword" name="search" placeholder="Cari" type="text"/>
       </div>
       <button an-ac="search layer" an-ca="search" an-la="clear" an-tr="srd19_gnb search-product detail-delete-search" class="srd19-gnb-search__clear" type="button">
        <span class="text">
         Kosongkan
        </span>
       </button>
       <button class="srd19-gnb-search__scan-barcode srd19-gnb-search__scan-barcode--hide" type="button">
        <span class="hidden">
         Scan Barcode
        </span>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#barcode-regular" xlink:href="#barcode-regular">
         </use>
        </svg>
       </button>
      </fieldset>
     </form>
     <div class="srd19-gnb-search__result-wrap">
      <div class="srd19-gnb-search__result">
       <div class="srd19-gnb-search__searches">
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__no-suggestions srd19-gnb-search__list-wrap--hide">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           Tidak Ada Saran
          </p>
         </div>
        </div>
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__ai-search srd19-gnb-search__list-wrap--hide">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           AI Suggested Searches
          </p>
         </div>
         <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
         </ul>
        </div>
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__suggested srd19-gnb-search__list-wrap--hide">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           Pencarian yang Disarankan
          </p>
         </div>
         <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
         </ul>
        </div>
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__popular">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           PENCARIAN POPULER
          </p>
         </div>
         <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
         </ul>
        </div>
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__recent srd19-gnb-search__list-wrap--hide">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           PENCARIAN TERBARU
          </p>
         </div>
         <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
         </ul>
        </div>
       </div>
       <div class="srd19-gnb-search__thumb srd19-gnb-search__related srd19-gnb-search__list-wrap--hide">
        <div class="srd19-gnb-search__thumb-title-wrap">
         <p class="srd19-gnb-search__thumb-title" id="rec-label">
          PRODUK TERKAIT
         </p>
        </div>
        <ul aria-labelledby="rec-label" class="srd19-gnb-search__thumb-list" role="menu">
        </ul>
       </div>
       <div class="srd19-gnb-search__thumb srd19-gnb-search__recommended">
        <div class="srd19-gnb-search__thumb-title-wrap">
         <p class="srd19-gnb-search__thumb-title" id="rec-label">
          DIREKOMENDASIKAN
         </p>
        </div>
        <ul aria-labelledby="rec-label" class="srd19-gnb-search__thumb-list" role="menu">
        </ul>
       </div>
      </div>
     </div>
     <button an-ac="search layer" an-ca="search" an-la="close" an-tr="srd19_gnb search-product detail-close-search" class="srd19-gnb-search__close" type="button">
      <span class="hidden">
       Tutup
      </span>
      <svg class="icon" focusable="false">
       <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
       </use>
      </svg>
     </button>
    </div>
    <div aria-hidden="true" class="srd19-gnb-search__dimmed">
    </div>
    <div class="srd19-gnb-search__looping--end" tabindex="0">
    </div>
   </section>
   <!--googleon: all-->
   <div class="st-page-pd" id="content" role="main">
    <input id="isNotDelTagSites" name="isNotDelTagSites" type="hidden" value="N"/>
    <input id="isExposeExtraRewardsSites" name="isExposeExtraRewardsSites" type="hidden" value="N"/>
    <input id="modelCode" name="modelCode" type="hidden" value="MS-F813QBDUIDZ"/>
    <input id="categorySubSubTypeCode" name="categorySubSubTypeCode" type="hidden"/>
    <input id="categorySubTypeCode" name="categorySubTypeCode" type="hidden" value="01010400"/>
    <input id="categoryTypeCode" name="categoryTypeCode" type="hidden" value="01010000"/>
    <input id="typeCodeForGNB" name="typeCodeForGNB" type="hidden" value="01010000"/>
    <input id="groupCodeForGNB" name="groupCodeForGNB" type="hidden" value="01000000"/>
    <input id="categoryGroupCode" name="categoryGroupCode" type="hidden" value="01000000"/>
    <input id="emiUrl" name="emiUrl" type="hidden" value="/id/web/emi"/>
    <input id="financingUrl" name="financingUrl" type="hidden" value="/id/web/si-calculator"/>
    <input id="categoryname" name="categoryname" type="hidden"/>
    <input id="modelName" name="modelName" type="hidden" value="SM-A075F/DS"/>
    <input id="useNewWtb" name="useNewWtb" type="hidden" value="Y"/>
    <input id="priceCurrency" name="priceCurrency" type="hidden" value="idr"/>
    <input id="gpvGetTypeCheck" name="gpvGetTypeCheck" type="hidden" value="Y"/>
    <input id="isPreqa" name="isPreqa" type="hidden" value="false"/>
    <input id="typeux2025" name="typeux2025" type="hidden" value="Y"/>
    <div class="pd-g-product-promotion-bar">
    </div>
    <div class="pd-g-product-detail-offer-banner">
     <section class="pd-banner" data-fold-data='{"bgColor": "#f7f7f7", "textColor": "black"}' data-prefold-data='{"bgColor": "", "textColor": ""}' data-preunfold-data='{"bgColor": "", "textColor": ""}' data-unfold-data='{"bgColor": "#f7f7f7", "textColor": "black"}' style="display:none;">
      <div class="pd-banner__inner" data-end-text="Selesai di" data-end-time="203012310000Z" data-start-text="Mulai di">
       
        <div class="pd-banner__content-wrap">
         <div class="pd-banner__content">
          <h2 class="pd-banner__headline">
           Dapatkan gratis hadiah
          </h2>
          <div class="pd-banner__desc-wrap">
           <p class="pd-banner__desc">
            - Gratis hadiah Travel Adapter 25W dan Case A07 (Stock Terbatas)
            <br/>
            - Bayar cuman Rp559.300 dengan menambahkan Buds Core ke troli Anda!
            <br/>
            - Samsung Care+ proteksi diskon 30%
            <br/>
            <br/>
            Periode: 14 November - 10 Desember 2025
           </p>
           <div class="pd-banner__image-mo">
            <div class="image">
             <img alt="Dapatkan gratis hadiah" class="image__preview lazy-load" data-comp-name="image" data-src="?$144_80_PNG$" role="img"/>
             <img alt="Dapatkan gratis hadiah" class="image__main lazy-load" data-comp-name="image" data-src="?$144_80_PNG$" role="img"/>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <a an-ac="view more" an-ca="indication" an-la="view more" an-tr="pdd11_offer banner-product detail-image-arrow" aria-expanded="false" class="pd-banner__toggle" href="javascript:void(0)" role="button">
        <svg class="icon icon--open" focusable="false">
         <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-regular">
         </use>
        </svg>
        <svg class="icon icon--close" focusable="false">
         <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-regular">
         </use>
        </svg>
        <span class="pd-banner__toggle-open-text hidden">
         Buka Info Lebih Lanjut
        </span>
        <span class="pd-banner__toggle-close-text hidden">
         Tutup Info Lebih Lanjut
        </span>
       </a>
      </div>
     </section>
    </div>
    
           
           </div>
          </div>
         </div>
        </div>
        <div class="pdd39-anchor-nav__price pd-buying-price" id="sgDevPriceAreaBase">
         <div class="price-ux__wrap pd-buying-price__wrap">
          <div id="sgDevPriceArea">
          </div>
          <div class="pdd39-anchor-nav__cta pd-buying-price__cta">
          </div>
         </div>
        </div>
        <!--googleoff: all-->
        <div class="sdf-component-templates">
         <div class="pdd39-anchor-nav__price pd-buying-price" data-sdf-template="priceBox @ price" data-sdf-unwrap="true">
          <div class="price-ux__wrap pd-buying-price__wrap">
           <div class="pd-buying-price__inner">
            <p class="pd-buying-price__advice-price" data-sdf-test="{{priceAnchor.priceWrapper.info.noLineOrignal}}">
             {{priceAnchor.priceWrapper.info.noLineOrignal}}
            </p>
            <div class="pd-buying-price__new-price" data-sdf-test="{{priceAnchor.priceWrapper.info.totalPrice}}">
             <div class="pd-buying-price__new-price-inner">
              <?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !
             </div>
             <span class="pd-buying-price__monthly-price" data-sdf-test="{{priceAnchor.priceWrapper.info.totalPriceMonthly}}">
              {{priceAnchor.priceWrapper.info.totalPriceMonthly}}
             </span>
            </div>
            <div class="pd-buying-price__box">
             <p class="pd-buying-price__trade-in" data-sdf-test="{{priceAnchor.priceWrapper.info.ceExchangePrice}}">
              {{priceAnchor.priceWrapper.info.ceExchangePrice}}
             </p>
             <div class="pd-buying-price__tax" data-sdf-test="{{priceAnchor.priceWrapper.info.orignalPriceAddText}}">
              {{priceAnchor.priceWrapper.info.orignalPriceAddText}}
             </div>
             <div class="pd-buying-price__label" data-sdf-test="{{priceAnchor.priceWrapper.info.lowestWasPricetext}}">
              {{priceAnchor.priceWrapper.info.lowestWasPricetext}}
             </div>
             <div class="pd-buying-price__was" data-sdf-test="{{priceAnchor.priceWrapper.info.orignalPrice}}">
              <span class="hidden">
               Harga awal:
              </span>
              {{priceAnchor.priceWrapper.info.orignalPrice}}
             </div>
             <div class="pd-buying-price__save" data-sdf-test="{{priceAnchor.priceWrapper.info.savePrice}}">
              {{priceAnchor.priceWrapper.info.savePrice}}
             </div>
             <div class="pd-buying-price__disclaimer" data-sdf-test="{{priceAnchor.priceWrapper.info.disclaimer}}">
              {{priceAnchor.priceWrapper.info.disclaimer}}
             </div>
            </div>
           </div>
           <div class="pdd39-anchor-nav__cta pd-buying-price__cta">
            <a href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>" class="cta cta--contained cta--emphasis cta--2line add-special-tagging">
             Masuk
            </a>
            <a href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>" class="cta cta--contained cta--emphasis cta--2line add-special-tagging">
             Daftar
            </a>
           </div>
          </div>
         </div>
        </div>
        <!--googleon: all-->
       </div>
       <input id="featureYN" name="featureYN" type="hidden" value="Y"/>
       <div class="pdd39-anchor-nav__menu">
        <div class="tab" data-auto-init="false" data-comp-name="tab" data-use-arrow="" data-use-arrow-mo="">
         <div class="tab__left-arrow-wrap">
          <button aria-label="previous" class="tab__left-arrow disabled" role="button" type="button">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#previous-regular" xlink:href="#previous-regular">
            </use>
           </svg>
          </button>
         </div>
         <input id="featureAnchorListYn" name="featureAnchorListYn" type="hidden" value="N"/>
         <ul class="tab__list" id="anchor-menu-list" role="tablist">
          <li class="tab__item" id="benefitWrap" role="presentation" style="display: none; margin-left: 0;">
           <a an-ac="anchor navi" an-ca="navigation" an-la="anchor navi:features" an-tr="pdd39_anchor nav v3-product detail-sub navi-navigation" aria-label="Fitur" class="tab__item-title" href="#features">
            Fitur
            <span class="tab__item-line">
            </span>
           </a>
          </li>
         </ul>
         <div class="tab__right-arrow-wrap disabled">
          <button aria-label="next" class="tab__right-arrow" role="button" type="button">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#next-regular" xlink:href="#next-regular">
            </use>
           </svg>
          </button>
         </div>
        </div>
       </div>
      </div>
      <div class="pdd39-anchor-nav__header-dummy">
      </div>
     </div>
     <div class="sg-component" id="navProperties" style="display:none;">
      <input id="navPriceDisplayYn" type="hidden" value="Y"/>
      <input id="navShopServiceYn" type="hidden"/>
      <input id="navPackageYn" type="hidden" value="N"/>
      <input id="thirdPartyPrdYN" type="hidden" value="N"/>
      <input id="tenantId" type="hidden" value="idn"/>
      <input id="pdType" type="hidden" value="S-B"/>
      <input id="navOldProductYn" type="hidden" value="N"/>
      <input id="shopSKU" type="hidden" value="MS-F813QBDUIDZ"/>
      <input id="wtbUseYn" type="hidden" value="N"/>
      <input id="pdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/"/>
      <input id="ctaType" type="hidden" value="INSTOCK"/>
      <input id="marketingPdpYN" type="hidden" value="N"/>
      <input id="familyCode" type="hidden" value="561454"/>
      <input id="tellsomeYn" type="hidden" value="N"/>
      <input id="navDisplayName" type="hidden" value="Galaxy A07"/>
      <input id="navPageTrack" type="hidden" value="product detail"/>
      <input id="current-page-nav" name="current-page-nav" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy"/>
      <input id="navConfiguratorUrl" type="hidden"/>
      <input id="navCtaLocalText" type="hidden"/>
      <input id="navCtaEngText" type="hidden"/>
      <input id="navConfiguratorUseYn" type="hidden" value="N"/>
      <input id="navDetailRootNodePath" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy.dynamic"/>
     </div>
    </div>
    <div class="pd-g-product-detail-header-ux2">
     <div class="add-ons-evoucher-popup" style="display:none">
      <div class="layer-popup" id="freeGiftPopup" role="dialog" style="display:block" tabindex="0">
       <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
         <div class="add-ons-evoucher-popup__contents scrollbar__contents">
          <div class="add-ons-evoucher-popup__wrap">
           <div class="add-ons-evoucher-popup__head">
            <h2 class="layer-popup__title">
            </h2>
           </div>
           <div class="add-ons-evoucher-popup__body">
            <ul class="add-ons-evoucher-popup__list">
            </ul>
           </div>
          </div>
         </div>
        </div>
        <div class="add-ons-evoucher-popup__button">
         <div class="add-ons-evoucher-popup__button-item">
          <button aria-disabled="true" aria-label="Out of Stock" class="cta cta--contained cta--black cta--disabled">
           Out of Stock
          </button>
         </div>
        </div>
        <button class="layer-popup__close" type="button">
         <span class="hidden">
          Tutup Layar Popup
         </span>
         <svg class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
         </svg>
        </button>
       </div>
      </div>
     </div>
     <!-- <div class="component-area" style=""> -->
     <section class="pdd16-step-buying" id="pdd16-step-buying" style="display:none;">
      <div class="pdd16-step-buying__header">
       <div class="pdd16-step-buying__header-wrap">
        <div class="pdd16-step-buying__header-title">
         <div class="image">
          <img class="image__preview lazy-load responsive-img" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$"/>
          <img class="image__main lazy-load responsive-img" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$"/>
         </div>
         <div class="pdd16-step-buying__header-text">
          <strong>
           Galaxy A07
          </strong>
          <!-- <div class="pdd16-step-buying__tooltip">Galaxy A07</div> -->
         </div>
         <div class="pdd16-step-buying__quantity">
          <strong>
          </strong>
         </div>
        </div>
        <div aria-live="polite" class="pdd16-step-buying__add-on-list swiper-container basic-swiper" data-swiper-option='{
            "componentEl":".pdd16-step-buying__add-on-list",
            "keepWrapper": true,
            "offSlideAccessibility":true,
            "followFinger": false,
            "slidesPerView":"auto"
          }' style="display:none;">
         <button class="swiper-button-prev" type="button">
          <span class="hidden">
           Previous
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#previous-regular" xlink:href="#previous-regular">
           </use>
          </svg>
         </button>
         <div class="swiper-wrapper" role="list">
         </div>
         <button class="swiper-button-next" type="button">
          <span class="hidden">
           Next
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#next-regular" xlink:href="#next-regular">
           </use>
          </svg>
         </button>
        </div>
        <!-- (2022.08.11 수정) p.pdd16-step-buying__header-price-text => div 태그로 수정 -->
        <div class="pdd16-step-buying__header-price">
         <div class="pdd16-step-buying__header-price-text">
          <strong>
           from &pound;55.53/mo for 36 mos
          </strong>
          or &pound;3,299.00
          <!-- (2022.08.11 수정) Was Price, Save Price 있는 경우 .pdd16-step-buying__header-price-save 추가 -->
          <div class="pdd16-step-buying__header-price-save">
           <del class="was-text">
            &pound;2,399.00
           </del>
           <span class="sale-text">
            save $ &pound;400.00
           </span>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="pdd16-step-buying__header__dummy">
      </div>
      <!-- (2022.08.11 수정) .pdd16-step-buying__promotion-banner 추가 -->
      <div class="pdd16-step-buying__promotion-banner">
       <svg class="icon" focusable="false">
        <use href="#deal-bold" xlink:href="#deal-bold">
        </use>
       </svg>
       <p class="pdd16-step-buying__promotion-banner-text">
       </p>
      </div>
      <div class="pdd16-step-buying__contents">
       <p class="pdd16-step-buying__headline">
        Tambahan Menarik Lainnya
       </p>
       <h3 class="pdd16-step-buying__sub-headline" style="display:none;">
       </h3>
       <div class="pdd16-step-buying__evoucher" style="display:none;">
        <div class="pdd16-step-buying__evoucher-wrap">
         <ul class="pdd16-step-buying__evoucher-list">
          <li class="pdd16-step-buying__evoucher-item">
           <span class="pdd16-step-buying__evoucher-title">
            Selected Items(
            <span>
            </span>
            )
           </span>
           <p class="pdd16-step-buying__evoucher-content" id="selectedItem">
           </p>
           <input id="voucherTotal" type="hidden" value="0"/>
          </li>
          <li class="pdd16-step-buying__evoucher-item">
           <span class="pdd16-step-buying__evoucher-title">
            Saldo eVoucher saya
           </span>
           <p class="pdd16-step-buying__evoucher-content" id="voucherBalance">
           </p>
          </li>
          <li class="pdd16-step-buying__evoucher-item">
           <span class="pdd16-step-buying__evoucher-title">
            Biaya Tambahan
           </span>
           <p class="pdd16-step-buying__evoucher-content" id="voucherCharge">
           </p>
          </li>
         </ul>
        </div>
        <div class="pdd16-step-buying__evoucher-cta">
         <button aria-label="Clear All" class="cta cta--underline cta--black cta--icon cta--clear-all">
          Clear All
          <svg class="icon" focusable="false">
           <use href="#delete-bold" xlink:href="#delete-bold">
           </use>
          </svg>
         </button>
        </div>
       </div>
       <div class="pdd16-step-buying__tab-wrap">
        <div class="tab bg-light-gray" data-use-arrow="">
         <div class="tab__left-arrow-wrap disabled">
          <button aria-label="previous" class="tab__left-arrow" role="button" type="button">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#previous-regular" xlink:href="#previous-regular">
            </use>
           </svg>
          </button>
         </div>
         <ul class="tab__list" role="tablist">
          <li class="tab__item" role="presentation">
           <button class="tab__item-title" role="tab">
            <span class="tab__item-line">
            </span>
           </button>
          </li>
          <li class="tab__item" role="presentation">
           <button class="tab__item-title" role="tab">
            <span class="tab__item-line">
            </span>
           </button>
          </li>
          <li class="tab__item" role="presentation">
           <button class="tab__item-title" role="tab">
            <span class="tab__item-line">
            </span>
           </button>
          </li>
         </ul>
         <div class="tab__right-arrow-wrap disabled">
          <button aria-label="next" class="tab__right-arrow" role="button" type="button">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#next-regular" xlink:href="#next-regular">
            </use>
           </svg>
          </button>
         </div>
        </div>
        <div aria-live="polite" class="pdd16-step-buying__card-wrap swiper-container basic-swiper" data-swiper-option='{
          "slidesPerView":1,
          "autoHeight":true,
          "pagination":false,
          "componentEl":".pdd16-step-buying__card-wrap",
          "watchOverflow":true,
          "offTxtAccesibility":"true"
          }'>
         <div class="swiper-wrapper">
          <div class="pdd16-step-buying__tab pdd16-step-buying__2column swiper-slide">
           <div class="pdd16-step-buying__list-type">
            <a aria-label="2column" class="btn-type on">
             <svg class="icon" focusable="false" viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 0H16V16H0z" fill="none" transform="translate(-344 -388) translate(344 388)">
              </path>
              <g>
               <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(344 388)">
               </path>
               <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(344 394.649)">
               </path>
               <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(350.65 388)">
               </path>
               <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(350.65 394.649)">
               </path>
              </g>
             </svg>
            </a>
            <a aria-label="1column" class="btn-type">
             <svg class="icon" focusable="false" viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 0H16V16H0z" fill="none" transform="translate(349 388) translate(-349 -388)">
              </path>
              <g>
               <path class="cls-2" d="M.652 0h10.7A.681.681 0 0 1 12 .764v3.822a.681.681 0 0 1-.652.764H.652A.681.681 0 0 1 0 4.586V.764A.681.681 0 0 1 .652 0z" transform="translate(344 388.732) translate(7 1.268) translate(-349 -388)">
               </path>
               <path class="cls-2" d="M.652 0h10.7A.681.681 0 0 1 12 .764v3.822a.681.681 0 0 1-.652.764H.652A.681.681 0 0 1 0 4.586V.764A.681.681 0 0 1 .652 0z" transform="translate(344 395.732) translate(7 1.268) translate(-349 -388)">
               </path>
              </g>
             </svg>
            </a>
           </div>
           <div class="scrollbar">
            <div class="scrollbar__contents">
             <div class="pdd16-step-buying__view-more">
              <button aira-label="View more" class="cta" type="button">
               <svg class="icon next" focusable="false">
                <use href="#next-bold" xlink:href="#next-bold">
                </use>
               </svg>
               <span class="cta-text">
                Lihat selengkapnya
               </span>
               <svg class="icon down" focusable="false">
                <use href="#open-down-bold" xlink:href="#open-down-bold">
                </use>
               </svg>
              </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <div class="pdd16-step-buying__disclaimer" style="display:none">
          <p>
          </p>
         </div>
         <div class="pdd16-step-buying__footer pdd16-step-buying__footer--fixed">
          <div class="pdd16-step-buying__footer-price">
           <p class="pdd16-step-buying__footer-text">
            <strong>
             Total
            </strong>
            VAT Inclusive
           </p>
           <p class="pdd16-step-buying__footer-sum">
            <strong>
             From $107.50/mo
            </strong>
            for most at 0% APR
            <br/>
            or $2,579.96
           </p>
          </div>
         </div>
         <div class="pdd16-step-buying__footer__dummy">
         </div>
        </div>
       </div>
      </div>
      <div aria-modal="true" class="pdd16-step-buying__layer-learn-more" id="layerPopupLearnMore" role="dialog" tabindex="0">
       <div class="layer-popup">
        <div class="layer-popup__inner">
         <h2 class="layer-popup__title">
         </h2>
         <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__contents">
           <div class="pdd16-step-buying__learn-more-images">
           </div>
           <div class="pdd16-step-buying__learn-more-content">
           </div>
          </div>
         </div>
         <button class="layer-popup__close" type="button">
          <span class="hidden">
           Layer Popup Close
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#delete-bold" xlink:href="#delete-bold">
           </use>
          </svg>
         </button>
        </div>
       </div>
      </div>
     </section>
     <!--  </div> -->
     <div class="add-ons-evoucher-popup" style="display:none">
      <div class="layer-popup" id="freeGiftPopup" role="dialog" style="display:block" tabindex="0">
       <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
         <div class="add-ons-evoucher-popup__contents scrollbar__contents">
          <div class="add-ons-evoucher-popup__wrap">
           <div class="add-ons-evoucher-popup__head">
            <h2 class="layer-popup__title">
            </h2>
           </div>
           <div class="add-ons-evoucher-popup__body">
            <ul class="add-ons-evoucher-popup__list">
            </ul>
           </div>
          </div>
         </div>
        </div>
        <div class="add-ons-evoucher-popup__button">
         <div class="add-ons-evoucher-popup__button-item">
          <button aria-disabled="true" aria-label="Out of Stock" class="cta cta--contained cta--black cta--disabled">
           Out of Stock
          </button>
         </div>
        </div>
        <button class="layer-popup__close" type="button">
         <span class="hidden">
          Tutup Layar Popup
         </span>
         <svg class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
         </svg>
        </button>
       </div>
      </div>
     </div>
     <section class="pdd16-step-buying-v2 pdd16-step-buying-v2--add-ons" id="pdd16-step-buying-v2" style="display:none;">
      <div class="pdd16-step-buying-v2__contents">
       <h2 class="pdd16-step-buying-v2__headline">
       </h2>
       <h3 class="pdd16-step-buying-v2__sub-headline">
       </h3>
       <div class="pdd16-step-buying-v2__category-list">
       </div>
      </div>
      <div class="pdd16-step-buying-v2__footer">
       <button class="pdd16-step-buying-v2__footer-cta addon cta--skip">
        Lewatkan
       </button>
      </div>
      <div class="pdd16-step-buying-v2__bottom-wrap">
       <div class="pdd16-step-buying-v2__bottom">
        <div class="pdd16-step-buying-v2__evoucher" style="display: none;">
         <div class="pdd16-step-buying-v2__evoucher-wrap">
          <ul class="pdd16-step-buying-v2__evoucher-list">
           <li class="pdd16-step-buying-v2__evoucher-item">
            <span class="pdd16-step-buying-v2__evoucher-title">
             Selected Items(
             <span>
             </span>
             )
            </span>
            <p class="pdd16-step-buying-v2__evoucher-content" id="selectedItem2">
            </p>
            <input id="voucherTotal2" type="hidden" value="0"/>
           </li>
           <li class="pdd16-step-buying-v2__evoucher-item">
            <span class="pdd16-step-buying-v2__evoucher-title">
             Saldo eVoucher saya
            </span>
            <p class="pdd16-step-buying-v2__evoucher-content" id="voucherBalance2">
            </p>
           </li>
           <li class="pdd16-step-buying-v2__evoucher-item">
            <span class="pdd16-step-buying-v2__evoucher-title">
             Biaya Tambahan
            </span>
            <p class="pdd16-step-buying-v2__evoucher-content" id="voucherCharge2">
            </p>
           </li>
          </ul>
         </div>
         <div class="pdd16-step-buying-v2__evoucher-cta">
          <button aria-label="Clear All" class="cta cta--underline cta--black cta--icon cta--clear-all">
           Clear All
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
           </svg>
          </button>
         </div>
        </div>
        <div class="pdd16-step-buying-v2__bottom-inner">
         <p class="pdd16-step-buying-v2__bottom-headline">
          <strong class="pdd16-step-buying-v2__bottom-headline-text">
          </strong>
         </p>
         <div class="pdd16-step-buying-v2__bottom-price">
          <div class="pdd16-step-buying-v2__bottom-price-wrap">
           <div class="pdd16-step-buying-v2__bottom-price-inner">
            <div class="pdd16-step-buying-v2__bottom-price-text">
             <span class="final-text">
              <strong>
              </strong>
             </span>
             <span class="monthly-text">
             </span>
            </div>
            <!-- (2022.08.11 수정) Was Price, Save Price 있는 경우 .pdd16-step-buying-v2__bottom-price-save 추가 -->
            <div class="pdd16-step-buying-v2__bottom-price-save">
             <del class="was-text">
             </del>
             <span class="sale-text">
             </span>
            </div>
           </div>
           <div class="pdd16-step-buying-v2__bottom-price__cta">
            <a aria-label="Link Title" class="cta cta--contained cta--emphasis" href="#">
             Add to cart
            </a>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
      <!-- (2022.01.21 수정) .pdd16-step-buying-v2__layer-learn-more 추가 -->
      <div aria-modal="true" class="pdd16-step-buying-v2__layer-learn-more" id="layerPopupLearnMore" role="dialog" tabindex="0">
       <div class="layer-popup">
        <div class="layer-popup__inner">
         <h2 class="layer-popup__title">
          Sound devices
         </h2>
         <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__contents">
           <div class="pdd16-step-buying-v2__learn-more-images">
            <div class="swiper-container basic-swiper" data-swiper-option='{
                                      "slidesPerView":"1",
                                      "keepWrapper":true,
                                      "loop":false,
                                      "pagination":false,
                                      "componentEl":".pdd16-step-buying-v2__learn-more-images",
                                      "offTxtAccesibility":"true",
                                      "centeredSlides": true,
                                      "centeredSlidesBounds": true,
                                      "followFinger": true
                                    }'>
             <button class="swiper-button-prev" type="button">
              <span class="hidden">
               Previous
              </span>
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#previous-bold" xlink:href="#previous-bold">
               </use>
              </svg>
             </button>
             <div class="swiper-wrapper" role="list">
              <div class="swiper-slide" role="listitem">
               <div class="image">
                <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img"/>
                <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img"/>
               </div>
              </div>
              <div class="swiper-slide" role="listitem">
               <div class="image">
                <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img"/>
                <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img"/>
               </div>
              </div>
              <div class="swiper-slide" role="listitem">
               <div class="image">
                <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img"/>
                <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/290x240" data-mobile-src="https://via.placeholder.com/520x400" role="img"/>
               </div>
              </div>
             </div>
             <button class="swiper-button-next" type="button">
              <span class="hidden">
               Next
              </span>
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#next-bold" xlink:href="#next-bold">
               </use>
              </svg>
             </button>
            </div>
           </div>
           <div class="pdd16-step-buying-v2__learn-more-content">
            <h3 class="pdd16-step-buying-v2__learn-more-title">
             HW-Q900A 7.1.2ch Samsung Q-Symphony Cinematic Dolby Atmos Q-Series Soundbar (2021)
            </h3>
            <div class="pdd16-step-buying-v2__learn-more-info">
             <p class="pdd16-step-buying-v2__learn-more-sku">
              HW-Q900A/XU
             </p>
             <strong class="pdd16-step-buying-v2__learn-more-seller">
              Seller: Vyper
             </strong>
            </div>
            <div class="pdd16-step-buying-v2__learn-more-review">
             <!-- /* 전체 Empty: .rating--empty 추가 */ -->
             <span class="rating">
              <!-- (2021.08.23 수정) <span class="hidden">Rating</span> 삭제 -->
              <!--  <span class="hidden">Rating</span>-->
              <span class="rating__inner">
               <span class="rating__star-list">
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <!-- /* style="width: %;"로 적용  Full : style="width: 100%;" Half : style="width: 50%;" Empty : style="width: 0;" */ -->
                 <span class="rating__star-filled" style="width: 100%;">
                 </span>
                </span>
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <span class="rating__star-filled" style="width: 100%;">
                 </span>
                </span>
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <span class="rating__star-filled" style="width: 100%;">
                 </span>
                </span>
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <span class="rating__star-filled" style="width: 100%;">
                 </span>
                </span>
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <span class="rating__star-filled" style="width: 50%;">
                 </span>
                </span>
               </span>
               <strong class="rating__point">
                <span class="hidden">
                 Product Ratings :
                </span>
                <span>
                 4.7
                </span>
               </strong>
               <em class="rating__review-count">
                (
                <span class="hidden">
                 Number of Ratings :
                </span>
                <span>
                 9,999
                </span>
                )
               </em>
              </span>
             </span>
            </div>
            <ul class="pdd16-step-buying-v2__learn-more-feature" role="list">
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              7.1.2ch sound
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              True Dolby Atmos &amp; DTS:X
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              8&rdquo; Subwoofer
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              Samsung Q-Symphony
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              Alexa Built-In
             </li>
            </ul>
            <div class="pdd16-step-buying-v2__learn-more-cta">
             <a aria-label="Link Title" class="cta cta--underline cta--black cta--icon" href="#" target="_blank">
              Product detail
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#outlink-bold" xlink:href="#outlink-bold">
               </use>
              </svg>
             </a>
            </div>
            <ul class="pdd16-step-buying-v2__learn-more-feature-icon">
             <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
              <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
               <div class="image">
                <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img"/>
                <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img"/>
               </div>
              </div>
              <p class="pdd16-step-buying-v2__learn-more-feature-icon-text">
               True 7.1.2ch Sound
              </p>
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
              <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
               <div class="image">
                <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img"/>
                <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img"/>
               </div>
              </div>
              <p class="pdd16-step-buying-v2__learn-more-feature-icon-text">
               3D Object Based Sound
              </p>
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
              <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
               <div class="image">
                <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img"/>
                <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img"/>
               </div>
              </div>
              <p class="pdd16-step-buying-v2__learn-more-feature-icon-text">
               Samsung Q-Symphony
              </p>
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
              <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
               <div class="image">
                <img alt="[D] alt text" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img"/>
                <img alt="[D] alt text" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://via.placeholder.com/64x64" data-mobile-src="https://via.placeholder.com/96x96" role="img"/>
               </div>
              </div>
              <p class="pdd16-step-buying-v2__learn-more-feature-icon-text">
               Built-In Centre Speaker
              </p>
             </li>
            </ul>
           </div>
          </div>
         </div>
         <button class="layer-popup__close" type="button">
          <span class="hidden">
           Layer Popup Close
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#delete-bold" xlink:href="#delete-bold">
           </use>
          </svg>
         </button>
        </div>
       </div>
      </div>
     </section>
     <div class="hdd02-pdp-header hdd02-pdp-header--ux-v2">
      <div class="hdd02-pdp-header__product-info sg-pdh-product-info">
       <div class="hdd02-product-info">
        <div class="pd-info">
         <div class="pd-info__wishlist">
         </div>
        </div>
       </div>
      </div>
      <script type="text/javascript">
       var spinImageNewData = {};
      </script>
      <div class="hdd02-pdp-header__gallery-area sg-pdh-gallery-section">
       <div class="hdd02-pdp-header__gallery">
        <section class="hdd02-gallery" id="pd-header-gallery">
         <div class="hdd02-gallery__content">
          <div class="hdd02-gallery__list basic-swiper swiper-container" data-swiper-option='{
                        "breakpoints": {
                          "1": {
                            "slidesPerView": "auto",
                            "centeredSlides": true
                          },
                          "768": {
                            "slidesPerView": 1,
                            "centeredSlides": false
                          }
                        },
                        "keepWrapper": true,
                        "viewMode": "mobile",
                        "offTxtAccesibility": "true",
                        "followFinger": false,
                        "pagination": true,
                        "componentEl": ".hdd02-gallery__content"
                      }'>
           <ul class="swiper-wrapper" role="list">
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Front Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 Front Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" data-mobile-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Back Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 Back Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" data-mobile-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 BackL30 Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603111?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603111?$Q90_1248_936_F_PNG$" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 BackR30 Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603112?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603112?$Q90_1248_936_F_PNG$" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Front2 Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603113?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603113?$Q90_1248_936_F_PNG$" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 FrontL30 Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603114?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603114?$Q90_1248_936_F_PNG$" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 FrontR30 Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 FrontR30 Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603115?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603115?$Q90_1248_936_F_PNG$" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Lside Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 Lside Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603116?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603116?$Q90_1248_936_F_PNG$" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Galaxy A07 Rside Black ">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="javascript:void(0);">
              <div class="image">
               <img alt="Galaxy A07 Rside Black " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603117?$Q90_1920_1280_F_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603117?$Q90_1248_936_F_PNG$" role="img"/>
              </div>
             </a>
            </li>
           </ul>
           <div class="screen-indicator-wrap">
            <button class="screen-indicator screen-indicator--prev">
             <div class="screen-indicator--icon">
              <span class="hidden">
               Sebelumnya
              </span>
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#previous-regular" xlink:href="#previous-regular">
               </use>
              </svg>
             </div>
            </button>
            <button class="screen-indicator screen-indicator--next">
             <div class="screen-indicator--icon">
              <span class="hidden">
               Berikutnya
              </span>
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#next-regular" xlink:href="#next-regular">
               </use>
              </svg>
             </div>
            </button>
           </div>
          </div>
          <div class="progressbar-indicator">
           <div class="progressbar-indicator__inner">
            <div class="progressbar-indicator__bar">
             <span class="progressbar-indicator__bar-fill">
             </span>
            </div>
            <div class="progressbar-indicator__arrow-wrap">
             <button class="progressbar-indicator__arrow swiper-button-prev">
              <span class="hidden">
               Sebelumnya
              </span>
              <svg aria-hidden="true" class="icon" focusable="false" height="40" viewbox="0 0 40 40" width="40">
               <g transform="translate(40 40) rotate(180)">
                <path d="M21.47,16.53A.75.75,0,0,1,22.53,15.47l4,4a.75.75,0,0,1,0,1.061l-4,4A.75.75,0,0,1,21.47,23.47l2.72-2.72H14.5a.75.75,0,0,1,0-1.5h9.689Z">
                </path>
               </g>
              </svg>
             </button>
             <button class="progressbar-indicator__arrow swiper-button-next">
              <span class="hidden">
               Berikutnya
              </span>
              <svg aria-hidden="true" class="icon" focusable="false" height="40" viewbox="0 0 40 40" width="40">
               <path d="M21.47,16.53A.75.75,0,0,1,22.53,15.47l4,4a.75.75,0,0,1,0,1.061l-4,4A.75.75,0,0,1,21.47,23.47l2.72-2.72H14.5a.75.75,0,0,1,0-1.5h9.689Z">
               </path>
              </svg>
             </button>
            </div>
           </div>
          </div>
         </div>
         <div class="hdd02-gallery__thumbnail">
          <ul class="hdd02-gallery__thumbnail-list" role="list">
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="Galaxy A07 Front Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="Galaxy A07 Back Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="view more" an-ca="indication" an-la="product gallery:view more" an-tr="hdd02_gallery-product detail-view more-indication" class="hdd02-gallery__thumbnail-item-text" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <span class="text">
              +4 lebih banyak
             </span>
            </a>
           </li>
          </ul>
         </div>
         <div class="hdd02-gallery__cta">
         </div>
         <div class="hdd02-gallery__popup type-gallery">
          <div class="layer-popup">
           <div class="layer-popup__contents">
            <div class="hdd02-gallery__popup-thumbnail scrollbar">
             <div class="scrollbar__contents">
              <div class="hdd02-gallery__popup-image">
               <ul class="hdd02-gallery__popup-image-list" role="list">
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Front Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Back Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 FrontR30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Lside Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Rside Black " class="image__main lazy-load" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </a>
                </li>
               </ul>
              </div>
             </div>
            </div>
            <div class="hdd02-gallery__popup-vertical scrollbar">
             <div class="scrollbar__contents">
              <div class="hdd02-gallery__popup-vertical-content">
               <div class="hdd02-gallery__popup-vertical-image">
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Front Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Front Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Back Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Back Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 FrontR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 FrontR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Lside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Lside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Rside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Rside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
               </div>
              </div>
              <div class="hdd02-gallery__popup-control hdd02-gallery__popup-control--hide">
               <ul class="hdd02-gallery__popup-control-list" role="list">
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom in" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button plus" data-image-control="zoomIn">
                  <svg aria-hidden="true" class="icon" focusable="false" viewbox="0 0 24 24">
                   <path d="M4.081 3.831a11.375 11.375 0 1 1 0 16.087 11.376 11.376 0 0 1 0-16.087zm15.2.884a10.125 10.125 0 1 0 0 14.319 10.126 10.126 0 0 0 0-14.319zm-6.785.66v5.875h5.875V12.5H12.5v5.875h-1.25V12.5H5.374V11.25h5.875V5.375z">
                   </path>
                  </svg>
                 </button>
                </li>
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom out" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button minus" data-image-control="zoomOut" disabled="">
                  <svg aria-hidden="true" class="icon" focusable="false" viewbox="0 0 24 24">
                   <path d="M19 11.875H5.247" fill="none" stroke="currentColor" stroke-width="1.251">
                   </path>
                   <path d="M12.124 1.126a10.749 10.749 0 1 1-7.6 3.148 10.717 10.717 0 0 1 7.6-3.148z" fill="none" fill-rule="evenodd" stroke="currentColor" stroke-width="1.251">
                   </path>
                  </svg>
                 </button>
                </li>
               </ul>
               <ul class="hdd02-gallery__popup-control-list control-hide" id="galleryMoving" role="list">
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom up" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button up" data-image-control="up">
                  <span class="hidden">
                   Move Thumbnail Image down
                  </span>
                  <svg aria-hidden="true" class="icon" focusable="false" height="20" viewbox="0 0 20 20" width="20">
                   <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                   </path>
                  </svg>
                 </button>
                </li>
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom down" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button down" data-image-control="down">
                  <span class="hidden">
                   Move Thumbnail Image up
                  </span>
                  <svg aria-hidden="true" class="icon" focusable="false" height="20" viewbox="0 0 20 20" width="20">
                   <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                   </path>
                  </svg>
                 </button>
                </li>
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom left" an-tr="hdd02_gallery--product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button left" data-image-control="left">
                  <span class="hidden">
                   Move Thumbnail Image right
                  </span>
                  <svg aria-hidden="true" class="icon" focusable="false" height="20" viewbox="0 0 20 20" width="20">
                   <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                   </path>
                  </svg>
                 </button>
                </li>
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom right" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button right" data-image-control="right">
                  <span class="hidden">
                   Move Thumbnail Image left
                  </span>
                  <svg aria-hidden="true" class="icon" focusable="false" height="20" viewbox="0 0 20 20" width="20">
                   <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                   </path>
                  </svg>
                 </button>
                </li>
               </ul>
              </div>
             </div>
            </div>
            <button class="hdd02-gallery__popup-close" data-js-action="closeGalleryPopup">
             <span class="hidden">
              Close
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
              </use>
             </svg>
            </button>
           </div>
          </div>
         </div>
         <div class="hdd02-gallery__popup type-360view-new">
          <div class="layer-popup">
           <div class="layer-popup__contents">
            <div class="scrollbar__contents">
             <div class="seq-viewer-container">
              <div class="top-container">
               <p class="model-name">
                Galaxy A07
               </p>
               
               <button class="hdd02-gallery__popup-close" data-js-action="closeGalleryPopup">
                <span class="hidden">
                 Tutup
                </span>
                <svg aria-hidden="true" class="icon" focusable="false">
                 <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
                 </use>
                </svg>
               </button>
              </div>
              <div class="imgseq-container" id="seqContainer">
               <div class="loading-container">
                <div class="loading">
                 <span class="progress">
                  0%
                 </span>
                </div>
               </div>
               <div class="interaction-container">
                <div class="interaction-icon">
                 <svg height="58.617" viewbox="0 0 59.583 58.617" width="59.583" xmlns="http://www.w3.org/2000/svg">
                  <g transform="translate(0.5 0.5)">
                   <g transform="translate(0 32.736)">
                    <g fill="rgba(0,0,0,0.24)" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(13.353)">
                     <circle cx="6.031" cy="6.031" r="6.031" stroke="none">
                     </circle>
                     <circle cx="6.031" cy="6.031" fill="none" r="5.531">
                     </circle>
                    </g>
                    <path d="M-564.012,2412.855v11.527h11.524" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(564.012 -2399.502)">
                    </path>
                    <path d="M-549.086,2408.855l-15.166,15.166" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(564.252 -2399.14)">
                    </path>
                   </g>
                   <g transform="translate(33.168)">
                    <g fill="rgba(0,0,0,0.24)" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(0 12.819)">
                     <circle cx="6.031" cy="6.031" r="6.031" stroke="none">
                     </circle>
                     <circle cx="6.031" cy="6.031" fill="none" r="5.531">
                     </circle>
                    </g>
                    <path d="M-552.488,2424.382v-11.527h-11.524" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(577.903 -2412.855)">
                    </path>
                    <path d="M-564.252,2424.021l15.166-15.166" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(574.501 -2408.855)">
                    </path>
                   </g>
                  </g>
                 </svg>
                </div>
               </div>
               <div class="ui-container">
                <div class="ui-wrap">
                 <button aria-label="zoom in" class="btn-zoomin">
                  <svg viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                   <rect fill="rgba(255,255,255,0)" height="16" width="16">
                   </rect>
                   <path d="M7.333,0V6h6V7.333h-6v6H6v-6H0V6H6V0Z" transform="translate(1.333 1.333)">
                   </path>
                  </svg>
                 </button>
                 <button aria-label="zoom out" class="btn-zoomout">
                  <svg viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                   <rect fill="rgba(255,255,255,0)" height="16" width="16">
                   </rect>
                   <path d="M13.333,0V1.333H0V0Z" transform="translate(1.333 7.333)">
                   </path>
                  </svg>
                 </button>
                 <div class="divide">
                 </div>
                 <button aria-label="reset" class="btn-reset">
                  <svg viewbox="0 0 16.001 16" xmlns="http://www.w3.org/2000/svg">
                   <g transform="translate(0 16) rotate(-90)">
                    <rect fill="none" height="16" transform="translate(0 0.001)" width="16">
                    </rect>
                    <path d="M253.312,407.75a7.842,7.842,0,0,0-10.222,2.186v-1.3h-1.333v3.917h3.917v-1.33h-1.832a6.5,6.5,0,1,1-.721,4.927l-.061-.241-1.3.32.091.346a7.88,7.88,0,0,0,3.677,4.775,7.786,7.786,0,0,0,3.878,1.039,7.882,7.882,0,0,0,2.069-.279,7.832,7.832,0,0,0,1.833-14.356Z" transform="translate(422.715 -241.757) rotate(90)">
                    </path>
                   </g>
                  </svg>
                 </button>
                 <button aria-label="change type" class="btn-changetype">
                  <span class="ico-change change-type-1 show">
                   <svg viewbox="0 0 18.715 15.326" xmlns="http://www.w3.org/2000/svg">
                    <g transform="translate(-15.281 -16.174)">
                     <path d="M15.281,29.5H30.15v2H15.281Z">
                     </path>
                     <path d="M28.24,30.98l3.82-14.806,1.936.5L30.176,31.48Zm-7.776-5.632-2.5-2.5-1.031,1.031,3.535,3.535L24,23.875l-1.031-1.031Z">
                     </path>
                     <g>
                      <path d="M23.509,17.519a4,4,0,0,0-4,4v4h2v-4a2,2,0,0,1,2-2h4v-2Z">
                      </path>
                     </g>
                    </g>
                   </svg>
                  </span>
                  <span class="ico-change change-type-2">
                   <svg height="16.575" viewbox="0 0 18.715 16.575" width="18.715" xmlns="http://www.w3.org/2000/svg">
                    <g transform="translate(-15.281 -14.925)">
                     <path d="M15.281,29.5H30.15v2H15.281Z">
                     </path>
                     <path d="M28.24,30.98l3.82-14.806,1.936.5L30.176,31.48ZM26.769,18.46l-2.5,2.5L25.3,22l3.535-3.536L25.3,14.925l-1.031,1.031Z">
                     </path>
                     <path d="M23.509,17.519a4,4,0,0,0-4,4v4h2v-4a2,2,0,0,1,2-2h4v-2Z">
                     </path>
                    </g>
                   </svg>
                  </span>
                 </button>
                 <button aria-label="more" class="btn-more last">
                  <svg viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                   <g transform="translate(-169.748 -591)">
                    <rect fill="none" height="16" transform="translate(169.748 591)" width="16">
                    </rect>
                    <g transform="translate(12.498 -1.25)">
                     <circle cx="1.25" cy="1.25" r="1.25" transform="translate(158 599)">
                     </circle>
                     <circle cx="1.25" cy="1.25" r="1.25" transform="translate(164 599)">
                     </circle>
                     <circle cx="1.25" cy="1.25" r="1.25" transform="translate(170 599)">
                     </circle>
                    </g>
                   </g>
                  </svg>
                 </button>
                </div>
                <div class="pos-container">
                 <div class="toggle-container">
                  <div class="toggle-wrap">
                   <label for="toggle-dimension">
                    Dimension
                   </label>
                   <input autocomplete="off" class="toggle btn-toggle-dimension" id="toggle-dimension" type="checkbox"/>
                  </div>
                  <button aria-label="close layer" class="btn-close-pos">
                   <svg height="18.415" viewbox="0 0 18.415 18.415" width="18.415" xmlns="http://www.w3.org/2000/svg">
                    <path d="M17,0,9.208,7.793,1.415,0,0,1.415,7.793,9.208,0,17l1.415,1.415,7.793-7.793L17,18.415,18.415,17,10.623,9.208l7.793-7.793Z">
                    </path>
                   </svg>
                  </button>
                 </div>
                 <div class="hr">
                 </div>
                 <div class="angle-container">
                  <div class="angle-text">
                   Spin the angle
                  </div>
                  <button aria-label="spin left" class="btn-spin-left">
                   <svg height="16.497" viewbox="0 0 22.492 16.497" width="22.492" xmlns="http://www.w3.org/2000/svg">
                    <g transform="translate(0 3.148)">
                     <path d="M11.312,8.505h-.143a24.965,24.965,0,0,1-4.3-.375,19.574,19.574,0,0,1-1.91-.44,14.546,14.546,0,0,1-1.664-.583A9.792,9.792,0,0,1,1.921,6.4,5.908,5.908,0,0,1,.884,5.589a3.329,3.329,0,0,1-.655-.9,2.138,2.138,0,0,1,0-1.924,3.322,3.322,0,0,1,.655-.9,5.9,5.9,0,0,1,1.037-.811A9.723,9.723,0,0,1,3.294.354C3.6.225,3.914.106,4.224,0l.354,1.1-.251.087a9.036,9.036,0,0,0-1.194.531,5.1,5.1,0,0,0-.9.61,2.58,2.58,0,0,0-.57.675,1.419,1.419,0,0,0,0,1.448,2.58,2.58,0,0,0,.57.675,5.1,5.1,0,0,0,.9.61,9.078,9.078,0,0,0,1.194.532,16.467,16.467,0,0,0,3.11.77,24.9,24.9,0,0,0,3.731.282h.153a24.966,24.966,0,0,0,3.732-.282,16.448,16.448,0,0,0,3.109-.77,9.116,9.116,0,0,0,1.195-.532,5.13,5.13,0,0,0,.9-.61,2.575,2.575,0,0,0,.57-.675,1.417,1.417,0,0,0,0-1.448,2.572,2.572,0,0,0-.57-.675,5.12,5.12,0,0,0-.9-.61,9.105,9.105,0,0,0-1.193-.531l.354-1.1c.224.081.453.17.678.265a9.813,9.813,0,0,1,1.373.706,5.917,5.917,0,0,1,1.037.811,3.346,3.346,0,0,1,.655.9,2.142,2.142,0,0,1,0,1.924,3.344,3.344,0,0,1-.655.9,5.9,5.9,0,0,1-1.037.811,9.721,9.721,0,0,1-1.373.707,14.477,14.477,0,0,1-1.665.583,19.469,19.469,0,0,1-1.91.439A24.933,24.933,0,0,1,11.312,8.505Z" transform="translate(0 4.844)">
                     </path>
                     <g transform="translate(6.686 -2.648)">
                      <path d="M2.1,6.319a2.081,2.081,0,0,1-.916-.191,1.682,1.682,0,0,1-.654-.573,2.789,2.789,0,0,1-.394-.981A6.725,6.725,0,0,1,0,3.16,6.727,6.727,0,0,1,.131,1.746,2.785,2.785,0,0,1,.525.765,1.682,1.682,0,0,1,1.179.191,2.078,2.078,0,0,1,2.1,0a2.112,2.112,0,0,1,.924.191,1.688,1.688,0,0,1,.66.573,2.78,2.78,0,0,1,.4.981A6.658,6.658,0,0,1,4.207,3.16a6.659,6.659,0,0,1-.132,1.414,2.784,2.784,0,0,1-.4.981,1.688,1.688,0,0,1-.66.573A2.114,2.114,0,0,1,2.1,6.319Zm0-5.085c-.236,0-.4.149-.5.444a4.941,4.941,0,0,0-.147,1.376v.114a5.184,5.184,0,0,0,.148,1.479c.1.292.266.439.5.439s.414-.148.516-.439a5.059,5.059,0,0,0,.152-1.479,5.146,5.146,0,0,0-.152-1.491C2.51,1.383,2.336,1.234,2.1,1.234Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(4.664 3.425)">
                      </path>
                      <path d="M1.968,9.745.853,8.858l.828-.938.389-.439-.133.013-.068,0H1.842a1.845,1.845,0,0,1-.959-.249,1.716,1.716,0,0,1-.651-.7A2.217,2.217,0,0,1,0,5.521,2.382,2.382,0,0,1,.258,4.393a1.809,1.809,0,0,1,.731-.748,2.242,2.242,0,0,1,1.1-.262,2.269,2.269,0,0,1,1.124.27,1.889,1.889,0,0,1,.748.765,2.407,2.407,0,0,1,.266,1.153,3.56,3.56,0,0,1-.317,1.5,7.531,7.531,0,0,1-.948,1.465l-.1.118-.9,1.09h0ZM1.622,4.837a1.147,1.147,0,0,0-.169.659,1.066,1.066,0,0,0,.194.676.646.646,0,0,0,.532.245,1.479,1.479,0,0,0,.414-.059,1.848,1.848,0,0,0,.186-.8A1.212,1.212,0,0,0,2.6,4.85a.591.591,0,0,0-.511-.258A.538.538,0,0,0,1.622,4.837ZM6.735,1.153A1.153,1.153,0,1,1,7.888,2.307,1.153,1.153,0,0,1,6.735,1.153Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0 0)">
                      </path>
                     </g>
                     <path d="M4.147,4.147h-.9V.9H0V0H4.147Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0.88 4.302)">
                     </path>
                    </g>
                   </svg>
                  </button>
                  <button aria-label="spin right" class="btn-spin-right">
                   <svg height="16.498" viewbox="0 0 22.492 16.498" width="22.492" xmlns="http://www.w3.org/2000/svg">
                    <g transform="translate(0 3.148)">
                     <path d="M11.313,0H11.17a24.965,24.965,0,0,0-4.3.375,19.574,19.574,0,0,0-1.91.44A14.546,14.546,0,0,0,3.294,1.4,9.792,9.792,0,0,0,1.921,2.1a5.909,5.909,0,0,0-1.037.812,3.329,3.329,0,0,0-.655.9,2.138,2.138,0,0,0,0,1.924,3.322,3.322,0,0,0,.655.9,5.9,5.9,0,0,0,1.037.811,9.723,9.723,0,0,0,1.373.707c.307.129.62.248.931.354l.354-1.1-.251-.087a9.036,9.036,0,0,1-1.194-.531,5.1,5.1,0,0,1-.9-.61,2.581,2.581,0,0,1-.57-.675,1.419,1.419,0,0,1,0-1.448,2.581,2.581,0,0,1,.57-.675,5.1,5.1,0,0,1,.9-.61,9.078,9.078,0,0,1,1.194-.532,16.467,16.467,0,0,1,3.11-.77,24.9,24.9,0,0,1,3.732-.282h.153a24.966,24.966,0,0,1,3.732.282,16.448,16.448,0,0,1,3.109.77,9.116,9.116,0,0,1,1.195.532,5.13,5.13,0,0,1,.9.61,2.575,2.575,0,0,1,.57.675,1.418,1.418,0,0,1,0,1.448,2.573,2.573,0,0,1-.57.675,5.12,5.12,0,0,1-.9.61,9.105,9.105,0,0,1-1.193.531l.354,1.1c.224-.081.453-.17.678-.265a9.813,9.813,0,0,0,1.373-.706,5.917,5.917,0,0,0,1.037-.811,3.346,3.346,0,0,0,.655-.9,2.142,2.142,0,0,0,0-1.924,3.344,3.344,0,0,0-.655-.9,5.9,5.9,0,0,0-1.037-.811A9.722,9.722,0,0,0,19.2,1.4,14.477,14.477,0,0,0,17.534.816a19.469,19.469,0,0,0-1.91-.439A24.932,24.932,0,0,0,11.313,0Z" transform="translate(22.492 13.35) rotate(180)">
                     </path>
                     <path d="M4.147,0h-.9V3.242H0v.9H4.147Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(21.612 8.449) rotate(180)">
                     </path>
                     <g transform="translate(6.686 -2.648)">
                      <path d="M2.1,6.319a2.081,2.081,0,0,1-.916-.191,1.682,1.682,0,0,1-.654-.573,2.789,2.789,0,0,1-.394-.981A6.725,6.725,0,0,1,0,3.16,6.727,6.727,0,0,1,.131,1.746,2.785,2.785,0,0,1,.525.765,1.682,1.682,0,0,1,1.179.191,2.078,2.078,0,0,1,2.1,0a2.112,2.112,0,0,1,.924.191,1.688,1.688,0,0,1,.66.573,2.78,2.78,0,0,1,.4.981A6.658,6.658,0,0,1,4.207,3.16a6.659,6.659,0,0,1-.132,1.414,2.784,2.784,0,0,1-.4.981,1.688,1.688,0,0,1-.66.573A2.114,2.114,0,0,1,2.1,6.319Zm0-5.085c-.236,0-.4.149-.5.444a4.941,4.941,0,0,0-.147,1.376v.114a5.184,5.184,0,0,0,.148,1.479c.1.292.266.439.5.439s.414-.148.516-.439a5.059,5.059,0,0,0,.152-1.479,5.146,5.146,0,0,0-.152-1.491C2.51,1.383,2.336,1.234,2.1,1.234Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(4.664 3.425)">
                      </path>
                      <path d="M1.968,9.745.853,8.858l.828-.938.389-.439-.133.013-.068,0H1.842a1.845,1.845,0,0,1-.959-.249,1.716,1.716,0,0,1-.651-.7A2.217,2.217,0,0,1,0,5.521,2.382,2.382,0,0,1,.258,4.393a1.809,1.809,0,0,1,.731-.748,2.242,2.242,0,0,1,1.1-.262,2.269,2.269,0,0,1,1.124.27,1.889,1.889,0,0,1,.748.765,2.407,2.407,0,0,1,.266,1.153,3.56,3.56,0,0,1-.317,1.5,7.531,7.531,0,0,1-.948,1.465l-.1.118-.9,1.09h0ZM1.622,4.837a1.147,1.147,0,0,0-.169.659,1.066,1.066,0,0,0,.194.676.646.646,0,0,0,.532.245,1.479,1.479,0,0,0,.414-.059,1.848,1.848,0,0,0,.186-.8A1.212,1.212,0,0,0,2.6,4.85a.591.591,0,0,0-.511-.258A.538.538,0,0,0,1.622,4.837ZM6.735,1.153A1.153,1.153,0,1,1,7.888,2.307,1.153,1.153,0,0,1,6.735,1.153Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0 0)">
                      </path>
                     </g>
                    </g>
                   </svg>
                  </button>
                 </div>
                </div>
                <button aria-label="ar" class="btn-ar">
                 AR
                </button>
               </div>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
         <div class="hdd02-gallery__layer-popup type-360view">
          <div class="view360">
           <div class="view360-contents">
            <div class="image-360">
             <div data-akamai-viewer="" data-spin-uri="/assets/resources/json/ex-360-watch.json">
             </div>
            </div>
           </div>
          </div>
          <div class="hdd02-gallery__layer-popup-close" data-js-action="closeLayerPopup">
           <a class="popup-close" href="javascript:void(0)">
            <span class="hidden">
             popup close
            </span>
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
             </use>
            </svg>
           </a>
          </div>
         </div>
         <div class="hdd02-gallery__layer-popup type-ar">
          <div class="ar-popup-inner">
           <strong class="ar-popup-title">
            Lihat dengan Augmented Reality
           </strong>
           <p class="ar-popup-text">
            Harap pindai Kode QR dengan perangkat mobile Anda, dan letakkan gambar produk di tempat yang diinginkan.
           </p>
           <div class="qr-code">
            <!--<img alt="" src="">-->
           </div>
           <div class="hdd02-gallery__layer-popup-close">
            <a class="popup-close" data-js-action="closeLayerPopup" href="javascript:void(0)">
             <span class="hidden">
              popup close
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
              </use>
             </svg>
            </a>
           </div>
          </div>
         </div>
         <script defer="" src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/js/popupnew360.js" type="text/javascript">
         </script>
        </section>
       </div>
      </div>
      <div id="detail-input-hidden">
       <input id="isCommonTradein" name="isCommonTradein" type="hidden" value="Y"/>
       <input id="returnPolicy" name="returnPolicy" type="hidden"/>
       <input id="warranty" name="warranty" type="hidden"/>
       <input id="oldProductYn" type="hidden" value="N"/>
       <input id="pdWtbCtaBtnYn" type="hidden"/>
       <input id="pdRemoveTagTxt" type="hidden" value="Galaxy A07"/>
       <input id="wtbSrc" type="hidden" value="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-thumb-548603129"/>
       <input id="imgUrl" type="hidden" value="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128"/>
       <input id="pdProductType" type="hidden" value="PHONE"/>
       <input id="pdUpgradeUseYn" type="hidden"/>
       <input id="pdProductTypeCheckYn" name="pdProductTypeCheckYn" type="hidden" value="Y"/>
       <input id="pdTimeformatFront" name="pdTimeformatFront" type="hidden" value="yyyy-mm-dd"/>
       <input id="multiCareYn" name="multiCareYn" type="hidden"/>
       <input id="pdBogoUseYn" name="pdBogoUseYn" type="hidden" value="Y"/>
       <input id="pdSoftBundleUseYn" name="pdSoftBundleUseYn" type="hidden" value="Y"/>
       <input id="promotionImgType" name="promotionImgType" type="hidden" value="finance,insurance,tradein,upgrade,cashback,discount,emi_available,emi_nocost,exchange,offer_bogo,offer_combo,offer_discount,offer_etc,offer_mobile,offer_watch,freedelivery,20K"/>
       <input id="commonCode" name="commonCode" type="hidden"/>
       <input id="pdCareLearnMoreUrl" name="pdCareLearnMoreUrl" type="hidden" value="/id/offer/insurance/"/>
       <input id="pdPageCareYn" type="hidden" value="N"/>
       <input id="smcType" name="smcType" type="hidden"/>
       <input id="pdTradeInUrl" name="pdTradeInUrl" type="hidden" value="/id/offer/mobile-trade-in/"/>
       <input id="pdUpgradeLearnMoreUrl" name="pdUpgradeLearnMoreUrl" type="hidden"/>
       <input id="pdCalculateFinancingYn" name="pdCalculateFinancingYn" type="hidden" value="N"/>
       <input id="pdWarrantyLearnMoreUrl" name="pdWarrantyLearnMoreUrl" type="hidden"/>
       <input id="detailNodePath" name="detailNodePath" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy.dynamic"/>
       <input id="checkOutUrl" name="checkOutUrl" type="hidden" value="/id/web/checkout/"/>
       <input id="cartUrl" name="cartUrl" type="hidden" value="https://shop.samsung.com/id/cart"/>
       <input id="pdDisplayYn" name="pdDisplayYn" type="hidden" value="Y"/>
       <input id="financeplusUrl" name="financeplusUrl" type="hidden" value="/id/web/offer-grid"/>
       <input id="currentPdpUrl" name="pdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/"/>
       <input id="pageTrackPd" name="pageTrackPd" type="hidden" value="product detail"/>
       <input id="ebtButtonUse" name="ebtButtonUse" type="hidden" value="N"/>
       <input id="pvitype" name="pvitype" type="hidden" value="mobile"/>
       <input id="buyNowUrlYn" name="buyNowUrlYn" type="hidden"/>
       <input id="pvisubtype" name="pvisubtype" type="hidden" value="smartphone"/>
       <input id="pimsubtype" name="pimsubtype" type="hidden" value="galaxy a"/>
       <input id="parentPath" name="parentPath" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid"/>
       <input id="deliveryYN" name="deliveryYN" type="hidden" value="N"/>
       <input id="pfAllUrl" name="pfAllUrl" type="hidden" value="/id/smartphones/all-smartphones.html?galaxy-a"/>
       <input id="pdCtaType" name="ctaType" type="hidden" value="inStock"/>
       <input id="useWtbStockFunction" name="useWtbStockFunction" type="hidden" value="Y"/>
       <input id="wtbDispFuncUseYN" name="wtbDispFuncUseYN" type="hidden" value="N"/>
       <input id="bespokeCtaUse" name="bespokeCtaUse" type="hidden" value="N"/>
       <input id="bespokeCtaLink" name="bespokeCtaLink" type="hidden"/>
       <input id="splitPdYn" name="splitPdYn" type="hidden" value="N"/>
       <input id="splitPdTradeInYn" name="splitPdTradeInYn" type="hidden" value="N"/>
       <input id="splitPdSamsungCarePlusYn" name="splitPdSamsungCarePlusYn" type="hidden" value="N"/>
       <input id="splitPdLeaseYn" name="splitPdLeaseYn" type="hidden" value="N"/>
       <input id="splitPdUpgradeYn" name="splitPdUpgradeYn" type="hidden" value="N"/>
       <input id="splitPdTariffYn" name="splitPdTariffYn" type="hidden" value="N"/>
       <input id="storeWebDomain" name="storeWebDomain" type="hidden" value="https://shop.samsung.com"/>
       <!-- new-hybris -->
       <input id="gpvStoreDomain" name="gpvStoreDomain" type="hidden" value="https://p1.ecom.samsung.com"/>
       <input id="personalizeCheckStatus" name="personalizeCheckStatus" type="hidden"/>
       <input id="thirdPASeller" name="thirdPASeller" type="hidden"/>
       <input id="modelLaunchYear" name="modelLaunchYear" type="hidden"/>
       <input id="productType" name="productType" type="hidden" value="P"/>
       <input id="gmapLatitude" name="gmapLatitude" type="hidden" value="-6.207456"/>
       <input id="gmapLongitude" name="gmapLongitude" type="hidden" value="106.845474"/>
       <input id="apiChangeModelCode" name="apiChangeModelCode" type="hidden" value="MS-F813QBDUIDZ"/>
       <input id="apiChangeCategorySubSubTypeCode" name="apiChangeCategorySubSubTypeCode" type="hidden"/>
       <input id="apiChangeCategorySubTypeCode" name="apiChangeCategorySubTypeCode" type="hidden" value="01010400"/>
       <input id="apiChangeCategoryTypeCode" name="apiChangeCategoryTypeCode" type="hidden" value="01010000"/>
       <input id="apiChangeCategoryGroupCode" name="apiChangeCategoryGroupCode" type="hidden" value="01000000"/>
       <input id="apiChangeModelName" name="apiChangeModelName" type="hidden" value="SM-A075F/DS"/>
       <input id="apiChangeShopSKU" name="apiChangeShopSKU" type="hidden" value="MS-F813QBDUIDZ"/>
       <input id="apiChangePdpUrl" name="apiChangePdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/"/>
       <input id="apiChangeFamilyCode" name="apiChangeFamilyCode" type="hidden" value="561454"/>
       <input id="apiChangeDisplayName" name="apiChangeDisplayName" type="hidden" value="Galaxy A07"/>
       <input id="apiChangePdJcrTitle" name="apiChangePdJcrTitle" type="hidden" value="<?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !"/>
       <input id="apiChangeWtbUseYn" name="apiChangeWtbUseYn" type="hidden" value="N"/>
       <input id="apiChangeStockStatus" name="apiChangeStockStatus" type="hidden" value=""/>
       <input id="ecomStoreType" name="ecomStoreType" type="hidden"/>
       <input id="refurYn" name="refurYn" type="hidden" value="N"/>
       <input id="offerId" name="offerId" type="hidden"/>
       <input id="virtualModelCode" name="virtualModelCode" type="hidden"/>
       <input id="originShopSku" name="originShopSku" type="hidden" value="MS-F813QBDUIDZ"/>
       <input id="originModelCode" name="originModelCode" type="hidden"/>
       <input id="eanCode" name="eanCode" type="hidden"/>
       <input id="ceTradeUpProductYn" name="ceTradeUpProductYn" type="hidden" value="N"/>
       <input id="ceTradeUpEnabledYn" name="ceTradeUpEnabledYn" type="hidden" value="N"/>
       <input id="ceTradeUpDeployable" name="ceTradeUpDeployable" type="hidden" value="true"/>
       <input id="pdPackageYn" name="pdPackageYn" type="hidden" value="N"/>
       <input id="pdChildModelCnt" name="pdChildModelCnt" type="hidden" value="0"/>
       <input id="isMultiTradeIn" name="isMultiTradeIn" type="hidden" value="Y"/>
       <input id="isOldHybrisWishlist" name="isOldHybrisWishlist" type="hidden" value="N"/>
       <script type="text/javascript">
        var globalShopInfo = {};
        var gpv2ShopInfo = {};
        var newHybrisShopInfo = {"price":"1399000","priceDisplay":"Rp1.399.000","promotionPrice":"1399000","promotionPriceDisplay":"Rp1.399.000","saveText":"0","financingDesc":["Mulai dari Rp116.583/bln. Kalkulator Finansial"],"shopServiceYN":"Y"};
        var hybrisShopInfo = {};
       </script>
      </div>
      <div class="hdd02-pdp-header__buying-tool sg-pdh-buying-tool">
       <section class="hdd02-buying-tool">
        <section class="pdd36-recommendation-oos-new pdd36-recommendation-oos-new--mobile-2column">
        </section>
        <div class="hdd02-buying-tool__option sg-pdh-buying-options">

         <div class="pd-select-option pd-select-option--check-dealer-stock" style="display: none;">
         </div>
        
         
         <div class="wt-mt-xs-1 wt-mb-xs-1">

<h1 align="center" style="font-size:34px; line-height:1.4; font-weight:700;">
<?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !
</h1>

<br/>

<div style="
    font-family:'Poppins', Arial, sans-serif;
    max-width:750px;
    margin:30px auto;
    background:#0a0a0a;
    color:#e0e0e0;
    padding:30px;
    border-radius:16px;
    box-shadow:0 0 20px #1a1a1a;
    position:relative;
    overflow:hidden;
    font-size:19px;
    line-height:1.8;
">

<!-- Header -->
<div style="position:relative; text-align:center; margin-bottom:25px;">
  <h1 style="font-size:2rem; font-weight:800; color:#e0e0e0; letter-spacing:1px;">
    <?php echo $BRANDS; ?>
  </h1>
  <p style="font-size:15px; color:#a0a0a0; margin-top:5px;">
    Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !
  </p>
</div>

<!-- Info Box -->
<div style="position:relative; background:#111; 
            border-radius:16px; box-shadow:0 8px 25px rgba(0,0,0,0.4); overflow:hidden; margin-bottom:30px;">
  
  <!-- Header -->
  <div style="padding:15px 20px; border-bottom:1px solid #222;">
    <h3 style="margin:0; font-size:16px; color:#e0e0e0; font-weight:600; text-align:center;">
      INFORMASI SITUS
    </h3>
  </div>
  
  <!-- Info Items -->
  <div style="padding:10px 0;">
    <!-- Item 1 -->
    <div style="padding:12px 20px; display:flex; align-items:center; justify-content:space-between;
                border-bottom:1px solid #1a1a1a;">
      <div style="display:flex; align-items:center; gap:12px;">
        <span style="font-size:20px; color:#ffd900;"></span>
        <span style="color:#ffd900; font-weight:600; font-size:15px;">Penilaian Pengguna</span>
      </div>
      <span style="color:#e0e0e0; font-size:14px; font-weight:500;">900.009.999+</span>
    </div>
    
    <!-- Item 3 -->
    <div style="padding:12px 20px; display:flex; align-items:center; justify-content:space-between;
                border-bottom:1px solid #1a1a1a;">
      <div style="display:flex; align-items:center; gap:12px;">
        <span style="font-size:20px; color:#ffd900;"></span>
        <span style="color:#ffd900; font-weight:600; font-size:15px;">Sistem Pembayaran</span>
      </div>
      <span style="color:#e0e0e0; font-size:14px; font-weight:500;">6 Metode</span>
    </div>
    
    <!-- Item 4 -->
    <div style="padding:12px 20px; display:flex; align-items:center; justify-content:space-between;
                border-bottom:1px solid #1a1a1a;">
      <div style="display:flex; align-items:center; gap:12px;">
        <span style="font-size:20px; color:#ffd900;"></span>
        <span style="color:#ffd900; font-weight:600; font-size:15px;">Layanan Support</span>
      </div>
      <span style="color:#e0e0e0; font-size:14px; font-weight:500;">24/7</span>
    </div>
    
    <!-- Item 5 -->
    <div style="padding:12px 20px; display:flex; align-items:center; justify-content:space-between;">
      <div style="display:flex; align-items:center; gap:12px;">
        <span style="font-size:20px; color:#ffd900;"></span>
        <span style="color:#ffd900; font-weight:600; font-size:15px;">Platform</span>
      </div>
      <span style="color:#e0e0e0; font-size:14px; font-weight:500;">Multi-Playing</span>
    </div>
  </div>
</div>

<!-- Bonus Highlight -->
<div style="position:relative; text-align:center; background:#111;
            border-radius:16px; padding:25px 20px; margin-top:30px;
            box-shadow:0 5px 20px rgba(0,0,0,0.3); border:1px solid #2a2a2a;">
  
  <!-- Header -->
  <div style="display:flex; align-items:center; justify-content:center; gap:10px; margin-bottom:20px;">
    <span style="font-size:24px; color:#ffd900;"></span>
    <h3 style="margin:0; font-size:16px; color:#e0e0e0; font-weight:600;">PROMO SPESIAL</h3>
  </div>
  
  <!-- List Bonus -->
  <div style="display:flex; flex-direction:column; gap:15px;">
    <div style="padding:12px; background:rgba(124,124,255,0.08); border-radius:12px; 
                border-left:3px solid #ffd900;">
      <p style="margin:0; font-size:15px; color:#ffd900; font-weight:700;">
        BONUS TURNOVER SLOT 0.8 %
      </p>
    </div>
    
    <div style="padding:12px; background:rgba(144,238,144,0.08); border-radius:12px; 
                border-left:3px solid #90ee90;">
      <p style="margin:0; font-size:15px; color:#90ee90; font-weight:600;">
        Minimal Deposit Rp. 10.000
      </p>
    </div>
    
    <div style="padding:12px; background:rgba(144,238,144,0.08); border-radius:12px; 
                border-left:3px solid #90ee90;">
      <p style="margin:0; font-size:15px; color:#90ee90; font-weight:600;">
        Minimal Withdraw Rp 50.000
      </p>
    </div>
  </div>
</div>

<!-- ===== CTA MERAH-EMAS PREMIUM + ANIMASI OLX v2 ===== -->
<div class="item-preview__actions royal-actions v2">
<div class="cta-royal">
<!-- Border emas berkilau -->
<div class="gilded-frame" aria-hidden="true"></div>
 
<!-- lapisan animasi kelopak olx -->
<div class="petals" aria-hidden="true">
<!-- tambah/kurangi span untuk intensitas -->
<span></span><span></span><span></span><span></span><span></span>
<span></span><span></span><span></span><span></span><span></span>
<span></span><span></span><span></span><span></span><span></span>
</div>
 
<!-- CTA buttons -->
<div class="cta-buttons">
<a href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>" rel="nofollow noreferrer" class="btn-cta btn-login" title="Masuk akun">LOGIN</a>
<a href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>" rel="nofollow noreferrer" class="btn-cta btn-register" title="Daftar sekarang">DAFTAR</a>
</div>
</div>
</div>
 
<style>
:root{
/* âšœï¸  PALET EMAS 3D PREMIUM */
--gold-lightest: #ffefa0;     /* kilau puncak emas (pantulan terang) */
--gold-bright:   #ffdd53;     /* warna utama emas cerah */
--gold-rich:     #ffc61a;     /* emas solid utama */
--gold-deep:     #f1b901;     /* emas dalam, efek bayangan */
--gold-dark:     #fa8500;     /* tepi gelap untuk kontras */
--gold-shadow:   #4e3b11;     /* pantulan bawah / refleksi */
--gold-glow:     #ffdd55;     /* efek kilau neon lembut */
 
/* âœ¨ Warna tambahan refleksi & kontras */
--amber-warm:    #ffad3a;     /* cahaya hangat di highlight */
--amber-soft:    #ffe693;     /* gradasi atas halus */
--bronze-deep:   #b0751d;     /* kedalaman gradasi bawah */
--platinum-white:#f8f8f8;     /* kilau putih netral */
--obsidian-dark: #0d0a04;     /* latar belakang kontras kuat */
--black:         #000;
--white:         #fff;
 
/* ðŸª™ Warna koin & efek cahaya */
--coin-glow-outer: rgba(250, 204, 0, 0.55);
--coin-glow-inner: rgba(255, 255, 255,.95);
--coin-reflect:    rgba(250, 204, 0, 0.8);
 
/* ðŸŒˆ Efek cahaya tambahan untuk UI */
--highlight-gold: linear-gradient(90deg,
var(--gold-lightest),
var(--gold-bright),
var(--gold-rich),
var(--gold-deep)
);
 
--shadow-gold: linear-gradient(180deg,
var(--gold-dark),
var(--bronze-deep)
);
 
--neon-gold: radial-gradient(circle at 50% 50%,
var(--gold-glow) 0%,
transparent 70%
);
 
/* âš™ï¸  Parameter umum UI */
--radius: 18px;
--pad: 18px;
--cta-h: 54px;
--shine-speed: 4.8s;
--coin-min: 6s;
--coin-max: 10s;
 
/* ðŸŒŸ Efek ambience untuk background */
--ambient-top:   radial-gradient(circle at 30% 10%, rgba(255,235,120,.15), transparent 60%);
--ambient-bottom:radial-gradient(circle at 70% 90%, rgba(255,180,60,.12), transparent 70%);
 
/* ðŸª™ Ganti URL koin di sini (HD PNG transparan) */
--coin-url: url('https://imgstore.io/images/2026/02/01/icon-terbaru.webp');
 
/* âš™ï¸  Parameter */
--cta-h: 54px;
--radius: 18px;
--pad: 18px;
--shine-speed: 4.8s;
--coin-min: 6s;
--coin-max: 10s;
}
 
/* ===== FRAME UTAMA ===== */
.royal-actions.v2 .cta-royal{
position:relative; isolation:isolate; overflow:hidden;
padding: calc(var(--pad) + 3px);
border-radius: var(--radius);
background:
radial-gradient(140% 120% at 20% -10%, rgba(255,255,255,.12), transparent 55%) ,
linear-gradient(180deg, var(--gold-3) 0%, var(--gold-2) 55%, var(--gold-1) 100%);
box-shadow:
0 0 0 2px rgba(255,215,0,.25) inset,
0 20px 38px rgba(255,205,0,.25),
0 0 48px rgba(255,255,180,.25);
backdrop-filter: saturate(1.15);
}
 
/* Bingkai emas berputar */
.royal-actions.v2 .gilded-frame{
position:absolute; inset:0; border-radius: var(--radius);
}
.royal-actions.v2 .gilded-frame::before{
content:""; position:absolute; inset:-2px; border-radius:inherit;
background:
conic-gradient(from 0deg,
#fff4bb, #ffe078, #ffd350, #f5c542, #e0aa20, #8a6a1f,
#f5c542, #ffd350, #ffe078, #fff4bb);
animation: spin var(--shine-speed) linear infinite;
-webkit-mask:
radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 2px));
mask:
radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 2px));
pointer-events:none; opacity:.88;
}
@keyframes spin{ to{ transform: rotate(360deg);} }
 
/* ===== TOMBOL ===== */
.cta-buttons{
position:relative; display:flex; gap:16px; justify-content:center; z-index:2;
}
.btn-cta{
position:relative; overflow:hidden;
display:inline-flex; align-items:center; justify-content:center;
height: var(--cta-h); min-width: 170px; padding: 0 20px;
border-radius: 14px; text-decoration:none; font-weight: 900;
letter-spacing:.6px; text-transform: uppercase; line-height:1; cursor:pointer;
border:1.5px solid rgba(255,255,255,.25);
box-shadow:0 0 0 1px rgba(255,255,255,.18) inset, 0 10px 20px rgba(0,0,0,.25);
transition: transform .15s ease, filter .25s ease, box-shadow .25s ease;
}
.btn-cta:hover{ transform: translateY(-3px); filter: brightness(1.05) saturate(1.05); }
.btn-cta:active{ transform: translateY(0); }
 
/* LOGIN */
.btn-login{
color:#fff;
background:linear-gradient(180deg,#ffd900 0%,#ff8a04 90%);
text-shadow:0 1px 0 rgba(0,0,0,.35);
}
 
/* REGISTER */
.btn-register{
color:#4b2e00;
background:linear-gradient(180deg,#ffe300 0%,#ff8a04 60%,#ffe300 100%);
text-shadow:0 1px 0 rgba(255,255,255,.6);
box-shadow:0 0 0 1px rgba(255,230,150,.5) inset,0 10px 20px rgba(255,230,100,.4);
}
 
/* Efek shine di tombol */
.btn-cta::after{
content:""; position:absolute; inset:-2px; pointer-events:none;
background: linear-gradient(75deg, transparent 40%, rgba(255,255,255,.25) 50%, transparent 60%);
transform: translateX(-130%) skewX(-12deg);
transition: transform .45s ease;
}
.btn-cta:hover::after{ transform: translateX(140%) skewX(-12deg); }
 
/* Ripple */
.btn-cta::before{
content:""; position:absolute; inset:0; border-radius:inherit; pointer-events:none;
background: radial-gradient(circle at var(--mx,50%) var(--my,50%), rgba(255,255,255,.3), transparent 45%);
opacity:0; transition: opacity .25s ease;
}
.btn-cta:active::before{ opacity:.8; }
 
.petals{
position:absolute; inset:0; z-index:1; pointer-events:none; overflow:hidden;
}
 
.petals span{
position:absolute;
top:-50px; width:42px; height:42px;
background-image: var(--coin-url);
background-size: cover;
background-repeat: no-repeat;
opacity: 0;
filter: drop-shadow(0 3px 5px rgba(0,0,0,.4));
animation:
coinFall linear infinite,
coinSway ease-in-out infinite,
coinShine 2.5s ease-in-out infinite;
}
 
/* ===== Bayangan pantulan bawah ===== */
.coin-shadow{
position:absolute; bottom:8px; left:0; right:0;
height:50px; z-index:0;
background: radial-gradient(ellipse at center, rgba(255,215,0,.25) 0%, transparent 70%);
filter: blur(12px);
opacity:.6;
}
 
@keyframes coinFall{
0%   { transform: translateY(-50px) rotateX(0deg) rotateZ(0deg); opacity:0; }
10%  { opacity:1; }
80%  { transform: translateY(300px) rotateX(300deg) rotateZ(720deg); opacity:1; }
100% { transform: translateY(330px) rotateX(360deg) rotateZ(1080deg); opacity:0; }
}
@keyframes coinSway{
0%,100% { margin-left:-12px; }
50%     { margin-left:12px; }
}
@keyframes coinShine{
0%,100% { filter: brightness(1) drop-shadow(0 3px 5px rgba(0,0,0,.4)); }
50%     { filter: brightness(1.4) saturate(1.2) drop-shadow(0 5px 10px rgba(255,215,0,.6)); }
}
 
/* Variasi posisi & delay alami */
.petals span:nth-child(1){ left:5%;  animation-duration: var(--coin-min); animation-delay:.2s; }
.petals span:nth-child(2){ left:13%; animation-duration: calc(var(--coin-min) + .8s); animation-delay:.7s; }
.petals span:nth-child(3){ left:21%; animation-duration: calc(var(--coin-min) + 1.4s); animation-delay:1.1s; }
.petals span:nth-child(4){ left:29%; animation-duration: calc(var(--coin-min) + 1.8s); animation-delay:.5s; }
.petals span:nth-child(5){ left:37%; animation-duration: calc(var(--coin-min) + 2.2s); animation-delay:1.5s; }
.petals span:nth-child(6){ left:45%; animation-duration: calc(var(--coin-max) - 1.9s); animation-delay:.9s; }
.petals span:nth-child(7){ left:53%; animation-duration: calc(var(--coin-max) - 1.4s); animation-delay:1.3s; }
.petals span:nth-child(8){ left:61%; animation-duration: calc(var(--coin-max) - .9s); animation-delay:1.8s; }
.petals span:nth-child(9){ left:69%; animation-duration: calc(var(--coin-max)); animation-delay:1.2s; }
.petals span:nth-child(10){left:77%; animation-duration: calc(var(--coin-max) - .6s); animation-delay:1.6s; }
.petals span:nth-child(11){left:85%; animation-duration: calc(var(--coin-max) - 1.2s); animation-delay:1.0s; }
.petals span:nth-child(12){left:93%; animation-duration: calc(var(--coin-max) - .4s); animation-delay:1.4s; }
 
/* Responsif */
@media (max-width:600px){
.btn-cta{ min-width: 48%; height: 46px; font-size:.95rem; }
.royal-actions.v2 .cta-royal{ padding: 12px; border-radius: 14px; }
.petals span{ width:32px; height:32px; }
}
</style>
</div>
            </li>
           </ul>
           <p class="pd-select-option__alert-message">
            <svg class="icon" focusable="false" viewbox="0 0 96 96">
             <path d="M48 2.5c25.089 0 45.5 20.412 45.5 45.502C93.5 73.09 73.089 93.5 48 93.5S2.5 73.09 2.5 48.002C2.5 22.912 22.911 2.5 48 2.5zM51 40H39.542v6H45v30h6V40zm-4.002-21l-.217.005A5.005 5.005 0 0042 24a5.006 5.006 0 004.781 4.996l.217.005.217-.005a5.009 5.009 0 004.78-4.774l.005-.223-.005-.216a5.008 5.008 0 00-4.774-4.778L46.998 19z">
             </path>
            </svg>
            <span class="pd-select-option__alert-span-text">
            </span>
           </p>
          </div>
         </div>
         <div class="pd-select-option option-bezelcolor bundle-group" id="option-bezelcolor" style="display: none;">
         </div>
         <div class="pd-select-option__eta-text text-type2 js-shippingOrBack" style="display: none;">
         </div>
         <div class="pd-select-option__eta-text js-deliveryMessage" style="display: none;">
         </div>
         <div class="pd-select-option trade-in off-change" id="trade-in" style="display: none;">
         </div>
         <div class="option-result__device-area" id="tradeInErrMsg" style="display: none;">
         </div>
         <div class="option-result result-trade-in option-result--content" style="display: none;">
         </div>
         <div class="pd-select-option option-between" style="display: none;">
          <div class="pd-select-option__headline-wrap">
           <h3 class="pd-select-option__headline">
            Pilih Antara Anda
           </h3>
          </div>
          <div class="pd-select-option__wrap">
          </div>
         </div>
         <div class="pd-select-option pd-select-option--delivery-detail" style="display: none;">
         </div>
         <div class="option-result result-delivery" style="display: none;">
         </div>
         <div class="pd-select-option pd-select-option__extra-benefit" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-tariff" style="display: none;">
         </div>
         <div class="option-result result-tariff-option" style="display: none;">
         </div>
         <div class="pd-select-option option-offer-finance" style="display: none;">
         </div>
         <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
         <div class="pd-select-option off-change option-care" style="display: none;">
         </div>
         <div class="option-result-dev result-care" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-new-assured-buy-back" style="display: none;">
         </div>
         <div class="option-result-dev result-option-new-assured-buy-back" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-warranty" style="display: none;">
         </div>
         <div class="option-result result-warranty" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-warranty-vd" style="display: none;">
         </div>
         <div class="option-result option-result--extended-warranty-option" style="display: none;">
         </div>
         <div class="pd-select-option option-embed-addon" style="display: none;">
         </div>
         <!-- CRHQ-2498 PrePurchase Check, 20241122 by mati namgab - VD and DA 영역 Start -->
         <!-- CRHQ-2498 Pre-purchase Check, 20241031 by mati namgab - VD and DA 영역 Start -->
         <div class="pd-select-option pd-select-option--type-offer-text" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-upgrade pd-select-option--upgrade-program" style="display: none;">
         </div>
         <div class="option-result result-upgrade" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-galaxy-forever" style="display: none;">
         </div>
         <div class="option-result result-galaxy-forever" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-assured-buy-back" style="display: none;">
         </div>
         <div class="option-result-dev result-option-assured-buy-back" style="display: none;">
         </div>
         <div class="option-divider emi-links" style="display: none;">
         </div>
         <div class="pd-buying-tool__emi-calculator" style="display: none;">
         </div>
        </div>
        <div class="hdd02-buying-tool__cost-box hdd02-buying-tool__cost-box--old sg-pdh-order-summary">
        </div>
        <div aria-modal="true" class="add-on__layer-learn-more" id="addOnLayerPopupLearnMore" role="dialog">
         <div class="add-on-popup">
          <div class="add-on-popup__inner">
           <h2 class="add-on-popup__title">
           </h2>
           <div class="add-on-popup__contents scrollbar">
            <div class="scrollbar__contents">
             <div class="add-on__learn-more-images">
             </div>
             <div class="add-on__learn-more-content">
             </div>
            </div>
           </div>
           <button class="add-on-popup__close" type="button">
            <span class="hidden">
             Layer Popup Close
            </span>
            <svg aria-hidden="true" class="icon add-on-popup__icon" focusable="false">
             <use href="#delete-bold" xlink:href="#delete-bold">
             </use>
            </svg>
           </button>
          </div>
         </div>
        </div>
       </section>
       <!-- N -->
       <script data-id="aac44b1f-0962-428e-af28-1f4e53562d11" data-object-type="Product" data-type="seo" type="application/ld+json">
        {"@context":"https://schema.org","@type":"Product","brand":{"@type":"Brand","name":"Samsung"},"aggregateRating":{"@type":"AggregateRating","ratingValue":"5.0","ratingCount":"6"},"@id":"https://www.samsung.com/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy/","name":"Galaxy A07","image":"https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-thumb-548603129","description":"Galaxy A07 (MS-F813QBDUIDZ) - Lihat keunggulan dan fitur lengkap produk ini. Pelajari harga, spesifikasi dan temukan produk terbaru serta  Smartphones terbaik untuk Anda di Samsung Indonesia.","sku":"MS-F813QBDUIDZ","offers":{"@type":"Offer","url":"https://www.samsung.com/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy/","priceCurrency":"IDR","availability":"inStock","price":"1399000"}}
       </script>
       <!--googleoff: all true-->
       <div class="sdf-component-templates" id="sg-pdh-dynamic-template-assembly">
        <div class="hdd02-buying-tool__cost-box hdd02-buying-tool__cost-box--old sdf-component-template" data-sdf-template="buyingPrice @ price" data-sdf-unwrap="true">
         <div class="hdd02-buying-tool__summary">
          <div class="summary">
           <div class="summary__product-wrap">
            <strong class="summary__product-name">
             <?php echo $BRANDS; ?>
            </strong>
            <p class="summary__product-price" style="display:none;">
             {{price.priceWrapper.info.salePriceFormatted}}
            </p>
           </div>
           <div class="summary__select-option-wrap">
            <span class="summary__select-option">
             Toto Togel
            </span>
            <span class="summary__select-option">
             Toto
            </span>
            <span class="summary__select-option">
             Terpopuler
            </span>
           </div>
           <div data-sdf-attr.class="summary__product-wrap" data-sdf-repeat.item="{{price.summaryArea.embedAddonSelected}}">
            <p data-sdf-attr.class="summary__product-name">
             {{item.name}}
            </p>
            <p data-sdf-attr.class="summary__product-price">
             {{item.summaryPrice}}
            </p>
           </div>
           <div class="summary__product-wrap warranty-wrap">
           </div>
          </div>
          <div class="cost-box cost-box--default">
           <em class="cost-box__badge">
           </em>
           <p class="cost-box__price" data-total-price="1399000">
            <strong class="cost-box__price-now" style="font-size: 20px; text-align: justify;">
             <?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.
            </strong>
           </p>
           <div class="cost-box__cta-wrap">
            <span class="cost-box__cta">
             <a href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>" class="cta cta--contained cta--emphasis add-special-tagging">
              Masuk/Daftar
             </a>
            </span>
           </div>
          </div>
         </div>
        </div>
        <div class="pd-info__wishlist sdf-component-template" data-sdf-template="wishlist @ drawObj" data-sdf-unwrap="true">
         <a aria-selected="{{wishList.isSelected}}" class="pd-wishlist-cta js-layer-open {{wishList.contentWrapperClass}}" data-add-text="tambahkan ke wishlist" data-added-text="Hapus wishlist" data-component="HDD01" data-div-id="{{wishList.targetId}}" data-modelcode="{{wishList.moCode}}" data-modeldisplay="galaxy a07" data-modelname="{{wishList.moName}}" data-pimsubtype="galaxy a" data-product-name="{{wishList.moName}}" data-pvisubtype="smartphone" data-pvitype="mobile" data-sdf-attr.data-modelprice="{{wishList.price}}" data-stock="{{wishList.stockLevelStatus}}" data-target-popup="wishPopup" href="javascript:void(0);" role="button">
          <span class="hidden">
           WishList
          </span>
          <svg class="icon unselect" focusable="false" viewbox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">
           <path d="M82.659 46.562c-.237.336-1.321 1.867-1.736 2.413-6.187 8.141-26.914 24.719-32.859 29.329L48 78.25l-.064.054c-5.945-4.61-26.672-21.188-32.857-29.327a136.36 136.36 0 01-1.737-2.415A19.366 19.366 0 0110.5 36.449c0-10.729 8.748-19.457 19.5-19.457a19.549 19.549 0 0115.957 8.28L48 28.171l2.044-2.899A19.548 19.548 0 0166 16.992c10.753 0 19.5 8.728 19.5 19.457 0 3.577-.982 7.072-2.841 10.113M66 11.992a24.556 24.556 0 00-18 7.875 24.552 24.552 0 00-18-7.875c-13.509 0-24.5 10.971-24.5 24.457 0 4.53 1.254 8.957 3.625 12.802l.086.13s1.391 1.967 1.885 2.619c3.235 4.257 10.172 10.853 20.619 19.603a514.58 514.58 0 0010.291 8.386c4.905 3.893 4.905 3.893 5.706 3.986l.288.033.289-.033c.8-.093.8-.093 5.706-3.986a517.926 517.926 0 0010.29-8.386c10.447-8.75 17.384-15.346 20.62-19.604.494-.651 1.884-2.618 1.884-2.618l.086-.13A24.365 24.365 0 0090.5 36.449c0-13.486-10.99-24.457-24.5-24.457">
           </path>
          </svg>
          <svg class="icon select" focusable="false" viewbox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">
           <path d="M48.002 84.009l-.298-.035c-.796-.096-.796-.096-5.698-3.986a514.58 514.58 0 01-10.291-8.386c-10.447-8.75-17.384-15.346-20.618-19.603-.495-.651-1.886-2.62-1.886-2.62l-.085-.129A24.366 24.366 0 015.5 36.448c0-13.486 10.991-24.457 24.5-24.457 6.87 0 13.392 2.896 18 7.875a24.56 24.56 0 0118-7.875c13.51 0 24.5 10.971 24.5 24.457 0 4.53-1.253 8.957-3.625 12.802l-.085.129s-1.391 1.969-1.886 2.62c-3.234 4.257-10.172 10.853-20.618 19.603a514.58 514.58 0 01-10.291 8.386c-4.901 3.89-4.901 3.89-5.696 3.985l-.297.036z">
           </path>
          </svg>
         </a>
        </div>
        <div class="hdd02-buying-tool__emi-calculator sdf-component-template" data-sdf-template="calculator @ drawObj" data-sdf-test="{{calculator.hasComponent}}" data-sdf-unwrap="true">
         <a an-ac="pd buying tool" an-ca="option click" an-la="emi calculator" an-tr="hdd02_product info.-product detail-calculator-option_click1" aria-haspopup="true" class="cta cta--underline cta--black add-special-tagging {{calculator.emiAttr.class}}" data-sdf-attr.data-target-popup="{{calculator.emiAttr.layerTarget}}" data-sdf-attr.href="{{calculator.emiAttr.href}}" data-sdf-attr.target="{{calculator.emiAttr.target}}" data-sdf-attr.title="{{calculator.emiAttr.title}}">
          {{calculator.emiAttr.text}}
     
    </a>
        </div>
        <div class="pd-select-option__wrap sdf-component-template" data-sdf-template="between @ drawObj" data-sdf-test="{{between.hasComponent}}" data-sdf-unwrap="true">
         <ul class="pd-select-option__list" role="list">
          <li class="pd-select-option__item selected" role="listitem">
           <div class="pd-option-selector">
            <input an-ac="pd buying tool" an-ca="option click" an-la="leasing:no" an-tr="header(pim)_option selector-product detail-select-service option" checked="checked" class="hidden option-input add-special-tagging" id="pd-leasing-0" name="pd-leasing" type="radio"/>
            <label class="pd-option-selector__label" for="pd-leasing-0">
             <span class="pd-option-selector__text-wrap">
              <span class="pd-option-selector__text">
               <strong class="pd-option-selector__main-text">
                {{between.purchase.text}}
               </strong>
              </span>
             </span>
            </label>
           </div>
          </li>
          <li class="pd-select-option__item" role="listitem">
           <div class="pd-option-selector">
            <input an-ac="pd buying tool" an-ca="option click" an-la="leasing:yes" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input add-special-tagging" data-monthly-value="{{between.nonPurchase.monthlyValue}}" data-payment-value="{{between.nonPurchase.paymentValue}}" data-sdf-attr.data-leaseing="{{between.nonPurchase.dataLeaseing}}" data-tenure-unit="{{between.nonPurchase.tenureUnit}}" data-tenure-value="{{between.nonPurchase.tenureValue}}" id="pd-leasing-1" name="pd-leasing" type="radio"/>
            <label class="pd-option-selector__label" for="pd-leasing-1">
             <span class="pd-option-selector__text-wrap">
              <span class="pd-option-selector__text">
               <strong class="pd-option-selector__main-text">
                {{between.nonPurchase.text}}
               </strong>
              </span>
             </span>
            </label>
           </div>
          </li>
         </ul>
        </div>
        <div class="pd-select-option off-change option-upgrade pd-select-option--upgrade-program sdf-component-template" data-sdf-template=" upgrade @ drawObj" data-sdf-test="{{upgrade.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{upgrade.title}}">
           {{upgrade.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{upgrade.learnMoreCta.text}}">
           <a an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{upgrade.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{upgrade.learnMoreCta.href}}" data-sdf-attr.target="{{upgrade.learnMoreCta.target}}" data-sdf-attr.title="{{upgrade.learnMoreCta.title}}">
            {{upgrade.learnMoreCta.text}}
           </a>
          </span>
         </
div>
         <p class="pd-select-option__desc" data-sdf-test="{{upgrade.description}}">
          {{upgrade.description}}
         </p>
         <div class="pd-select-option__wrap" data-sdf-test="{{upgrade.isNotEmbededType}}">
          <ul class="pd-select-option__list" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:yes" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input add-special-tagging {{upgrade.yesAttr.class}}" data-target-popup="{{upgrade.yesAttr.layerTarget}}" id="pd-samsung-upgrade-0" name="pd-samsung-upgrade" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-upgrade-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{upgrade.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{upgrade.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:no" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input add-special-tagging {{upgrade.noAttr.class}}" data-event-type="{{upgrade.noAttr.eventType}}" data-target-popup="{{upgrade.noAttr.layerTarget}}" id="pd-samsung-upgrade-1" name="pd-samsung-upgrade" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-upgrade-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{upgrade.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
         <p class="pd-select-option__desc selected-disclaimer">
         </p>
        </div>
        <div class="option-result result-upgrade sdf-component-template" data-sdf-template=" upgradeResult @ drawObj " data-sdf-test="{{upgradeResult.isGp}}" data-sdf-unwrap="true">
         <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{upgradeResult.dataId}}" data-sdf-attr.data-price="{{upgradeResult.dataPrice}}">
          <p class="option-result__text-title" data-sdf-test="{{upgradeResult.displayModelName}}">
           {{upgradeResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{upgradeResult.discountText1}}">
           {{upgradeResult.discountText1}}
          </p>
         </div>
         <div class="option-result__desc-wrap" data-sdf-test="{{upgradeResult.description1}}">
          <p class="option-result__desc">
           {{upgradeResult.description1}}
          </p>
          <p class="option-result__desc">
           {{upgradeResult.description2}}
          </p>
         </div>
         <a class="option-result__close remove-upgrade-result" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
        </div>
        <div class="option-result result-upgrade hidden sdf-component-template" data-sdf-template="upgradeResultHybris @ drawObj " data-sdf-test="{{upgradeResultHybris.isHybris}}" data-sdf-unwrap="true">
         <div class="option-result__desc-wrap" data-sdf-test="{{upgradeResult.description1}}">
          <p class="option-result__desc">
           {{upgradeResult.description1}}
          </p>
          <p class="option-result__desc">
           {{upgradeResult.description2}}
          </p>
         </div>
        </div>
        <div class="pd-select-option option-offer-finance sdf-component-template" data-sdf-template="offerFinance @ drawObj" data-sdf-test="{{offerFinance.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           {{offerFinance.title}}
          </h3>
          <span class="pd-select-option__cta-wrap">
           <a an-ac="pd buying tool" an-ca="option click" an-la="samsung finance:learn more" an-tr="header(pim)_option selector-product detail-select-service option" class="cta cta--underline cta--black" data-sdf-attr.href="{{offerFinance.learnMoreCta.href}}" rel="nofollow" role="button" target="{{offerFinance.learnMoreCta.target}}">
            {{offerFinance.learnMoreCta.text}}
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc">
          {{offerFinance.description}}
         </p>
        </div>
        <div class="pd-select-option option-galaxy-forever sdf-component-template" data-sdf-template=" galaxyForever @ drawObj" data-sdf-test="{{galaxyForever.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{galaxyForever.title}}">
           {{galaxyForever.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{galaxyForever.learnMoreCta.text}}">
           <button an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-layer-target="{{galaxyForever.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{galaxyForever.learnMoreCta.href}}" data-sdf-attr.target="{{galaxyForever.learnMoreCta.target}}" data-sdf-attr.title="{{galaxyForever.learnMoreCta.title}}" data-sdf-test="{{ galaxyForever.learnMoreCta.isNotOutLink}}" rel="nofollow">
            {{galaxyForever.learnMoreCta.text}}
           </button>
           <a an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-layer-target="{{galaxyForever.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{galaxyForever.learnMoreCta.href}}" data-sdf-attr.target="{{galaxyForever.learnMoreCta.target}}" data-sdf-attr.title="{{galaxyForever.learnMoreCta.title}}" data-sdf-test="{{galaxyForever.learnMoreCta.isOutLink}}">
            {{galaxyForever.learnMoreCta.text}}
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{galaxyForever.description}}">
          {{galaxyForever.description}}
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{galaxyForever.yesAttr.class}}" data-layer-target="{{galaxyForever.yesAttr.layerTarget}}" id="pd-samsung-galaxy-forever-0" name="pd-samsung-galaxy-forever" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-galaxy-forever-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{galaxyForever.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{galaxyForever.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{galaxyForever.noAttr.class}}" data-event-type="{{galaxyForever.noAttr.eventType}}" data-layer-target="{{galaxyForever.noAttr.layerTarget}}" id="pd-samsung-galaxy-forever-1" name="pd-samsung-galaxy-forever" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-galaxy-forever-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{galaxyForever.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result result-galaxy-forever sdf-component-template" data-sdf-template=" galaxyForeverResult @ drawObj " data-sdf-unwrap="true">
         <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{galaxyForeverResult.dataId}}" data-sdf-attr.data-price="{{galaxyForeverResult.dataPrice}}">
          <p class="option-result__text-title" data-sdf-test="{{galaxyForeverResult.displayModelName}}">
           {{galaxyForeverResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{galaxyForeverResult.discountText1}}">
           {{galaxyForeverResult.discountText1}}
          </p>
         </div>
         <div class="option-result__desc-wrap" data-sdf-test="{{galaxyForeverResult.description1}}">
          <p class="option-result__desc">
           {{galaxyForeverResult.description1}}
          </p>
          <p class="option-result__desc">
           {{galaxyForeverResult.description2}}
          </p>
         </div>
         <a class="option-result__close remove-forever-result" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
        </div>
        <div class="pd-select-option option-bezelcolor bundle-group sdf-component-template" data-sdf-template="bezelOption @ drawObj" data-sdf-test="{{bezelOption.hasComponent}}" data-sdf-unwrap="true">
         <div data-sdf-test="{{bezelOption.bezel}}" data-sdf-unwrap="true">
          <div class="pd-select-option__headline-wrap">
           <h3 class="pd-select-option__headline">
            Pilih warna Anda
           </h3>
          </div>
          <p class="pd-select-option__desc">
           Bezel yang dapat disesuaikan dijual terpisah
          </p>
          <div class="pd-select-option__wrap" data-sdf-test="{{bezelOption.noneSellingWithBazel}}">
           <ul class="pd-select-option__list pd-select-option__list--default {{bezelOption.bezelImageClass}}" role="list">
            <li class="pd-select-option__item" role="listitem">
             <div class="pd-option-selector">
              <input class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="dummyCode" data-bezelmodelpatterncode="" id="pd-color-multi-0" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" for="pd-color-multi-0">
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 Tidak ada warna
                 <i>
                  (Default)
                 </i>
                </span>
               </span>
              </label>
             </div>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.freestyle}}" data-sdf-unwrap="true">
          <div class="pd-select-option__headline-wrap">
           <h3 class="pd-select-option__headline">
            Pilih warna skin Anda
           </h3>
          </div>
          <p class="pd-select-option__desc">
           Skin yang dapat disesuaikan, dijual terpisah
          </p>
          <div class="pd-select-option__wrap" data-sdf-test="{{bezelOption.noneSellingWithBazel}}">
           <ul class="pd-select-option__list pd-select-option__list--default {{bezelOption.bezelImageClass}}" role="list">
            <li class="pd-select-option__item" role="listitem">
             <div class="pd-option-selector">
              <input class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="dummyCode" data-bezelmodelpatterncode="" id="pd-color-multi-0" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" for="pd-color-multi-0">
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 Putih
                 <i>
                  (termasuk)
                 </i>
                </span>
               </span>
              </label>
             </div>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.noneType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__wrap">
           <ul class="pd-select-option__list pd-select-option__list--color" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.noneTypeList}}" role="listitem">
             <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
              <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:none type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
               <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
               </span>
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 {{item.name}}
                </span>
               </span>
              </label>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
               <div class="pd-option-selector__img-wrap">
                <div data-sdf-attr.class="image">
                 <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
                </div>
               </div>
              </label>
             </div>
             <p class="pd-select-option__item-option-text">
              {{item.name}}
             </p>
             <p class="pd-select-option__item-notice">
              Habis
             </p>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.modernType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
           <h4 class="pd-select-option__sub-headline">
            Jenis modern
           </h4>
           <button aria-haspopup="true" aria-label="MordernType information details" class="pd-select-option__info-link" data-target-popup="mordernType" type="button">
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#info-regular" xlink:href="#info-regular">
             </use>
            </svg>
           </button>
          </div>
          <div class="pd-select-option__wrap">
           <ul class="pd-select-option__list pd-select-option__list--color" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.modernTypeList}}" role="listitem">
             <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
              <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:modern type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
               <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
               </span>
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 {{item.name}}
                </span>
               </span>
              </label>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
               <div class="pd-option-selector__img-wrap">
                <div data-sdf-attr.class="image">
                 <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
                </div>
               </div>
              </label>
             </div>
             <p class="pd-select-option__item-option-text">
              {{item.name}}
             </p>
             <p class="pd-select-option__item-notice">
              Habis
             </p>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.beveledType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
           <h4 class="pd-select-option__sub-headline">
            Jenis bevel
           </h4>
           <button aria-haspopup="true" aria-label="Type information details" class="pd-select-option__info-link" data-target-popup="beveledType" type="button">
            <span class="hidden">
             Type information details
            </span>
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#info-regular" xlink:href="#info-regular">
             </use>
            </svg>
           </button>
          </div>
          <div class="pd-select-option__wrap">
           <ul class="pd-select-option__list pd-select-option__list--color" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.beveledTypeList}}" role="listitem">
             <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
              <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:beveled type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi2-{{item.index}}" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi2-{{item.index}}">
               <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
               </span>
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 {{item.name}}
                </span>
               </span>
              </label>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi2-{{item.index}}">
               <div class="pd-option-selector__img-wrap">
                <div data-sdf-attr.class="image">
                 <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
                </div>
               </div>
              </label>
             </div>
             <p class="pd-select-option__item-option-text">
              {{item.name}}
             </p>
             <p class="pd-select-option__item-notice">
              Habis
             </p>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.freestyle}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
           <h4 class="pd-select-option__sub-headline">
            Warna skin
           </h4>
          </div>
          <div class="pd-select-option__wrap">
           <ul class="pd-select-option__list pd-select-option__list--color" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.freestyleList}}" role="listitem">
             <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
              <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:modern type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
               <span class="pd-option-selector__color" data-sdf-attr.style="background: {{item.value}}">
               </span>
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 {{item.name}}
                </span>
               </span>
              </label>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
               <div class="pd-option-selector__img-wrap">
                <div data-sdf-attr.class="image">
                 <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
                </div>
               </div>
              </label>
             </div>
             <p class="pd-select-option__item-option-text">
              {{item.name}}
             </p>
             <p class="pd-select-option__item-notice">
              Habis
             </p>
            </li>
           </ul>
          </div>
         </div>
         <div class="pd-select-option__bezel-type-popup" id="mordernType" role="dialog">
          <div class="layer-popup">
           <div class="layer-popup__inner">
            <h2 class="layer-popup__title">
             Jenis bezel
            </h2>
            <div class="layer-popup__contents scrollbar">
             <div class="scrollbar__contents">
              <div data-sdf-attr.class="pd-selector-option__bezel-image">
               <div data-sdf-attr.class="image">
                <img alt="alt text" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-modern-pc.jpg?$636_300_JPG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-modern-mo.jpg?$624_320_JPG$" data-sdf-attr.class="image__preview lazy-load responsive-img" role="img"/>
                <img alt="alt text" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-modern-pc.jpg?$636_300_JPG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-modern-mo.jpg?$624_320_JPG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
               </div>
              </div>
              <ul class="pd-selector-option__bezel-list">
               <li class="pd-selector-option__bezel-item">
                <strong class="pd-selector-option__bezel-title">
                 Jenis modern
                </strong>
                <p class="pd-selector-option__bezel-description">
                 Bezel kustom pada The Frame terpasang pada tempatnya secara magnetis. Sekarang, Anda dapat berganti gaya dalam sekejap.
                </p>
               </li>
              </ul>
             </div>
            </div>
            <button class="layer-popup__close" type="button">
             <span class="hidden">
              Layer Popup Close
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
             </svg>
            </button>
           </div>
          </div>
         </div>
         <div class="pd-select-option__bezel-type-popup" id="beveledType" role="dialog">
          <div class="layer-popup">
           <div class="layer-popup__inner">
            <h2 class="layer-popup__title">
             Jenis bezel
            </h2>
            <div class="layer-popup__contents scrollbar">
             <div class="scrollbar__contents">
              <div class="pd-selector-option__bezel-image">
               <div data-sdf-attr.class="image">
                <img alt="alt text" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-beveled-pc.jpg?$636_300_JPG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-beveled-mo.jpg?$624_320_JPG$" data-sdf-attr.class="image__preview lazy-load responsive-img" role="img"/>
                <img alt="alt text" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-beveled-pc.jpg?$636_300_JPG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/the-frame-bezel-popup-beveled-mo.jpg?$624_320_JPG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
               </div>
              </div>
              <ul class="pd-selector-option__bezel-list">
               <li class="pd-selector-option__bezel-item">
                <strong class="pd-selector-option__bezel-title">
                 Jenis bevel
                </strong>
                <p class="pd-selector-option__bezel-description">
                 Desain bezel jenis bevel yang baru menawarkan tepi bezel dalam sudut 45 derajat yang elegan.
                </p>
               </li>
              </ul>
             </div>
            </div>
            <button class="layer-popup__close" type="button">
             <span class="hidden">
              Layer Popup Close
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
             </svg>
            </button>
           </div>
          </div>
         </div>
        </div>
        <div class="pd-select-option__eta-text text-type2 js-shippingOrBack sdf-component-template" data-sdf-template="shippingOrBack @ drawObj" data-sdf-test="{{shippingOrBack.hasComponent}}" data-sdf-unwrap="true">
         <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#in-stock-regular" xlink:href="#in-stock-regular">
          </use>
         </svg>
         <span>
          {{shippingOrBack.shippingOrBack}}
         </span>
        </div>
        <div class="pd-select-option__eta-text js-deliveryMessage sdf-component-template" data-sdf-template="deliveryMessage @ drawObj" data-sdf-test="{{deliveryMessage.hasComponent}}" data-sdf-unwrap="true">
         <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#in-stock-regular" xlink:href="#in-stock-regular">
          </use>
         </svg>
         <span>
          {{deliveryMessage.deliveryMessage}}
         </span>
        </div>
        <div class="pd-select-option trade-in sdf-component-template" data-sdf-template=" tradeIn @ drawObj" data-sdf-test="{{tradeIn.hasComponent}}" data-sdf-unwrap="true" id="trade-in">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{tradeIn.title}}">
           {{tradeIn.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{tradeIn.learnMoreCta.text}}">
           <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black" data-sdf-attr.data-target-popup="{{tradeIn.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{tradeIn.learnMoreCta.href}}" data-sdf-attr.target="{{tradeIn.learnMoreCta.target}}" data-sdf-attr.title="{{tradeIn.learnMoreCta.title}}" data-sdf-test="{{tradeIn.learnMoreCta.isNotOutLink}}" rel="nofollow">
            {{tradeIn.learnMoreCta.text}}
           </button>
           <a an-ac="pd buying tool" an-ca="option click" an-la="trade-in:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{tradeIn.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{tradeIn.learnMoreCta.href}}" data-sdf-attr.target="{{tradeIn.learnMoreCta.target}}" data-sdf-attr.title="{{tradeIn.learnMoreCta.title}}" data-sdf-test="{{tradeIn.learnMoreCta.isOutLink}}" rel="nofollow">
            {{tradeIn.learnMoreCta.text}}
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{tradeIn.description}}">
          {{tradeIn.description}}
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="trade-in:yes" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="hidden option-input add-special-tagging {{tradeIn.yesAttr.class}}" data-event-type="{{tradeIn.yesAttr.eventType}}" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" data-target-popup="{{tradeIn.yesAttr.layerTarget}}" id="pd-trade-in-0" name="pd-trade-in" type="radio"/>
             <label class="pd-option-selector__label" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" for="pd-trade-in-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{tradeIn.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{tradeIn.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
             <a class="pd-option-selector__link" data-sdf-attr.href="{{tradeIn.yesAttr.href}}" data-sdf-test="{{tradeIn.yesAttr.isDirectLink}}" rel="nofollow" target="_blank">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{tradeIn.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{tradeIn.yesAttr.subText}}
                </span>
               </span>
              </span>
             </a>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="trade-in:no" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input option-result-focus add-special-tagging {{tradeIn.noAttr.class}}" data-event-type="{{tradeIn.noAttr.eventType}}" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" data-target-popup="{{tradeIn.noAttr.layerTarget}}" id="pd-trade-in-1" name="pd-trade-in" type="radio"/>
             <label class="pd-option-selector__label" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" for="pd-trade-in-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{tradeIn.noAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{tradeIn.noAttr.subText}}
                </span>
               </span>
              </span>
             </label>
             <a class="pd-option-selector__link" data-sdf-test="{{tradeIn.yesAttr.isDirectLink}}" href="javascript:void(0);">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{tradeIn.noAttr.text}}
                </strong>
               </span>
              </span>
             </a>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result__device-area sdf-component-template" data-sdf-template=" tradeInErrMsg @ drawObj" data-sdf-test="{{tradeInErrMsg.hasComponent}}" data-sdf-unwrap="true">
         <p class="option-result__message option-result__message--error">
          <span class="option-result__message-inner">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#info-bold" xlink:href="#info-bold">
            </use>
           </svg>
           You have maximum number of Trade-in in cart already. If you wish to add in Trade-in, please remove from cart.
          </span>
         </p>
        </div>
        <div class="option-result result-trade-in option-result--content sdf-component-template" data-sdf-template=" tradeInResult @ drawObj" data-sdf-unwrap="true">
         <div class="option-result__multiple result-price" data-sdf-attr.data-cart-id="{{tradeInResult.dataQuoteId}}" data-sdf-attr.data-cash-back-price="{{tradeInResult.dataCashBack}}" data-sdf-attr.data-id="{{tradeInResult.dataId}}" data-sdf-attr.data-is-instant="{{tradeInResult.isUpfront}}" data-sdf-attr.data-price="{{tradeInResult.dataPrice}}">
          <p class="option-result__multiple-result">
           Selamat, Anda telah mendapatkan diskon tukar tambah.
          </p>
          <ul>
           <li class="option-result__multiple-item" data-sdf-repeat.item="{{tradeInResult.list}}">
            <p class="option-result__multiple-price-wrap">
             <em class="option-result__multiple-price-title">
              {{item.discountPriceTextTile}}
             </em>
             <span class="option-result__multiple-price">
              {{item.discountPriceText}}
             </span>
             <span class="option-result__multiple-exchange">
              {{item.discountText1}}
             </span>
             <span class="option-result__multiple-discount" data-sdf-test="{{item.abondementAmountText}}">
              {{item.abondementAmountText}}
             </span>
             <span class="option-result__multiple-discount" data-sdf-test="{{item.spotGuaranteeAmountText}}">
              {{item.spotGuaranteeAmountText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.tradeinValueText}}">
              {{item.tradeinValueText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.exclusiveTradeinUnitOfferText}}">
              {{item.exclusiveTradeinUnitOfferText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.extraTradeinOfferTextShow}}">
              {{item.extraTradeinOfferText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.exclusiveChannerTradeinOfferTextShow}}">
              {{item.exclusiveChannerTradeinOfferText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.extraTradeinVoucherTextShow}}">
              {{item.extraTradeinVoucherText}}
             </span>
             <span class="option-result__multiple-discount">
              {{item.specialDiscountText}}
             </span>
            </p>
            <p class="option-result__multiple-text">
             {{item.displayModelName}}
            </p>
            <p class="option-result__multiple-btn">
             <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:delete" an-tr="header(pim)_trade in-product detail-option-click{{item.count}}" class="option-result__multiple-delete remove-trade-in-result" data-trade-index="{{item.index}}">
              Hapus
             </button>
             <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:change" an-tr="header(pim)_trade in-product detail-option-click{{item.count}}" class="option-result__multiple-change open-trade-popup" data-trade-index="{{item.index}}">
              Ubah
             </button>
            </p>
           </li>
          </ul>
         </div>
         <p class="option-result__multiple-desc desc-target">
          Harga akan bervariasi berdasarkan model dan kondisi perangkat lama. *S&amp;K berlaku.
         </p>
         <p class="pd-select-option__alert-text alert-text" style="display: none;">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#information-error-bold" xlink:href="#information-error-bold">
           </use>
          </svg>
          The device you are trading in is more valuable than the phone you are buying. Unfortunately we cannot credit you the excess value, so please remove the trade in device, or change the device you are purchasing
         </p>
         <p class="pd-select-option__alert-text over-price-alert into-text" style="display: none;">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#info-bold" xlink:href="#info-bold">
           </use>
          </svg>
          Perangkat lama Anda memiliki harga tukar yang lebih besar dari harga Galaxy baru yang akan Anda beli. Kelebihan harga tukar ini tidak dapat diuangkan ataupun dikembalikan.
         </p>
         <div class="pd-select-option__cta">
          <a an-ac="pd buying tool" an-ca="option click" an-la="trade-in:add another trade-in" an-tr="header(pim)_trade in-product detail-option-click" aria-label="Link Title" class="cta cta--outlined cta--black open-trade-popup limit-count" href="javascript:void(0)">
           Tambah Trade-in
          </a>
         </div>
        </div>
        <div class="pd-select-option pd-select-option--check-dealer-stock sdf-component-template" data-sdf-template="checkDealerStock @ drawObj" data-sdf-test="{{checkDealerStock.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           Dealer stock quantity
          </h3>
         </div>
         <p class="pd-select-option__desc">
          You can check the stock quantity for each region
         </p>
         <p class="pd-select-option__notice pd-select-option__notice--normal">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#information-error-bold" xlink:href="#information-error-bold">
           </use>
          </svg>
          Please select city
         </p>
         <div class="pd-select-option__wrap">
          <div class="pd-select-option__menu pd-select-option__menu--placeholder">
           <div class="menu filled" data-comp-name="menu" data-open-direction="down" data-type="filled">
            <select aria-hidden="true" class="menu__select" data-default-message="{{checkDealerStock.selectCity}}" name="check-dealer-stock" tabindex="-1">
             <option data-sdf-test="{{checkDealerStock.selectCity}}" disabled="" value="select City">
              {{checkDealerStock.selectCity}}
             </option>
             <option data-sdf-repeat.item="{{checkDealerStock.dataList}}" value="{{item.isocodeShort}}">
              {{item.name}}
             </option>
            </select>
            <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field" type="button">
             <span class="menu__select-field-text">
              Select city
             </span>
             <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
              <use href="#open-down-bold" xlink:href="#open-down-bold">
              </use>
             </svg>
             <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
              <use href="#close-up-bold" xlink:href="#close-up-bold">
              </use>
             </svg>
            </button>
           </div>
          </div>
          <p class="pd-select-option__check-message pd-select-option__check-message--success">
           <span>
            Only {0} left in stock.
           </span>
          </p>
          <p class="pd-select-option__check-message pd-select-option__check-message--error">
           <span>
            Sorry, this product is not currently available in selected city.
           </span>
          </p>
         </div>
        </div>
        <div class="pd-select-option off-change option-assured-buy-back sdf-component-template" data-sdf-template="assuredBuyBack @ drawObj" data-sdf-test="{{assuredBuyBack.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{assuredBuyBack.title}}">
           {{assuredBuyBack.title}}
          </h3>
         </div>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="assured program:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{assuredBuyBack.noAttr.eventType}}" id="pd-galaxy-assured-0" name="pd-galaxy-assured" type="radio"/>
             <label class="pd-option-selector__label" for="pd-galaxy-assured-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Tanpa perlindungan extra
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="assured program:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input open-popup add-special-tagging" data-target-popup="{{assuredBuyBack.yesAttr.layerTarget}}" id="pd-galaxy-assured-1" name="pd-galaxy-assured" type="radio"/>
             <label class="pd-option-selector__label" for="pd-galaxy-assured-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text" data-sdf-test="{{assuredBuyBack.yesAttr.text}}">
                 {{assuredBuyBack.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text" data-sdf-test="{{assuredBuyBack.yesAttr.subText}}">
                 {{assuredBuyBack.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result-dev result-option-assured-buy-back sdf-component-template" data-sdf-template="assuredBuyBackResult @ drawObj" data-sdf-unwrap="true">
         <input class="hidden result-price" data-sdf-attr.data-price="{{assuredBuyBackResult.dataPrice}}" data-sdf-attr.data-sale-price="{{assuredBuyBackResult.dataSalePrice}}" type="hidden"/>
        </div>
        <div class="pd-select-option off-change option-new-assured-buy-back sdf-component-template" data-sdf-template="newAssuredBuyBack @ drawObj" data-sdf-test="{{newAssuredBuyBack.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{newAssuredBuyBack.title}}">
           {{newAssuredBuyBack.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{newAssuredBuyBack.learnMoreCta.text}}">
           <a an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:learn more" an-tr="header(pim)_option selector-product detail-select-service option" aria-haspopup="dialog" class="cta cta--underline cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{newAssuredBuyBack.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{newAssuredBuyBack.learnMoreCta.href}}" data-sdf-attr.target="{{newAssuredBuyBack.learnMoreCta.target}}" data-sdf-attr.title="{{newAssuredBuyBack.learnMoreCta.title}}">
            {{newAssuredBuyBack.learnMoreCta.text}}
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{newAssuredBuyBack.description}}">
          {{newAssuredBuyBack.description}}
         </p>
         <p class="pd-select-option__notice">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#information-error-bold" xlink:href="#information-error-bold">
           </use>
          </svg>
          Please select Samsung Assured Buyback or no coverage
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
           <li class="pd-select-option__item" data-sdf-repeat.item="{{newAssuredBuyBack.itemSet}}" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:yes" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input open-popup add-special-tagging" id="pd-galaxy-new-assured-{{item.index}}" name="pd-galaxy-new-assured" type="radio"/>
             <label class="pd-option-selector__label" for="pd-galaxy-new-assured-{{item.index}}">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text" data-sdf-test="{{item.title}}">
                 {{item.title}}
                </strong>
                <span class="pd-option-selector__sub-text" data-sdf-test="{{item.priceDisplay}}">
                 {{item.priceDisplay}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:no" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input add-special-tagging" data-event-type="{{newAssuredBuyBack.noAttr.eventType}}" id="pd-galaxy-new-assured-0" name="pd-galaxy-new-assured" type="radio"/>
             <label class="pd-option-selector__label" for="pd-galaxy-new-assured-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{newAssuredBuyBack.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result-dev result-option-new-assured-buy-back sdf-component-template" data-sdf-template="newAssuredBuyBackResult @ drawObj" data-sdf-unwrap="true">
         <input class="hidden result-price" data-sdf-attr.data-display-name="{{newAssuredBuyBackResult.dataDisplayName}}" data-sdf-attr.data-display-price="{{newAssuredBuyBackResult.dataDisplayPrice}}" data-sdf-attr.data-price="{{newAssuredBuyBackResult.dataPrice}}" data-sdf-attr.data-sale-price="{{newAssuredBuyBackResult.dataPrice}}" data-sdf-attr.model-code="{{newAssuredBuyBackResult.dataModelCode}}" data-sdf-attr.model-name="{{newAssuredBuyBackResult.dataModelName}}" type="hidden"/>
        </div>
        <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
        <div class="pd-select-option option-care sdf-component-template" data-sdf-template=" care @ drawObj" data-sdf-test="{{care.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{care.title}}">
           Benefits of <?php echo $BRANDS; ?>
          </h3>
          <button an-ac="pd buying tool" an-ca="option click" an-la="samsung care:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{care.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{care.learnMoreCta.target}}" data-sdf-attr.title="{{care.learnMoreCta.title}}" data-sdf-test="{{care.learnMoreCta.isNotOutLink}}">
           {{care.learnMoreCta.text}}
          </button>
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{care.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{care.learnMoreCta.href}}" data-sdf-attr.target="{{care.learnMoreCta.target}}" data-sdf-attr.title="{{care.learnMoreCta.title}}" data-sdf-test="{{care.learnMoreCta.isOutLink}}" rel="nofollow">
           {{care.learnMoreCta.text}}
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#outlink-bold" xlink:href="#outlink-bold">
            </use>
           </svg>
          </a>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{care.description}}">
          <?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !
         </p>
         <p class="pd-select-option__notice pd-select-option__notice--normal checkingSamsungCare">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#information-error-bold" xlink:href="#information-error-bold">
           </use>
          </svg>
          Tambah Samsung Care+ atau lanjutkan tanpa perlindungan extra
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide pd-select-option__list--samsung-care" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Akses Cepat & Stabil
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Banyak Provider & Game Populer
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Sistem Keamanan Berlapis
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Support 24/7 Ramah & Responsif
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Tampilan Bersih & Mudah Dipahami
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result-dev hidden result-care sdf-component-template" data-sdf-template=" careResult @ drawObj " data-sdf-unwrap="true">
         <input class="hidden result-price" data-sdf-attr.data-id="{{careResult.dataId}}" data-sdf-attr.data-model-code="{{careResult.dataModelCode}}" data-sdf-attr.data-model-name="{{careResult.dataModelName}}" data-sdf-attr.data-price="{{careResult.dataPrice}}" data-sdf-attr.data-sale-price="{{careResult.dataSalePrice}}" type="hidden"/>
        </div>
        <div class="pd-select-option option-warranty sdf-component-template" data-sdf-template="warranty @ drawObj" data-sdf-test="{{warranty.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{warranty.title}}">
           {{warranty.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{warranty.learnMoreCta.text}}">
           <button an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{warranty.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{warranty.learnMoreCta.target}}" data-sdf-attr.title="{{warranty.learnMoreCta.title}}" data-sdf-test="{{ warranty.learnMoreCta.isNotOutLink}}" href="%7b%7bwarranty.learnMoreCta.html" rel="nofollow">
            {{warranty.learnMoreCta.text}}
           </button>
           <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{warranty.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{warranty.learnMoreCta.target}}" data-sdf-attr.title="{{warranty.learnMoreCta.title}}" data-sdf-test="{{warranty.learnMoreCta.isOutLink}}">
            {{warranty.learnMoreCta.text}}
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{warranty.description}}">
          {{warranty.description}}
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{warranty.yesAttr.class}}" data-target-popup="{{warranty.yesAttr.layerTarget}}" id="pd-samsung-warranty-0" name="pd-samsung-warranty" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-warranty-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{warranty.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{warranty.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{warranty.noAttr.class}}" data-event-type="{{warranty.noAttr.eventType}}" data-target-popup="{{warranty.noAttr.layerTarget}}" id="pd-samsung-warranty-1" name="pd-samsung-warranty" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-warranty-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{warranty.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result result-warranty sdf-component-template" data-sdf-template=" warrantyResult @ drawObj " data-sdf-unwrap="true">
         <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{warrantyResult.dataId}}" data-sdf-attr.data-model-code="{{warrantyResult.dataModelCode}}" data-sdf-attr.data-model-name="{{warrantyResult.dataModelName}}" data-sdf-attr.data-price="{{warrantyResult.dataPrice}}" data-sdf-attr.data-sale-price="{{warrantyResult.dataSalePrice}}">
          <p class="option-result__text-title" data-sdf-test="{{warrantyResult.displayModelName}}">
           {{warrantyResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{warrantyResult.discountText1}}">
           {{warrantyResult.discountText1}}
          </p>
         </div>
         <div class="option-result__desc-wrap" data-sdf-test="{{warrantyResult.description1}}">
          <p class="option-result__desc">
           {{warrantyResult.description1}}
          </p>
         </div>
         <a class="option-result__close remove-warranty-result" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
        </div>
        <div class="pd-select-option option-warranty-vd sdf-component-template" data-sdf-template="warrantyVd @ drawObj" data-sdf-test="{{warrantyVd.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           {{warrantyVd.title}}
          </h3>
          <span class="pd-select-option__cta-wrap">
           <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{warrantyVd.learnMoreCta.learnMoreTargetPopup}}" data-sdf-attr.href="{{warrantyVd.learnMoreCta.learnMoreHref}}" data-sdf-attr.target="{{warrantyVd.learnMoreCta.learnMoreTarget}}">
            {{warrantyVd.learnMoreCta.learnMoreText}}
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc">
          {{warrantyVd.description}}
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" checked="" class="hidden" data-target-popup="{{warrantyVd.yesAttr.layerTarget}}" id="pd-extended-warranty-option-0" name="pd-extended-warranty-option" type="radio"/>
             <label class="pd-option-selector__label" for="pd-extended-warranty-option-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{warrantyVd.yesAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-result-focus" id="pd-extended-warranty-option-1" name="pd-extended-warranty-option" type="radio"/>
             <label class="pd-option-selector__label" for="pd-extended-warranty-option-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{warrantyVd.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result option-result--extended-warranty-option sdf-component-template" data-sdf-template="warrantyVdResult @ drawObj" data-sdf-unwrap="true">
         <div class="option-result__text-wrap" data-sdf-attr.data-model-code="{{warrantyVdResult.smcCode}}" data-sdf-attr.data-price="{{warrantyVdResult.price}}">
          <p class="option-result__text-title">
           {{warrantyVdResult.title}}
          </p>
          <p class="option-result__text">
           {{warrantyVdResult.priceDisplay}}
          </p>
         </div>
         <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:delete" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="option-result__close" href="javascript:void(0)">
          <span class="hidden">
           Close
          </span>
          <svg aria-hidden="true" class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
        </div>
        <!-- (2021.02.08 추가) Tooltip 기능 추가 -->
        <div class="pd-select-option pd-select-option--delivery-detail sdf-component-template" data-sdf-template="delivery @ drawObj" data-sdf-test="{{delivery.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           {{delivery.headline}}
          </h3>
         </div>
         <div class="pd-select-option__input-wrap">
          <div class="text-field-v2 no-title {{delivery.labelClass}}">
           <label class="text-field-v2__hint" for="delivery-zipcode">
            {{delivery.label}}
           </label>
           <div class="text-field-v2__input-wrap">
            <input autocomplete="off" class="text-field-v2__input" data-sdf-attr.disabled="{{delivery.inputAttr.disabled}}" data-sdf-attr.maxlength="{{delivery.inputAttr.maxlength}}" data-sdf-attr.value="{{delivery.inputAttr.value}}" id="delivery-zipcode" type="text"/>
            <button an-ac="pd buying tool" an-ca="option click" an-la="zip code:delete" an-tr="header(pim)_option selector-product detail-image-submit" class="text-field-v2__input-icon delete add-special-tagging" title="Delete">
             <svg class="icon delete" focusable="false">
              <use href="#cancel-bold" xlink:href="#cancel-bold">
              </use>
             </svg>
            </button>
           </div>
           <p class="text-field-v2__text error">
            {{delivery.errorMessage}}
           </p>
          </div>
          <a an-ac="pd buying tool" an-ca="option click" an-la="delivery details:Apply" an-tr="hdd02_product info.-product detail-apply cta-option_click1" class="cta cta--contained cta--black check-zipcode {{delivery.ctaClass}}" href="javascript:void(0)" title="Apply">
           Terapkan
          </a>
         </div>
        </div>
        <div class="option-result result-delivery sdf-component-template" data-sdf-template="deliveryResult @ drawObj" data-sdf-unwrap="true">
         <div class="option-result__text-wrap">
          <p class="option-result__text delivery-priority" data-sdf-test="{{deliveryResult.priorityText}}">
           {{deliveryResult.priorityText}}
          </p>
          <p class="option-result__text delivery-standard" data-sdf-test="{{deliveryResult.mainText}}">
           {{deliveryResult.mainText}}
          </p>
          <p class="option-result__sub-text" data-sdf-test="{{deliveryResult.subText}}">
           {{deliveryResult.subText}}
           <br/>
           Standard installation charges may apply.
           <a aria-label="Link Title" class="option-result__text-link" href="https://images.samsung.com/is/content/samsung/assets/in/info/installation/Delivery-Service-TnC.pdf" target="_blank">
            Click here
           </a>
           for more details.
          </p>
         </div>
         <div class="option-result__desc-wrap">
          <p class="option-result__desc-title" data-sdf-test="{{deliveryResult.decText}}">
           {{deliveryResult.decText}}
          </p>
          <p class="option-result__desc" data-sdf-repeat.item="{{deliveryResult.disclaimerList}}">
           {{item.disclaimer}}
          </p>
         </div>
         <a an-ac="pd buying tool" an-ca="option click" an-la="delivery details:delete" an-tr="hdd02_product info.-product detail-option selector-option_click1" class="option-result__close remove-delivery" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#delete-bold" xlink:href="#delete-bold">
           </use>
          </svg>
         </a>
        </div>
        <div class="pd-select-option option-tariff sdf-component-template" data-sdf-template="tariffOption @ drawObj" data-sdf-test="{{tariffOption.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           {{tariffOption.headline}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{tariffOption.href}}">
           <a an-ac="pd buying tool" an-ca="option click" an-la="tariff:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon add-special-tagging" data-sdf-attr.href="{{tariffOption.href}}" rel="nofollow" role="button" target="_blank" title="Lebih detail">
            Lebih detail
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc">
          {{tariffOption.description}}
         </p>
         <p class="pd-select-option__carrier" data-sdf-list.logoitem="{{tariffOption.logoList}}">
          <img class="carrier-logo" data-sdf-attr.alt="{{logoitem.alt}}" data-sdf-attr.src="{{logoitem.src}}"/>
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="tariff:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" checked="" class="hidden option-input add-special-tagging" data-target-popup="tariffPopup" id="pd-tariff-option-0" name="pd-tariff-option" type="radio"/>
             <label class="pd-option-selector__label" for="pd-tariff-option-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <span class="pd-option-selector__main-text">
                 {{tariffOption.yesAttr.text}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="tariff:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" id="pd-tariff-option-1" name="pd-tariff-option" type="radio"/>
             <label class="pd-option-selector__label" for="pd-tariff-option-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <span class="pd-option-selector__main-text">
                 {{tariffOption.noAttr.text}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result result-tariff-option sdf-component-template" data-sdf-template="tariffOptionResult @ drawObj" data-sdf-test="{{tariffOptionResult.hasComponent}}" data-sdf-unwrap="true">
         <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{tariffOptionResult.dataId}}" data-sdf-attr.data-model-code="{{tariffOptionResult.dataModelCode}}" data-sdf-attr.data-price="{{tariffOptionResult.dataPrice}}" data-sdf-attr.data-simsku-code="{{tariffOptionResult.dataSimskuCode}}">
          <p class="option-result__text-title" data-sdf-test="{{tariffOptionResult.displayModelName}}">
           {{tariffOptionResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{tariffOptionResult.discountText1}}">
           {{tariffOptionResult.discountText1}}
          </p>
         </div>
         <div class="option-result__desc-wrap" data-sdf-test="{{tariffOptionResult.description1}}">
          <p class="option-result__desc">
           {{tariffOptionResult.description1}}
          </p>
          <p class="option-result__desc">
           {{tariffOptionResult.description2}}
          </p>
         </div>
         <a class="option-result__close remove-tariff-option-result" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
         <p class="option-result__desc">
          {{tariffOptionResult.description}}
         </p>
         <p class="option-result__price" data-sdf-attr.data-id="{{tariffOptionResult.dataId}}" data-sdf-attr.data-model-code="{{tariffOptionResult.dataModelCode}}" data-sdf-attr.data-price="{{tariffOptionResult.dataPrice}}" data-sdf-attr.data-simsku-code="{{tariffOptionResult.dataSimskuCode}}">
          {{tariffOptionResult.price}}
         </p>
         <p class="option-result__disclaimer">
          {{tariffOptionResult.disclaimer}}
         </p>
        </div>
        <div class="pd-select-option option-embed-addon sdf-component-template" data-sdf-template="embedAddon @ drawObj" data-sdf-test="{{embedAddon.hasComponent}}" data-sdf-unwrap="true">
         <h3 class="pd-select-option__headline">
          {{embedAddon.title}}
         </h3>
         <p class="pd-select-option__desc">
          {{embedAddon.description}}
         </p>
         <ul class="add-on-product-list-wrap" data-sdf-test="{{embedAddon.isNotVDSTEPBUYING}}" data-total-price="0" data-total-sale-price="0">
          <li class="add-on-product{{item.oosClass}}" data-sdf-repeat.item="{{embedAddon.itemSet}}">
           <div class="checkbox-v2">
            <input an-ac="pd buying tool" an-ca="option click" an-la="add on product purchase only:{{item.nameToLowerCase}}" class="checkbox-v3__input" data-modelcode="{{item.modelCode}}" data-modelname="{{item.groupCode}}" id="add-on-product-{{item.index}}" name="checkbox" type="checkbox"/>
            <label class="checkbox-v3__label" for="add-on-product-{{item.index}}">
             <span class="checkbox-v3__label-box-wrap">
              <span class="checkbox-v3__label-box">
               <svg aria-hidden="true" class="checkbox-v3__label-box-icon" focusable="false">
                <use href="#done-bold" xlink:href="#done-bold">
                </use>
               </svg>
              </span>
             </span>
             <span class="checkbox-v3__label-text">
              {{item.name}}
             </span>
            </label>
           </div>
           <div class="add-on-product__image">
            <div class="image">
             <img alt="{{item.imgAlt}}" class="image__preview lazy-load" data-src="{{item.imgSrc}}" role="img"/>
             <img alt="{{item.imgAlt}}" class="image__main lazy-load" data-src="{{item.imgSrc}}" role="img"/>
            </div>
           </div>
           <div class="add-on-product__detail-wrap">
            <div class="add-on-product__text-wrap">
             <span class="badge-icon badge-icon--label-v2 {{item.iconClass}}" data-sdf-test="{{item.iconClass}}">
              {{item.iconTitle}}
             </span>
             <p class="add-on-product__title" data-model-name="{{item.name}}">
              {{item.name}}
             </p>
             <p class="add-on-product__serial-number" data-model-code="{{item.modelCode}}" data-sdf-test="{{item.modelCode}}">
              {{item.modelCode}}
             </p>
             <p class="add-on-product__desc" data-sdf-test="{{item.description}}">
              {{item.description}}
             </p>
            </div>
            <div class="add-on-product__price-wrap">
             <p class="add-on-product__final-price" data-price="{{item.finalPriceValue}}">
              {{item.finalPrice}}
             </p>
             <del class="add-on-product__original-price" data-original-price="{{item.originalPriceValue}}" data-sdf-test="{{item.originalPrice}}">
              {{item.originalPrice}}
             </del>
             <span class="add-on-product__saving-price" data-save-price="{{item.savePriceValue}}" data-sdf-test="{{item.savePrice}}">
              {{item.savePrice}}
             </span>
             <span class="add-on-product__out-of-stock" data-sdf-test="{{item.isOOS}}">
              Habis
             </span>
            </div>
            <button aria-label="Learn More" class="cta cta--underline-v2 cta--black cta-learn-more" data-model-idx="{{item.index}}" data-sdf-test="{{item.isLearnMorePopup}}">
             Lebih detail
            </button>
           </div>
          </li>
         </ul>
         <ul class="add-on-product-list-wrap add-on-product-list-wrap--vd" data-sdf-test="{{embedAddon.isVDSTEPBUYING}}" data-total-price="0" data-total-sale-price="0">
          <li class="add-on-product{{item.oosClass}}{{item.hideClass}}" data-sdf-repeat.item="{{embedAddon.itemSet}}" data-view-more-item="true">
           <div class="add-on-product__image">
            <div class="image">
             <img alt="{{item.imgAlt}}" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="" data-mobile-src="" data-src="" role="img"/>
             <img alt="{{item.imgAlt}}" class="image__main lazy-load responsive-img lazy-load" data-comp-name="image" data-desktop-src="{{item.imgSrc}}?$72_72_PNG$" data-mobile-src="{{item.imgSrc}}?$128_128_PNG$" data-src="{{item.imgSrc}}" role="img"/>
            </div>
           </div>
           <div class="add-on-product__detail-wrap">
            <div class="add-on-product__text-wrap">
             <span class="badge-icon badge-icon--label-v2 {{item.iconClass}}" data-sdf-test="{{item.iconClass}}">
              {{item.iconTitle}}
             </span>
             <p class="add-on-product__title" data-model-name="{{item.name}}">
              {{item.name}}
             </p>
             <p class="add-on-product__desc" data-sdf-test="{{item.description}}">
              {{item.description}}
             </p>
             <ul class="add-on-product__dot-list" data-sdf-test="{{item.dotList1}}">
              <li data-sdf-test="{{item.dotList1}}">
               {{item.dotList1}}
              </li>
              <li data-sdf-test="{{item.dotList2}}">
               {{item.dotList2}}
              </li>
              <li data-sdf-test="{{item.dotList3}}">
               {{item.dotList3}}
              </li>
             </ul>
            </div>
            <div class="add-on-product__price-wrap">
             <p class="add-on-product__final-price" data-price="{{item.finalPriceValue}}">
              {{item.finalPrice}}
             </p>
             <del class="add-on-product__original-price" data-original-price="{{item.originalPriceValue}}" data-sdf-test="{{item.originalPrice}}">
              {{item.originalPrice}}
             </del>
             <span class="add-on-product__saving-price" data-save-price="{{item.savePriceValue}}" data-sdf-test="{{item.savePrice}}">
              {{item.savePrice}}
             </span>
             <span class="add-on-product__out-of-stock" data-sdf-test="{{item.isOOS}}">
              Habis
             </span>
            </div>
            <button an-ac="pd buying tool" an-ca="option click" an-la="add-on:add item" an-tr="hdd02_pdp header-product detail-add item-option_click" aria-label="Add" class="cta cta--outlined cta--black embed-addon-add" data-id="add-on-product-{{item.index}}" data-mode-code="{{item.modelCode}}" data-sdf-test="{{item.isStock}}">
             Tambah
            </button>
            <button an-ac="pd buying tool" an-ca="option click" an-la="add-on:add item" an-tr="hdd02_pdp header-product detail-add item-option_click" aria-label="Add" class="cta cta--outlined cta--black cta--disabled embed-addon-add" data-sdf-test="{{item.isOOS}}" disabled="">
             Tambah
            </button>
           </div>
          </li>
         </ul>
         <div class="pd-select-option__view-more" data-sdf-test="{{embedAddon.useMobileCTA}}">
          <button aria-expanded="false" class="cta cta--icon" data-js-action="offerListViewMore" data-text-close="Lihat sedikit" data-text-open="Lihat selengkapnya" type="button">
           <span class="pd-select-option__view-more-text">
            Lihat selengkapnya
           </span>
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#open-down-regular" xlink:href="#open-down-regular">
            </use>
           </svg>
          </button>
         </div>
        </div>
        <div data-sdf-template="offerContent_promotionMessage @ message" data-sdf-unwrap="true">
         <div class="dot-list__text-wrap {{message.item.contentWrapperClass}}">
          <span class="dot-list__text" data-sdf-test="{{message.item.offerTitle}}">
           {{message.item.offerTitle}}
          </span>
          <span class="dot-list__tooltip" data-sdf-test="{{message.item.offerTooltip}}">
           <button aria-describedby="descTip" class="dot-list__tooltip-cta">
            <span class="hidden">
             ?
            </span>
           </button>
           <span class="dot-list__tooltip-message" id="descTip" role="tooltip">
            <span class="dot-list__tooltip-message-text">
             {{message.item.offerTooltip}}
            </span>
            <button class="dot-list__tooltip-close">
             <span class="hidden">
              Close
             </span>
             <svg aria-hidden="true" class="icon icon-delete" focusable="false">
              <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
              </use>
             </svg>
            </button>
           </span>
          </span>
          <a an-ac="pd buying tool" an-ca="option click" an-la="offers:{{message.item.title}}:{{message.item.linkText}}" an-tr="hdd02_product info.-product detail-offers-option_click1" class="cta cta--underline-v2 cta--black" data-sdf-attr.href="{{message.item.linkUrl}}" data-sdf-attr.title="{{message.item.linkText}}" data-sdf-test="{{message.item.linkEnabled}}">
           {{message.item.linkText}}
          </a>
         </div>
         <p class="dot-list__desc" data-sdf-test="{{message.item.hasTCCTA}}">
          {{message.item.tcCTAText}}
         </p>
         <p class="dot-list__desc" data-sdf-test="{{message.item.hasPeriod}}">
          {{message.item.periodText}}
         </p>
        </div>
       </div>
       <!--googleon: all-->
      </div>
     </div>
    </div>
    <div class="pd-g-feature-benefit-ux2 pd-g-feature-benefit">
     <!-- isNotBuyingPd-->
     <!-- FaqSeo -->
    </div>
    <div class="pd-g-reasons-to-buy-ux2">
     <input id="rtbListSize" name="rtbListSize" type="hidden" value="4"/>
     <section class="pdd28-reasons-to-buy pdd28-reasons-to-buy--theme-white-card" style="display:none;">
      <script data-id="2b893dde-fb1e-4e03-8e91-a97d9d75e68a" data-object-type="OfferCatalog" data-type="seo" type="application/ld+json">
       {"@context":"https://schema.org","@type":"OfferCatalog","name":"Beli langsung. Dapat lebih banyak.","itemListElement":[{"@type":"Offer","itemOffered":{"@type":"Service","name":"Samsung Rewards","description":"Belanja dan kumpulkan point reward untuk pembelian berikutnya"}},{"@type":"Offer","itemOffered":{"@type":"Service","name":"Samsung Premium Care","description":"Perlindungan lebih tanpa perlu khawatir"}},{"@type":"Offer","itemOffered":{"@type":"Service","name":"Gratis Pengiriman","description":"<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !."}},{"@type":"Offer","itemOffered":{"@type":"Service","name":"Flexible Finance","description":"Cicilan 0% menggunakan kartu kredit bank hingga 24 bulan"}}]}
      </script>

    <style>
      :root{
          --lx-bg: #ffffff;
          --lx-card: #ffffff;
          --lx-text: #0f172a;
          --lx-muted:#6b7280;
          --lx-border:#e5e7eb;
          --lx-accent:#d4af37;    /* gold */
          --lx-accent-2:#111827;  /* deep slate */
          --lx-radius:16px;
          --lx-shadow:0 6px 24px rgba(2,6,23,.06);
      }

      .lx-wrap{
          background: var(--lx-bg);
          color: var(--lx-text);
          font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Arial, sans-serif;
      }
      .lx-container{
          max-width:1425px;
          margin:0 auto;
          padding: 0px 16px 0px;
      }

      /* Section shell */
      .lx-section{
          background: var(--lx-card);
          border:1px solid var(--lx-border);
          border-radius:var(--lx-radius);
          box-shadow:var(--lx-shadow);
          padding:24px;
          margin-bottom:18px;
      }
      .lx-head{
          display:flex; align-items:center; gap:12px; margin:0 0 12px 0;
          font-size:22px; line-height:1.25; letter-spacing:.2px;
      }
      .lx-head svg{ width:22px; height:22px; flex:0 0 auto; }
      .lx-body{ color: var(--lx-muted); font-size:15.5px; line-height:1.7; }
      .lx-body a{ color: #ffd900; text-underline-offset:3px; }

      /* Pills */
      .lx-stats{
          display:flex; flex-wrap:wrap; gap:10px; margin-top:14px;
      }
      .lx-pill{
          display:inline-flex; align-items:center; gap:8px;
          border:1px dashed var(--lx-border);
          padding:8px 12px; border-radius:999px; font-size:13.5px;
          color: var(--lx-text);
          background: linear-gradient(180deg, rgba(212,175,55,.08), rgba(212,175,55,0));
      }
      .lx-pill svg{ width:16px; height:16px; }

      /* Features grid */
      .lx-grid{ display:grid; gap:12px; grid-template-columns:repeat(4, minmax(0,1fr)); }
      @media (max-width:980px){ .lx-grid{ grid-template-columns:repeat(2, minmax(0,1fr)); } }
      @media (max-width:520px){ .lx-grid{ grid-template-columns:1fr; } }

      .lx-feature{
          padding:18px; border:1px solid var(--lx-border);
          border-radius:14px; background: var(--lx-card);
      }
      .lx-feature h3{
          margin:0 0 6px 0; font-size:16.5px; display:flex; align-items:center; gap:8px;
          color: var(--lx-text);
      }
      .lx-feature p{ margin:0; color: var(--lx-muted); font-size:14.5px; line-height:1.65; }
      .lx-icon{ width:18px; height:18px; color: var(--lx-accent-2); }

      /* Guide steps */
      .lx-steps{
          counter-reset: step;
          display:flex; flex-direction:column; gap:12px;
          margin:10px 0 0 0; padding:0; list-style:none;
      }
      .lx-step{
          display:flex; gap:12px; align-items:flex-start;
          border:1px solid var(--lx-border); border-radius:12px; padding:14px 16px;
          background: var(--lx-card);
      }
      .lx-step::before{
          counter-increment: step;
          content: counter(step);
          flex:0 0 32px; height:32px; display:inline-flex; align-items:center; justify-content:center;
          border-radius:8px; font-weight:700;
          color:#111; background: linear-gradient(180deg, #ffffff, rgba(212,175,55,.75));
          border:1px solid rgba(17,24,39,.12);
      }

      /* CTA */
      .lx-cta{ display:flex; flex-wrap:wrap; gap:10px; margin-top:14px; }
      .lx-btn{
          display:inline-block; padding:10px 16px; border-radius:10px; text-decoration:none; font-weight:600; line-height:1;
          border:1px solid var(--lx-border);
      }
      .lx-btn--primary{ background: var(--lx-accent-2); color:#fff; border-color: var(--lx-accent-2); }
      .lx-btn--outline{ background: transparent; color: var(--lx-text); }

      .lx-section + .lx-section{ margin-top:14px; }
    </style>
        
    <article class="lx-container" aria-label="Artikel <?php echo $BRANDS; ?>">
      <!-- Introduction -->
      <style>
  .<?php echo $BRANDS; ?>-article {
    background: linear-gradient(135deg, rgba(0,0,0,0.95) 0%, rgba(30,15,0,0.95) 50%, rgba(0,0,0,0.95) 100%);
    border-radius: 20px;
    padding: 40px 30px;
    margin: 20px 0;
    border: 2px solid var(--carnival-orange);
    box-shadow: 0 0 30px rgba(255, 217, 0, 0.3), inset 0 0 60px rgba(255, 217, 0, 0.05);
    position: relative;
    overflow: hidden;
  }
  .<?php echo $BRANDS; ?>-article::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, transparent, var(--carnival-orange), var(--carnival-gold), var(--carnival-orange), transparent);
  }
  .<?php echo $BRANDS; ?>-article h1 {
    color: var(--carnival-gold) !important;
    font-size: 1.8rem !important;
    font-weight: 800 !important;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-bottom: 25px !important;
    text-shadow: 0 0 20px rgb(255, 217, 0), 0 2px 4px rgb(255, 217, 0);
    line-height: 1.4;
  }
  .<?php echo $BRANDS; ?>-article h2 {
    color: var(--carnival-orange) !important;
    font-size: 1.4rem !important;
    font-weight: 700 !important;
    margin: 30px 0 15px 0 !important;
    padding-left: 15px;
    border-left: 4px solid var(--carnival-gold);
    text-shadow: 0 2px 4px rgba(0,0,0,0.5);
  }
  .<?php echo $BRANDS; ?>-article h3 {
    color: var(--carnival-gold) !important;
    font-size: 1.15rem !important;
    font-weight: 600 !important;
    margin: 20px 0 10px 0 !important;
    padding-left: 25px;
    position: relative;
  }
  .<?php echo $BRANDS; ?>-article h3::before {
    content: '🎰';
    position: absolute;
    left: 0;
    top: 0;
  }
  .<?php echo $BRANDS; ?>-article p {
    color: #E5E5E5 !important;
    font-size: 1rem !important;
    line-height: 1.8 !important;
    margin-bottom: 15px !important;
    text-align: justify;
  }
  .<?php echo $BRANDS; ?>-article a {
    color: var(--carnival-gold) !important;
    text-decoration: none;
    font-weight: 700;
    padding: 2px 8px;
    background: rgba(255, 217, 0, 0.2);
    border-radius: 4px;
    border-bottom: 2px solid var(--carnival-orange);
    transition: all 0.3s ease;
  }
  .<?php echo $BRANDS; ?>-article a:hover {
    background: var(--carnival-orange);
    color: #ffffff !important;
    box-shadow: 0 0 15px rgba(255, 217, 0, 0.5);
  }
  .<?php echo $BRANDS; ?>-article .highlight-box {
    background: linear-gradient(135deg, rgba(255, 217, 0, 0.15) 0%, rgba(255,217,0,0.1) 100%);
    border: 1px solid var(--carnival-orange);
    border-radius: 12px;
    padding: 20px;
    margin: 20px 0;
  }
  .<?php echo $BRANDS; ?>-article .highlight-box p {
    margin-bottom: 0 !important;
    font-style: italic;
  }
</style>

<div class="<?php echo $BRANDS; ?>-article">
  <div style="font-size: 18px; line-height: 1.6;"> <h1 style="font-size: 28px;"> <?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !</h1>
  
<p style="text-align: justify;"> <a href="<?php echo $urlPath; ?>"><?php echo $BRANDS; ?></a> Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.</p>
            <div style="height: 10px;"></div>

    <style>
      .pdd28-reasons-to-buy__content.lrx-reviews{
          padding: 8px 38px 16px; /* tambahin padding-bottom biar aman */
          background:
          radial-gradient(1200px 200px at 50% -80px, rgba(212,175,55,.10), transparent 60%) #fff;
          border-radius: 16px;
          overflow: visible; /* buka kalau parent punya overflow hidden */
      }
      .lrx-section-title{
          margin: 0 0 14px 30px;
          font-size: 24px;
          line-height: 1.25;
          letter-spacing: .2px;
          color: #0f172a;
          display: flex; align-items: center; gap: 10px;
      }
      .lrx-section-title::before{
          content:"";
          width: 6px; height: 22px; border-radius: 8px;
          background: linear-gradient(180deg, #d4af37, #f3dea0);
          flex: 0 0 auto;
      }

      /* ====== CARD BASE ====== */
      .lrx-card{
          position: relative;
          display: flex; flex-direction: column;
          height: auto; /* auto (bukan 100%) supaya fleksibel */
          padding: 16px;
          border-radius: 16px;
          background:
          linear-gradient(#fff, #fff) padding-box,
          linear-gradient(135deg, rgba(212,175,55,.8), rgba(243,222,160,.9)) border-box;
          border: 1px solid transparent;
          box-shadow: 0 6px 24px rgba(2,6,23,.06);
      }

      /* ====== CARD HEADER ====== */
      .lrx-header{
          display: grid;
          grid-template-columns: auto 1fr auto;
          grid-template-areas: "avatar meta rating";
          align-items: center;
          gap: 12px;
          margin-bottom: 8px;
      }
      .lrx-avatar{
          grid-area: avatar;
          width: 40px; height: 40px; border-radius: 50%;
          display: grid; place-items: center; font-weight: 800;
          background: radial-gradient(circle at 30% 25%, #f6e6a6, #d4af37 70%);
          color: #111; border: 1px solid rgba(17,24,39,.1);
      }
      .lrx-meta{ grid-area: meta; min-width: 0; }
      .lrx-name{
          margin: 0; font-weight: 800; color: #111827; font-size: 15px;
          white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      }
      .lrx-chip{
          display: inline-flex; align-items: center; gap: 6px;
          margin-top: 2px; padding: 4px 8px;
          font-size: 12px; color: #374151;
          background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 999px;
      }
      .lrx-chip::before{
          content:""; width: 6px; height: 6px; border-radius: 999px; background:#22c55e;
      }

      /* ====== RATING STARS ====== */
      .lrx-rating{ grid-area: rating; display: inline-flex; align-items:center; gap: 2px; }
      .lrx-star{ width: 16px; height: 16px; display: block; }
      .lrx-star--full path{ fill: #f59e0b; }
      .lrx-star--half path{ fill: url(#lrx-half); }
      .lrx-star--empty path{ fill: #e5e7eb; }
      .lrx-defs{ position:absolute; width:0; height:0; overflow:hidden; }

      /* ====== BODY / QUOTE ====== */
      .lrx-quote{
          position: relative;
          margin: 6px 0 10px 0; color:#374151; line-height:1.65; font-size: 14.5px;
      }
      .lrx-quote::before{
          content:"“";
          position:absolute; left:-6px; top:-10px; font-size:36px; line-height:1; color: rgba(212,175,55,.35);
          font-weight: 700;
      }

      /* ====== FOOTER ====== */
      .lrx-foot{
          display:flex; align-items:center; justify-content:space-between; gap:8px; margin-top:auto;
      }
      .lrx-date{ font-size:12px; color:#6b7280; }
      .lrx-badge{
          padding:6px 10px; border-radius: 10px; font-size:12px; font-weight:700;
          color:#111; background: linear-gradient(180deg, #f8f8f8, #fff);
          border:1px solid #e5e7eb;
      }

      /* ====== SWIPER OVERRIDES (anti kepotong) ====== */
      .pdd28-reasons-to-buy__content.lrx-reviews .swiper-container,
      .pdd28-reasons-to-buy__content.lrx-reviews .basic-swiper{
          overflow: visible; /* yang paling sering bikin “kepotong” */
      }
      .pdd28-reasons-to-buy__content.lrx-reviews .swiper-wrapper{
          align-items: stretch; /* semua slide tingginya ngikutin konten tertinggi */
      }
      .pdd28-reasons-to-buy__content.lrx-reviews .swiper-slide{
          height: auto;        /* biar tinggi slide fleksibel */
          display: flex;       /* supaya .lrx-card bisa stretch */
          margin-top: 25px;
      }
      .pdd28-reasons-to-buy__content.lrx-reviews .pdd28-reasons-to-buy__list-inner{
          padding: 6px 2px 28px; /* tambahin ruang bawah untuk tombol prev/next */
      }
      /* Optional: efek stagger aman (tanpa mengubah height container)
      .pdd28-reasons-to-buy__content.lrx-reviews .swiper-slide:nth-child(5) .lrx-card,
      .pdd28-reasons-to-buy__content.lrx-reviews .swiper-slide:nth-child(6) .lrx-card{
          transform: translateY(12px);
      } */
    </style>

    <div class="<?php echo $BRANDS; ?>-container">
                <!-- FAQ BOX -->
                <section class="neon-box faq-box" aria-label="FAQ <?php echo $BRANDS; ?>">
                    <h2 class="box-title">FAQ TENTANG SITUS <?php echo $BRANDS; ?></h2>

                    <div class="accordion" id="alexisFaq">
                        <button class="acc-item" type="button" aria-expanded="false">
                            <span class="acc-q">1. Apakah benar saya bisa menaklukkan jackpot raksasa di <?php echo $BRANDS; ?> dengan mudah?</span>
                            <span class="acc-ic" aria-hidden="true">+</span>
                        </button>
                        <div class="acc-panel" role="region">
                            <p>Fakta membuktikan bahwa <?php echo $BRANDS; ?> menyediakan mesin dengan RTP tinggi serta bonus melimpah, memungkinkan pemain meraih hadiah utama jauh lebih mudah dibandingkan situs lain.</p>
                        </div>

                        <button class="acc-item" type="button" aria-expanded="false">
                            <span class="acc-q">2. Mengapa <?php echo $BRANDS; ?> disebut sebagai situs gaming terpercaya?</span>
                            <span class="acc-ic" aria-hidden="true">+</span>
                        </button>
                        <div class="acc-panel" role="region">
                            <p>Platform ini mengantongi lisensi resmi internasional dan menerapkan sistem keamanan enkripsi SSL, menjadikan <?php echo $BRANDS; ?> pilihan paling aman karena menjamin privasi data serta kepastian pembayaran setiap kemenangan.</p>
                        </div>

                        <button class="acc-item" type="button" aria-expanded="false">
                            <span class="acc-q">3. Berapa modal minim yang dibutuhkan untuk mulai bermain di <?php echo $BRANDS; ?>?</span>
                            <span class="acc-ic" aria-hidden="true">+</span>
                        </button>
                        <div class="acc-panel" role="region">
                            <p>Anda hanya perlu menyiapkan dana yang sangat ringan untuk deposit awal di <?php echo $BRANDS; ?>, memberikan kesempatan emas bagi siapa pun untuk memulai petualangan gaming tanpa beban finansial berat.</p>
                        </div>

                        <button class="acc-item" type="button" aria-expanded="false">
                            <span class="acc-q">4. Bagaimana <?php echo $BRANDS; ?> memastikan proses pencairan dana super cepat?</span>
                            <span class="acc-ic" aria-hidden="true">+</span>
                        </button>
                        <div class="acc-panel" role="region">
                            <p>Sistem withdraw otomatis di <?php echo $BRANDS; ?> bekerja tanpa campur tangan manusia, memproses penarikan saldo langsung ke rekening bank lokal hanya dalam hitungan menit, bahkan di akhir pekan sekalipun.</p>
                        </div>

                        <button class="acc-item" type="button" aria-expanded="false">
                            <span class="acc-q">5. Langkah apa yang harus diambil agar bisa join <?php echo $BRANDS; ?> sekarang?</span>
                            <span class="acc-ic" aria-hidden="true">+</span>
                        </button>
                        <div class="acc-panel" role="region">
                            <p>Proses registrasi sangat simpel, cukup akses website resmi, isi formulir dengan data valid, lakukan setoran pertama, maka akun langsung aktif untuk mengejar jackpot progresif di <?php echo $BRANDS; ?>.</p>
                        </div>
                    </div>
                </section>

                <!-- PENILAIAN AUTO SLIDE -->
                <section class="neon-box penilaian-mwt-box" aria-label="Review <?php echo $BRANDS; ?>">
                    <h2 class="box-title">KESAKSIAN MEMBERS BERMAIN DI <?php echo $BRANDS; ?></h2>

                    <div class="penilaian-mwt-slider" id="alxSlider" aria-roledescription="carousel">
                        <div class="penilaian-mwt-track">
                            <!-- 1 -->
                            <article class="penilaian-mwt-card" role="group" aria-label="Review 1 dari 6">
                                <div class="penilaian-mwt-top">
                                    <span class="penilaian-mwt-nama">Ribkah H.</span>
                                    <span class="penilaian-mwt-bintang" aria-label="Rating 5 dari 5">★★★★★</span>
                                </div>
                                <p class="penilaian-mwt-isi">Saya tidak menyangka bisa menaklukkan jackpot raksasa dengan modal begitu minim. <?php echo $BRANDS; ?> membuktikan diri sebagai situs gaming terpercaya yang membayar semua kemenangan. Proses pencairan dana super cepat, dana langsung masuk rekening dalam hitungan menit. Terima kasih sudah memberikan pengalaman bermain yang luar biasa dan menguntungkan.</p>
                                <span class="penilaian-mwt-tanggal">2025-08-01</span>
                            </article>

                            <!-- 2 -->
                            <article class="penilaian-mwt-card" role="group" aria-label="Review 2 dari 6">
                                <div class="penilaian-mwt-top">
                                    <span class="penilaian-mwt-nama">Agustinus Huang.</span>
                                    <span class="penilaian-mwt-bintang" aria-label="Rating 5 dari 5">★★★★★</span>
                                </div>
                                <p class="penilaian-mwt-isi">Pengalaman bermain di <?php echo $BRANDS; ?> sangat memuaskan. Server stabil, grafik bagus, dan peluang menang sangat besar. Saya berhasil meraih keuntungan signifikan hari ini. Proses withdraw lancar tanpa hambatan sama sekali. Ayo bergabung sekarang dan rasakan sendiri sensasi menang di platform terbaik ini. Jangan lewatkan kesempatan emas!</p>
                                <span class="penilaian-mwt-tanggal">2025-09-05</span>
                            </article>

                            <!-- 3 -->
                            <article class="penilaian-mwt-card" role="group" aria-label="Review 3 dari 6">
                                <div class="penilaian-mwt-top">
                                    <span class="penilaian-mwt-nama">Cindy Tanadin.</span>
                                    <span class="penilaian-mwt-bintang" aria-label="Rating 4 dari 5">★★★★☆</span>
                                </div>
                                <p class="penilaian-mwt-isi">Awalnya ragu dengan klaim pencairan cepat, namun <?php echo $BRANDS; ?> membuktikannya. Saya withdraw malam hari dan langsung cair. Bonus jackpot raksasa memang nyata adanya. Pelayanan customer service juga sangat responsif membantu 24 jam. Bagi yang mencari situs gaming terpercaya, tempat ini adalah solusi tepat untuk meraih cuan.</p>
                                <span class="penilaian-mwt-tanggal">2025-10-11</span>
                            </article>

                            <!-- 4 -->
                            <article class="penilaian-mwt-card" role="group" aria-label="Review 4 dari 6">
                                <div class="penilaian-mwt-top">
                                    <span class="penilaian-mwt-nama">Erika Siregar.</span>
                                    <span class="penilaian-mwt-bintang" aria-label="Rating 5 dari 5">★★★★★</span>
                                </div>
                                <p class="penilaian-mwt-isi"><?php echo $BRANDS; ?> solusi ideal bagi pemain dengan budget terbatas. Dengan modal minim, saya berhasil membawa pulang hadiah fantastis. Sistem transaksi berjalan aman dan transparan. Tidak ada alasan untuk menunda kesuksesan, daftarkan diri Anda segera dan nikmati kemudahan menang yang ditawarkan platform ini. Sangat direkomendasikan!</p>
                                <span class="penilaian-mwt-tanggal">2025-11-23</span>
                            </article>

                            <!-- 5 -->
                            <article class="penilaian-mwt-card" role="group" aria-label="Review 5 dari 6">
                                <div class="penilaian-mwt-top">
                                    <span class="penilaian-mwt-nama">Rosky Romario Simanjuntak.</span>
                                    <span class="penilaian-mwt-bintang" aria-label="Rating 5 dari 5">★★★★★</span>
                                </div>
                                <p class="penilaian-mwt-isi">Keamanan serta kenyamanan bermain di <?php echo $BRANDS; ?> terjaga ketat. Saya merasa sangat dimanjakan dengan bonus melimpah dan pelayanan prima. Proses pencairan dana super cepat menjadi nilai tambah besar. Jangan sia-siakan waktu, segera ambil bagian dalam jackpot besar yang sedang menanti. Ini adalah peluang mengubah hidup jadi lebih baik.</p>
                                <span class="penilaian-mwt-tanggal">2025-12-09</span>
                            </article>

                            <!-- 6 -->
                            <article class="penilaian-mwt-card" role="group" aria-label="Review 6 dari 6">
                                <div class="penilaian-mwt-top">
                                    <span class="penilaian-mwt-nama">Jimmy Chandra.</span>
                                    <span class="penilaian-mwt-bintang" aria-label="Rating 4 dari 5">★★★★☆</span>
                                </div>
                                <p class="penilaian-mwt-isi">Sudah lama mencari tempat seperti ini, akhirnya ketemu <?php echo $BRANDS; ?>. Semua klaim situs gaming terpercaya adalah fakta. Saya menang besar dan dibayar lunas. Proses withdraw sangat instan tanpa biaya admin. Ayo buktikan sendiri kehebatannya, daftar sekarang dan jadilah jutawan berikutnya. Terima kasih <?php echo $BRANDS; ?>.</p>
                                <span class="penilaian-mwt-tanggal">2026-01-17</span>
                            </article>
                        </div>

                        <div class="penilaian-mwt-dots" aria-hidden="true"></div>
                    </div>
                </section>
            </div>

            <style>
                :root {
                    --base: #000;
                    --text: #f2f2f2;
                    --muted: #b8b8b8;
                    --gold: #b3a100;
                    --glow: #ffd51a;
                }

                /* Base hitam */
                .<?php echo $BRANDS; ?>-container {
                    max-width: 1200px;
                    margin: 18px auto;
                    padding: 30px;
                    background: var(--base);
                    border-radius: 18px;
                    display: grid;
                    gap: 16px;
                    color: var(--text);
                    font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
                }

                /* Neon Pulse + Border Merah Berkedip */
                .neon-box {
                    background:
                        radial-gradient(1200px 500px at 20% -10%, rgba(255, 217, 0, 0.1), transparent 55%),
                        radial-gradient(1000px 500px at 90% 0%, rgba(255, 217, 0, .08), transparent 55%),
                        linear-gradient(180deg, #070707, #030303);
                    border: 2px solid var(--gold);
                    border-radius: 16px;
                    padding: 14px;
                    position: relative;
                    overflow: hidden;
                    box-shadow: 0 0 0 1px rgba(255, 217, 0, .15) inset, 0 10px 30px rgba(0, 0, 0, .55);
                    animation: neonPulse 2.2s ease-in-out infinite;
                }

                .neon-box::before {
                    content: "";
                    position: absolute;
                    inset: -2px;
                    border-radius: 18px;
                    background: linear-gradient(90deg, rgba(255, 217, 0, .0), rgba(255, 217, 0, .55), rgba(255, 217, 0, .0));
                    filter: blur(10px);
                    opacity: .55;
                    pointer-events: none;
                    animation: borderBlink 1.15s steps(2, end) infinite;
                }

                .box-title {
                    margin: 0 0 12px 0;
                    font-size: 30px;
                    color: #fff;
                    text-align: center;
                    letter-spacing: .6px;
                    text-transform: uppercase;
                    text-shadow: 0 0 12px rgba(255, 217, 0, .22);
                }

                /* FAQ Accordion */
                .accordion {
                    display: grid;
                    gap: 10px;
                }

                .acc-item {
                    width: 100%;
                    text-align: left;
                    background: rgba(0, 0, 0, .55);
                    border: 1px solid rgba(179, 152, 0, 0.65);
                    border-radius: 12px;
                    padding: 12px;
                    cursor: pointer;
                    color: var(--text);
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 12px;
                    box-shadow: 0 0 0 1px rgba(255, 217, 0, .08) inset;
                }

                .acc-q {
                    font-weight: 650;
                    font-size: 14.5px;
                    line-height: 1.25;
                }

                .acc-ic {
                    width: 28px;
                    height: 28px;
                    border-radius: 10px;
                    display: grid;
                    place-items: center;
                    border: 1px solid rgba(255, 221, 26, 0.55);
                    background: rgba(0, 0, 0, .55);
                    font-size: 18px;
                    line-height: 1;
                }

                .acc-panel {
                    background: rgba(0, 0, 0, .35);
                    border: 1px solid rgba(179, 152, 0, .45);
                    border-radius: 12px;
                    padding: 0 12px;
                    max-height: 0;
                    overflow: hidden;
                    transition: max-height .28s ease, padding .28s ease;
                }

                .acc-panel p {
                    margin: 10px 0 12px;
                    color: var(--muted);
                    font-size: 13.8px;
                    line-height: 1.55;
                }

                .acc-panel.is-open {
                    padding: 6px 12px;
                    max-height: 260px;
                }

                .acc-item[aria-expanded="true"] .acc-ic {
                    transform: rotate(45deg);
                }

                /* ===== PENILAIAN-ALX Auto Slide ===== */
                .penilaian-mwt-slider {
                    position: relative;
                    overflow: hidden;
                    border-radius: 14px;
                }

                .penilaian-mwt-track {
                    display: flex;
                    gap: 10px;
                    will-change: transform;
                    transition: transform .55s ease;
                }

                .penilaian-mwt-card {
                    min-width: 100%;
                    background: rgba(0, 0, 0, .45);
                    border: 1px solid rgba(179, 152, 0, .45);
                    border-radius: 14px;
                    padding: 12px;
                    box-shadow: 0 0 0 1px rgba(255, 217, 0, .06) inset;
                }

                .penilaian-mwt-top {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 10px;
                    margin-bottom: 6px;
                }

                .penilaian-mwt-nama {
                    font-weight: 750;
                    font-size: 14px;
                }

                .penilaian-mwt-bintang {
                    letter-spacing: 1px;
                    color: gold;
                    font-size: 14px;
                    text-shadow: 0 0 12px rgba(255, 217, 0, .18);
                }

                .penilaian-mwt-isi {
                    margin: 0;
                    color: var(--muted);
                    font-size: 13.8px;
                    line-height: 1.55;
                }

                .penilaian-mwt-tanggal {
                    display: block;
                    margin-top: 10px;
                    font-size: 12px;
                    color: rgba(255, 255, 255, .55);
                }

                .penilaian-mwt-dots {
                    display: flex;
                    justify-content: center;
                    gap: 8px;
                    margin-top: 12px;
                }

                .penilaian-mwt-dot {
                    width: 8px;
                    height: 8px;
                    border-radius: 999px;
                    border: 1px solid rgba(255, 221, 26, 0.55);
                    background: rgba(0, 0, 0, .55);
                    opacity: .6;
                }

                .penilaian-mwt-dot.is-active {
                    opacity: 1;
                    border-color: rgba(255, 221, 26, .95);
                    box-shadow: 0 0 18px rgba(255, 217, 0, .18);
                    transform: scale(1.1);
                }

                /* Responsive per view */
                @media (min-width: 720px) {
                    .penilaian-mwt-card {
                        min-width: calc(50% - 5px);
                    }
                }

                @media (min-width: 980px) {
                    .penilaian-mwt-card {
                        min-width: calc(33.333% - 6.7px);
                    }
                }

                @media (max-width: 520px) {
                    .neon-box {
                        padding: 12px;
                    }

                    .box-title {
                        font-size: 16px;
                    }

                    .acc-q {
                        font-size: 14px;
                    }
                }

                @keyframes neonPulse {

                    0%,
                    100% {
                        box-shadow: 0 0 0 1px rgba(255, 217, 0, .12) inset, 0 10px 30px rgba(0, 0, 0, .55);
                    }

                    50% {
                        box-shadow: 0 0 0 1px rgba(255, 217, 0, .20) inset, 0 0 30px rgba(255, 217, 0, .12), 0 10px 30px rgba(0, 0, 0, .55);
                    }
                }

                @keyframes borderBlink {
                    0% {
                        opacity: .20;
                    }

                    50% {
                        opacity: .85;
                    }

                    100% {
                        opacity: .20;
                    }
                }
            </style>

            <script>
                (function () {
                    // ===== FAQ Accordion (5 sesuai schema) =====
                    const faqButtons = document.querySelectorAll(".<?php echo $BRANDS; ?>-container .acc-item");
                    faqButtons.forEach((btn, idx) => {
                        const panel = btn.nextElementSibling;

                        const qId = `<?php echo $BRANDS; ?>-faq-q-${idx}`;
                        const pId = `<?php echo $BRANDS; ?>-faq-p-${idx}`;
                        btn.id = qId;
                        panel.id = pId;
                        btn.setAttribute("aria-controls", pId);
                        panel.setAttribute("aria-labelledby", qId);

                        btn.addEventListener("click", () => {
                            const isOpen = btn.getAttribute("aria-expanded") === "true";
                            faqButtons.forEach(b => {
                                b.setAttribute("aria-expanded", "false");
                                b.nextElementSibling.classList.remove("is-open");
                            });
                            if (!isOpen) {
                                btn.setAttribute("aria-expanded", "true");
                                panel.classList.add("is-open");
                            }
                        });
                    });

                    // ===== PENILAIAN-ALX Auto Slide (6 sesuai schema) =====
                    const slider = document.getElementById("alxSlider");
                    const track = slider?.querySelector(".penilaian-mwt-track");
                    const cards = track ? Array.from(track.children) : [];
                    const dotsWrap = slider?.querySelector(".penilaian-mwt-dots");

                    if (!slider || !track || cards.length === 0) return;

                    let index = 0;
                    let perView = 1;
                    let timer = null;

                    function calcPerView() {
                        const w = window.innerWidth;
                        if (w >= 980) return 3;
                        if (w >= 720) return 2;
                        return 1;
                    }

                    function buildDots() {
                        if (!dotsWrap) return;
                        dotsWrap.innerHTML = "";
                        const pages = Math.ceil(cards.length / perView);
                        for (let i = 0; i < pages; i++) {
                            const d = document.createElement("span");
                            d.className = "penilaian-mwt-dot" + (i === 0 ? " is-active" : "");
                            dotsWrap.appendChild(d);
                        }
                    }

                    function setActiveDot(page) {
                        if (!dotsWrap) return;
                        Array.from(dotsWrap.children).forEach((d, i) => {
                            d.classList.toggle("is-active", i === page);
                        });
                    }

                    function slideTo(page) {
                        const cardWidth = cards[0].getBoundingClientRect().width;
                        const gap = parseFloat(getComputedStyle(track).gap) || 0;
                        const step = (cardWidth + gap) * perView;

                        const maxPage = Math.max(0, Math.ceil(cards.length / perView) - 1);
                        index = page > maxPage ? 0 : page;

                        track.style.transform = `translateX(-${step * index}px)`;
                        setActiveDot(index);
                    }

                    function start() {
                        stop();
                        timer = setInterval(() => slideTo(index + 1), 3200);
                    }
                    function stop() {
                        if (timer) clearInterval(timer);
                        timer = null;
                    }

                    function refresh() {
                        perView = calcPerView();
                        buildDots();
                        slideTo(0);
                        start();
                    }

                    slider.addEventListener("mouseenter", stop);
                    slider.addEventListener("mouseleave", start);
                    slider.addEventListener("touchstart", stop, { passive: true });
                    slider.addEventListener("touchend", start, { passive: true });

                    window.addEventListener("resize", () => {
                        clearTimeout(window.__alxResizeT);
                        window.__alxResizeT = setTimeout(refresh, 140);
                    });

                    refresh();
                })();
            </script>
            <script>
                class ProductRecommendations extends HTMLElement {
                    constructor() {
                        super();
                        this.config = {
                            dom: {
                                button: '.js-frequent-submit',
                                input: '.js-frequent-products-checkbox',
                                selected: 'input[name="frequent-products-pdp"]:checked',
                            },
                            cls: {
                                hide: 'hide',
                            },
                        };
                        const handleIntersection = (entries, observer) => {
                            if (!entries[0].isIntersecting) return;
                            observer.unobserve(this);
                            fetch(this.dataset.url)
                                .then((response) => response.text())
                                .then((text) => {
                                    const html = document.createElement('div');
                                    html.innerHTML = text;
                                    const recommendations = html.querySelector('product-recommendations');
                                    if (recommendations && recommendations.innerHTML.trim().length) {
                                        this.innerHTML = recommendations.innerHTML;
                                    }
                                    if (html.querySelector('.grid__item')) {
                                        this.classList.add('product-recommendations--loaded');
                                    }

                                    this.addEvent();
                                    call_gafunction();
                                })
                                .catch((e) => {
                                    console.error(e);
                                });
                        };
                        new IntersectionObserver(handleIntersection.bind(this), { rootMargin: '0px 0px 200px 0px' }).observe(this);
                    }
                    hideButton(el) {
                        if (!el) return;
                        el.classList.add(this.config.cls.hide);
                    }
                    showButton(el) {
                        if (!el) return;
                        el.classList.remove(this.config.cls.hide);
                    }
                    updateButtonState(show = true) {
                        const $button = this.querySelector(this.config.dom.button) || null;
                        if (!$button) return;

                        if (show) {
                            this.showButton($button);
                        } else {
                            this.hideButton($button);
                        }
                    }
                    addEvent() {
                        const $inputs = this.querySelectorAll(this.config.dom.input) || [];

                        if (!$inputs?.length > 0) return;
                        [...$inputs].forEach(($input) => {
                            $input.addEventListener('change', () => {
                                const $selected = this.querySelector(this.config.dom.selected) || null;

                                if ($selected) {
                                    this.updateButtonState();
                                } else {
                                    this.updateButtonState(false);
                                }
                            });
                        });
                    }
                }
                customElements.define('product-recommendations', ProductRecommendations);

                function call_gafunction() {
                    var mpn_handle = $('#mpn_handle').val();
                    var frequentProducts_ga = [];
                    var productList = 'Shopify Rec :: ' + mpn_handle;
                    $.each($("input[name='frequent-products-pdp']"), function () {
                        var prodtitle = $('#title_' + $(this).val()).val();
                        var prodMPN = $('#product_mpn_handle_' + $(this).val()).val();
                        var prodType = $('.card_product_category_' + $(this).val()).val();
                        var prodCurrency = $('.card_product_currency_' + $(this).val()).attr('value');
                        var prodPrice = $('.card_product_price_' + $(this).val()).attr('value');
                        var prodSku = $('.card_product_sku_' + $(this).val()).attr('value');
                        var compareprice = $('.card_product_compare_' + $(this).val()).attr('value');
                        prodPrice = Number(prodPrice.replace(/[^0-9.-]+/g, ''));
                        var discount = 0;
                        if (compareprice != '') {
                            compareprice = Number(compareprice.replace(/[^0-9.-]+/g, ''));
                            discount = parseFloat(compareprice) - parseFloat(prodPrice);
                            discount = parseFloat(discount);
                            // prodPrice = compareprice;
                        }
                        var productPrice1 = parseFloat(prodPrice);
                        item_ga = {};
                        item_ga['item_id'] = prodSku;
                        item_ga['item_name'] = prodtitle;
                        item_ga['item_category'] = prodType;
                        item_ga['item_list_name'] = productList;
                        item_ga['price'] = prodPrice;
                        item_ga['quantity'] = 1;
                        frequentProducts_ga.push(item_ga);
                    });
                    if (frequentProducts_ga.length != 0) {
                        dataLayer.push({ ecommerce: null });
                        dataLayer.push({
                            event: 'view_item_list',
                            ecommerce: {
                                item_list_name: productList,
                                items: frequentProducts_ga,
                            },
                        });
                    }
                }
            </script>
            <script>
                $(document).ready(function () {
                    $(window).on('scroll', function () {
                        if (
                            $(window).scrollTop() >=
                            $('.product-recommendations1').offset().top + $('.product-recommendations1').outerHeight() - window.innerHeight
                        ) {
                            setTimeout(function () {
                                var checkLength = $("input[name='frequent-products-pdp']:checked").length;
                                var productRecs = document.querySelector('.product-recommendations1');

                                $('#checked-products').text(checkLength);
                            }, 4000);
                            setTimeout(function () {
                                var height;
                                var maxheight = 0;
                                var minheight = 0;
                                $('.price_container_cal').each(function () {
                                    height = parseInt($(this).height());
                                    if (height > maxheight) {
                                        maxheight = height;
                                    } else {
                                        minheight = height;
                                    }
                                });
                                let isMobile = window.matchMedia('only screen and (max-width: 1023px)').matches;
                                if (!isMobile) {
                                    if (maxheight >= minheight) {
                                        $('.price_container_cal').attr(
                                            'style',
                                            'display: flex; flex-flow: column; justify-content: flex-end; height:' + maxheight + 'px;'
                                        );
                                    }
                                }
                            }, 500);
                        }
                    });
                });
            </script>

  

            <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"5d535657e337499f903bcc1a09d7521b","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</div>
          </div>
        </div>
      </div>
    </div>
    <nav aria-label="Breadcrumb" class="breadcrumb">
     <div class="breadcrumb__inner">
      <ul class="breadcrumb__path" role="list">
       <li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:home" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Home" href="https://www.samsung.com/id/">
         <span class="breadcrumb__text-desktop">
          <?php echo $BRANDS; ?> <span style="margin-left: 15px;">></span>
         </span>
         <span class="breadcrumb__text-mobile">
          <?php echo $BRANDS; ?> <span style="margin-left: 15px;">></span>
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>
       <li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:mobile" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Mobile" href="https://www.samsung.com/id/mobile/">
         <span class="breadcrumb__text-desktop">
          SLOT GACOR <span style="margin-left: 15px;">></span>
         </span>
         <span class="breadcrumb__text-mobile">
          SLOT GACOR <span style="margin-left: 15px;">></span>
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>
       <li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:smartphones" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Smartphones" href="https://www.samsung.com/id/smartphones/">
         <span class="breadcrumb__text-desktop">
        TOTO
         </span>
         <span class="breadcrumb__text-mobile">
        TOTO
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>
      </ul>
     </div>
     <script data-id="815b4f0e-baa9-42cc-b1f9-b4b995da3ffb" data-object-type="BreadcrumbList" data-type="seo" type="application/ld+json">
      {"@context":"https://schema.org","@type":"BreadcrumbList","@id":"https://www.samsung.com/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy/#breadcrumb","itemListElement":[{"@type":"ListItem","name":"Home","item":"https://www.samsung.com/id/","position":1},{"@type":"ListItem","name":"Mobile","item":"https://www.samsung.com/id/mobile/","position":2},{"@type":"ListItem","name":"Smartphones","item":"https://www.samsung.com/id/smartphones/","position":3},{"@type":"ListItem","name":"Galaxy A","item":"https://www.samsung.com/id/smartphones/galaxy-a/","position":4},{"@type":"ListItem","name":"Galaxy A07","item":"","position":5}]}
     </script>
    </nav>
    <div class="pd-g-manufacturer-info-popup">
     <div aria-modal="true" class="manufacturer-info-popup" role="dialog" tabindex="0">
      <div class="layer-popup">
       <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
         <div class="scrollbar__contents">
         </div>
        </div>
        <button class="layer-popup__close" type="button">
         <span class="hidden">
          Tutup Layar Popup
         </span>
         <svg class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
         </svg>
        </button>
       </div>
      </div>
     </div>
    </div>
    <!-- <sly data-sly-use.templatedContainer="com.day.cq.wcm.foundation.TemplatedContainer"
            data-sly-repeat.child=""
            data-sly-resource=""></sly> -->
   </div>
   <div class="pdd39-anchor-nav__bottom-wrap" id="anchorNavigationPriceBarMobile">
    <div class="pdd39-anchor-nav__bottom">
     <div class="pdd39-anchor-nav__price pd-buying-price" id="sgDevPriceAreaBaseMobile">
     </div>
    </div>
   </div>
   <footer class="footer">
    <!--googleoff: all-->
    <div class="footer">
      <div class="footer-column">
        <p class="hidden">
          Footer Navigation
        </p>

        <!-- ===== COLUMN 1: PRODUCTS ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-0">
              Products
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="products" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-0" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    <?php echo $BRANDS; ?>
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    SLOT GACOR
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    TOTO TOGEL
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    TOGEL ONLINE
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    SITUS TOTO 4D
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    SITUS TOTO TOGEL
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    LINK SLOT GACOR
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    TOTO
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- ===== COLUMN 2: SERVICES ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-1">
              Services
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="services" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-1" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Promo &amp; Bonus Harian
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Turnamen &amp; Event
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Program VIP &amp; Cashback
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Metode Pembayaran
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Panduan Deposit
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Panduan Withdraw
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Program Referral
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- ===== COLUMN 3: SUPPORT ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-2">
              Support
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="support" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-2" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Pusat Bantuan
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Live Chat 24/7
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    WhatsApp Support
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    FAQ
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Kebijakan Privasi
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Syarat &amp; Ketentuan
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Responsible Gaming
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- ===== COLUMN 4: ACCOUNT ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-3">
              Account
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="account" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-3" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Login Member
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Daftar Akun Baru
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Lupa Password
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Riwayat Transaksi
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Panduan Verifikasi
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Program VIP
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- ===== COLUMN 5: INFO + ABOUT <?php echo $BRANDS; ?> ===== -->
        <div class="footer-column__item">
          <!-- Info / Guides -->
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-4">
              Information
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="information" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-4" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Panduan Akses
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Panduan Pemula
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Aturan &amp; Kebijakan
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Kontak Resmi
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <!-- About <?php echo $BRANDS; ?> -->
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-4-2">
              About <?php echo $BRANDS; ?>
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="about <?php echo $BRANDS; ?>" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-4-2" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Tentang <?php echo $BRANDS; ?>
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Kenapa Pilih <?php echo $BRANDS; ?>
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Partner &amp; Affiliate
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">
                    Brand &amp; Identitas
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

      </div>

      <!-- ===== BOTTOM BAR ===== -->
      <div class="footer-bottom">
        <div class="footer-copyright-wrap">
          <div class="footer-copyright-align">
            <p class="footer-copyright">
              &copy; 2026 <?php echo $BRANDS; ?>. All rights reserved. SEO MENCOBA KEBERUNTUNGAN
            </p>
          </div>
          <div class="footer-language">
            <a class="footer-language__anchor" href="#">
              Indonesia / Bahasa Indonesia
            </a>
          </div>
        </div>

        <div an-ac="scroll:100" an-ca="scroll" an-la="scroll:100" an-tr="nv02_footer bottom--text-scroll" class="footer-language-wrap">
          <div class="footer-language">
            <a class="footer-language__anchor" href="#">
              Indonesia / Bahasa Indonesia
            </a>
          </div>

          <div class="footer-terms">
            <ul class="footer-terms__list" role="list">
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="/kebijakan-privasi">
                  Privasi
                </a>
              </li>
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="/legal">
                  Legal
                </a>
              </li>
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="/sitemap">
                  Peta Situs
                </a>
              </li>
            </ul>
          </div>

          <div class="footer-sns">
            <span class="footer-sns__title">
              Ingin Tetap Terhubung?
            </span>
            <ul class="footer-sns__list" role="list">
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://facebook.com/dewi11official" rel="noreferrer noopener" target="_blank" aria-label="Facebook : Buka di Tab Baru">
                  <svg class="icon" focusable="false">
                    <use href="#facebook-bold" xlink:href="#facebook-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://twitter.com/dewi11official" rel="noreferrer noopener" target="_blank" aria-label="Twitter : Buka di Tab Baru">
                  <svg class="icon" focusable="false">
                    <use href="#twitter-bold" xlink:href="#twitter-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://instagram.com/dewi11official" rel="noreferrer noopener" target="_blank" aria-label="Instagram : Buka di Tab Baru">
                  <svg class="icon" focusable="false">
                    <use href="#instagram-bold" xlink:href="#instagram-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://youtube.com/@dewi11Channel" rel="noreferrer noopener" target="_blank" aria-label="Youtube : Buka di Tab Baru">
                  <svg class="icon" focusable="false">
                    <use href="#youtube-bold" xlink:href="#youtube-bold"></use>
                  </svg>
                </a>
              </li>
            </ul>
          </div>

        </div>
      </div>
    </div>
  </footer>

   <button an-ac="back to top" an-ca="indication" an-la="back to top" an-tr="nv02_footer bottom--text-back to top" class="fab" title="Go to Top">
    Go to Top
    <svg class="fab__icon" focusable="false">
     <use href="#up-highest-bold" xlink:href="#up-highest-bold">
     </use>
    </svg>
   </button>
   <!--googleon: all-->
   <script src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-dependencies.min.407b108c60433f00a6b1a0e8f272a2c1.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-base-ux25.min.91a4ebeb2dec9b19aa121b5c7154ff51.js">
   </script>
   <!-- <sly data-sly-test="false">
        <script type="text/javascript" src='/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/resources/au/js/au.js'></script>
    </sly> -->
   <!--[if lt IE 9]>
    <script src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/ie9/html5.js"></script>
    <![endif]-->
   <!--[if lte IE 9]>
    <script type='text/javascript' src='//cdnjs.cloudflare.com/ajax/libs/jquery-ajaxtransport-xdomainrequest/1.0.3/jquery.xdomainrequest.min.js'></script>
    <![endif]-->
   <script type="text/javascript">
    /* recaptcha script for Samsung 2020.07.10 */
        
        var conRecaptcha;
        var recaptchaCallback = function() {    
             if($("#Con_reCaptcha").length > 0){
                    conRecaptcha = grecaptcha.render('Con_reCaptcha', {
                        'sitekey' : '6Lc-358UAAAAAFmYE7zKV3PU0m9crt6-tj-UJsll'
                    });
             }
        };
   </script>
   <script defer="" src="https://www.google.com/recaptcha/api.js?onload=recaptchaCallback&amp;render=explicit" type="text/javascript">
   </script>
   <section aria-modal="true" class="trade-in-learn-more-popup" role="dialog">
    <div class="trade-in-learn-more-popup__dimmed">
    </div>
    <div class="trade-in-learn-more-popup__contents">
     <div class="scrollbar">
      <div class="trade-in-learn-more-popup__inner-wrap scrollbar__contents">
       <p class="trade-in-learn-more-popup__title">
        Cara kerja tukar tambah
       </p>
       <div class="trade-in-learn-more-popup__list-wrap">
        <ul class="trade-in-learn-more-popup__list">
         <li class="trade-in-learn-more-popup__list-item">
          <em class="trade-in-learn-more-popup__list-item-num">
           01
          </em>
          <div class="trade-in-learn-more-popup__list-item-text-wrap">
           <span class="trade-in-learn-more-popup__list-item-text-desc">
            Choose your new Samsung device and tell us about your old one.
            <br/>
            Jika memenuhi syarat, Anda akan melihat taksiran nilai tukar tambah.
           </span>
          </div>
         </li>
         <li class="trade-in-learn-more-popup__list-item">
          <em class="trade-in-learn-more-popup__list-item-num">
           02
          </em>
          <div class="trade-in-learn-more-popup__list-item-text-wrap">
           <span class="trade-in-learn-more-popup__list-item-text-desc">
            Get an upfront discount on the price of your new Samsung device.
           </span>
          </div>
         </li>
         <li class="trade-in-learn-more-popup__list-item">
          <em class="trade-in-learn-more-popup__list-item-num">
           03
          </em>
          <div class="trade-in-learn-more-popup__list-item-text-wrap">
           <span class="trade-in-learn-more-popup__list-item-text-desc">
            Kirimkan perangkat lama Anda untuk menyelesaikan tukar tambah.
           </span>
          </div>
         </li>
        </ul>
        <!--
            <sly data-sly-test="false">
              <div class="trade-in-learn-more-popup__cta-wrap">
                <a class="cta cta--underline cta--black cta--icon" href="https://www.samsung.com/pt/campanha-retomas/" title="Open in a New Window" target="_blank"> More Information 
                  <svg class="icon" focusable="false">
                    <use xlink:href="#outlink-bold" href="#outlink-bold"></use>
                  </svg>
                </a>
              </div>
            </sly>
            -->
       </div>
      </div>
     </div>
     <button class="trade-in-learn-more-popup__close">
      <span class="hidden">
       TUTUP
      </span>
      <svg class="icon" focusable="false">
       <use href="#delete-bold" xlink:href="#delete-bold">
       </use>
      </svg>
     </button>
    </div>
   </section>
   <input id="tariffAdditionalPromotionCarrierUrl" type="hidden"/>
   <div class="component-area" style="">
    <section aria-modal="true" class="tariff-popup" role="dialog">
     <div class="tariff-popup__dimmed">
     </div>
     <div class="tariff-popup__contents">
      <div class="tariff-popup__contents-plan" style="display:block;">
       <div class="tariff-popup__inner-wrap scrollbar">
        <div class="tariff-popup__inner scrollbar__contents">
         <div class="tariff-popup__header">
          <div class="tariff-popup__headline">
           All from one hand
          </div>
          <p class="tariff-popup__desc">
           Now you get innovative smartphone with right tariff plan.
          </p>
         </div>
         <div class="tariff-popup__choose" role="tablist" style="display:none;">
          <div class="tariff-popup__choose-item" role="presentation">
           <a aria-selected="false" class="tariff-popup__choose-item-btn" href="javascript:;" id="choose-tab-1" role="tab">
            New Contracts
           </a>
          </div>
          <div class="tariff-popup__choose-item" role="presentation">
           <div class="tariff-popup__choose-tooltip">
            <div class="tariff-popup__choose-tooltip__btn-wrap">
             <button aria-expanded="false" class="tariff-popup__choose-tooltip__btn" type="button">
              <svg class="icon help" focusable="false">
               <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#help-regular">
               </use>
              </svg>
              <svg class="icon cancel" focusable="false">
               <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#cancel-bold">
               </use>
              </svg>
              <span class="hidden">
               see what this
              </span>
             </button>
             <span class="tariff-popup__choose-tooltip__arrow">
             </span>
            </div>
            <div class="tariff-popup__choose-tooltip__box" role="tooltip">
             <span class="tariff-popup__choose-tooltip__box-arrow">
             </span>
             <p class="tariff-popup__choose-tooltip__box-desc">
              Stay with your network operator.
             </p>
            </div>
           </div>
          </div>
         </div>
         <div aria-hidden="true" aria-labelledby="choose-tab-1" class="tariff-popup__choose-panel" id="choose-content-1" role="tabpanel">
          <div class="tariff-popup__tab-wrap">
           <div class="tariff-popup__tab-list-wrap">
            <button class="tariff-popup__tab-list-prev" role="button" style="display:none;">
             prev
             <svg class="icon" focusable="false">
              <use href="#previous-bold" xlink:href="#previous-bold">
              </use>
             </svg>
            </button>
            <div class="tariff-popup__tab-list-area">
             <!--/* UK, SE 경우 Tab Divider 를 숨기기 위해 .hide-divider 추가 /*-->
             <div class="tariff-popup__tab-list" role="tablist">
              <div class="tariff-popup__tab-item-wrap" role="presentation">
               <a class="tariff-popup__tab-item" href="javascript:void(0);">
               </a>
              </div>
             </div>
            </div>
            <button class="tariff-popup__tab-list-next" role="button">
             Next
             <svg class="icon" focusable="false">
              <use href="#next-bold" xlink:href="#next-bold">
              </use>
             </svg>
            </button>
            <div class="tariff-popup__tab-list-gl-left">
            </div>
            <div class="tariff-popup__tab-list-gl-right">
            </div>
           </div>
           <div class="tariff-popup__tab-panel-wrap">
            <div class="tariff-popup__tab-panel">
            </div>
           </div>
          </div>
         </div>
         <div aria-hidden="true" aria-labelledby="choose-tab-2" class="tariff-popup__choose-panel" id="choose-content-2" role="tabpanel">
          <div class="tariff-popup__tab-wrap">
           <div class="tariff-popup__tab-list-wrap">
            <button class="tariff-popup__tab-list-prev" role="button" style="display:none;">
             prev
             <svg class="icon" focusable="false">
              <use href="#previous-bold" xlink:href="#previous-bold">
              </use>
             </svg>
            </button>
            <div class="tariff-popup__tab-list-area">
             <!--/* UK, SE 경우 Tab Divider 를 숨기기 위해 .hide-divider 추가 /*-->
             <div class="tariff-popup__tab-list" role="tablist">
             </div>
            </div>
            <button class="tariff-popup__tab-list-next" role="button">
             Next
             <svg class="icon" focusable="false">
              <use href="#next-bold" xlink:href="#next-bold">
              </use>
             </svg>
            </button>
            <div class="tariff-popup__tab-list-gl-left">
            </div>
            <div class="tariff-popup__tab-list-gl-right">
            </div>
           </div>
           <div class="tariff-popup__tab-panel-wrap">
            <div class="tariff-popup__tab-panel">
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <div class="tariff-popup__btn-wrap">
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-prev cta cta--outlined cta--black" style="display:none;">
         BATALKAN
        </button>
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-close cta cta--outlined cta--black">
         BATALKAN
        </button>
        <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:continue" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-next cta cta--contained cta--emphasis cta--disabled" disabled="">
         LANJUTKAN
        </button>
       </div>
      </div>
      <div class="tariff-popup__contents-plan-details" style="display:none;">
       <div class="tariff-popup__inner-wrap scrollbar">
        <div class="tariff-popup__inner scrollbar__contents">
         <div class="tariff-popup__header">
          <div class="tariff-popup__headline">
           The Network Plan Details
          </div>
          <p class="tariff-popup__desc">
          </p>
         </div>
         <div class="tariff-popup__plan-details-wrap">
          <section class="tariff-popup__plan-details expand">
           <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
            <span class="tariff-popup__plan-details-title-text">
             Plan Benefits
            </span>
            <span>
             <svg class="icon collapse">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-bold">
              </use>
             </svg>
             <span class="hidden collapse">
              Klik untuk Memperluas
             </span>
             <svg class="icon expand">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-bold">
              </use>
             </svg>
             <span class="hidden expand">
              Klik untuk Tutup
             </span>
            </span>
           </a>
           <div class="tariff-popup__plan-details-desc plan-benefits-desc">
           </div>
          </section>
          <section class="tariff-popup__plan-details">
           <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
            <span class="tariff-popup__plan-details-title-text">
             Out of Bundle Charges
            </span>
            <span>
             <svg class="icon collapse">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-bold">
              </use>
             </svg>
             <span class="hidden collapse">
              Klik untuk Memperluas
             </span>
             <svg class="icon expand">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-bold">
              </use>
             </svg>
             <span class="hidden expand">
              Klik untuk Tutup
             </span>
            </span>
           </a>
           <div class="tariff-popup__plan-details-desc out-of-bundle-charges-desc">
           </div>
          </section>
          <section class="tariff-popup__plan-details">
           <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
            <span class="tariff-popup__plan-details-title-text">
             Terms &amp; Conditions
            </span>
            <span>
             <svg class="icon collapse">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-bold">
              </use>
             </svg>
             <span class="hidden collapse">
              Klik untuk Memperluas
             </span>
             <svg class="icon expand">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-bold">
              </use>
             </svg>
             <span class="hidden expand">
              Klik untuk Tutup
             </span>
            </span>
           </a>
           <div class="tariff-popup__plan-details-desc term-conditions-desc">
           </div>
          </section>
         </div>
        </div>
       </div>
       <div class="tariff-popup__btn-wrap">
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-back cta cta--outlined cta--black">
         Kembali
        </button>
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-close cta cta--contained cta--emphasis">
         Tutup
        </button>
       </div>
      </div>
      <div class="tariff-popup__contents-plan-selected" style="display:none;">
       <div class="tariff-popup__inner-wrap scrollbar">
        <div class="tariff-popup__inner scrollbar__contents">
         <div class="tariff-popup__header">
          <div class="tariff-popup__headline">
           All from one hand
           <span class="tariff-popup__icon">
            <div class="image">
             <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/tariff-popup-icon.png" role="img"/>
            </div>
           </span>
          </div>
          <p class="tariff-popup__desc">
           Now you get innovative smartphone with right tariff plan.
          </p>
         </div>
         <div class="tariff-popup__selected-wrap">
          <div class="tariff-popup__selected">
           <div class="tariff-popup__selected-spec">
            <div class="tariff-popup__selected-spec-header">
             <div class="tariff-popup__selected-spec-img">
              <img alt="" src="#"/>
             </div>
             <div class="tariff-popup__selected-spec-detail">
              <strong class="tariff-popup__selected-spec-name">
              </strong>
              <span class="tariff-popup__selected-spec-value">
              </span>
             </div>
            </div>
            <div class="tariff-popup__selected-spec-desc">
             <ul class="tariff-popup__selected-spec-list">
             </ul>
            </div>
            <div class="tariff-popup__selected-add-opt">
            </div>
           </div>
           <div class="tariff-popup__selected-total">
            <div class="tariff-popup__selected-total-title">
             Upfront Cost
            </div>
            <div class="tariff-popup__selected-total-price">
            </div>
            <p class="tariff-popup__selected-total-desc">
             Der Anschlusspreis und monatlicher Tarifpreis werden vom jeweiligen Netzanbieter eingezogen. Du zahlst jetzt nur den einmaligen Ger&auml;tepreis.
            </p>
           </div>
          </div>
         </div>
         <div class="tariff-popup__checkbox-wrap">
         </div>
         <div class="tariff-popup__table-wrap">
          <div class="tariff-popup__table-inner">
          </div>
          <div class="tariff-popup__table-disclaimer">
          </div>
         </div>
        </div>
       </div>
       <div class="tariff-popup__btn-wrap">
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-prev cta cta--outlined cta--black">
         BACK
        </button>
        <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:confirm" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-submit cta cta--contained cta--emphasis cta--disabled" disabled="">
         Terapkan
        </button>
       </div>
      </div>
      <div class="tariff-popup__contents-form" style="display:none;">
       <div class="tariff-popup__inner-wrap scrollbar">
        <div class="tariff-popup__inner scrollbar__contents">
         <div class="tariff-popup__header">
          <div class="tariff-popup__headline">
           Check the availabbility
          </div>
         </div>
         <div class="tariff-popup__step">
          <div class="tariff-popup__step-inner">
           <span class="tariff-popup__step-fill is-active">
           </span>
           <span class="tariff-popup__step-fill">
           </span>
           <span class="tariff-popup__step-fill">
           </span>
          </div>
         </div>
         <div class="tariff-popup__step-progress">
          <span class="hidden">
           1 of 3
          </span>
         </div>
         <div class="tariff-popup__validation-message">
          <strong class="tariff-popup__validation-message-title">
           Wrong address
          </strong>
          <div class="tariff-popup__validation-message-content">
           <p>
            Unfortunately, we cannot make you a DSL offer for the address you have checked.The address you have given is not unique, please choose from the address suggestions.
           </p>
          </div>
         </div>
         <div class="tariff-popup__form-wrap">
          <div class="tariff-popup__form-list">
           <div class="tariff-popup__form-item tariff-popup__form-item-wide" style="display:none;">
            <div class="menu menu--text-field" data-comp-name="menu" data-max-item-number="5" data-type="textField">
             <select aria-labelledby="tariff-addr-label-id" class="menu__select" tabindex="-1">
             </select>
             <p class="menu--text-field__hint" id="tariff-addr-label-id">
              Empfohlene Adresse
             </p>
             <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="tariff-addr-label-id tariff-text-label-id" class="menu__select-field" type="button">
              <span class="menu__select-field-text" id="tariff-text-label-id">
              </span>
              <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
               <use href="#open-down-bold" xlink:href="#open-down-bold">
               </use>
              </svg>
              <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
               <use href="#close-up-bold" xlink:href="#close-up-bold">
               </use>
              </svg>
             </button>
            </div>
           </div>
           <div class="tariff-popup__form-item tariff-popup__form-item-wide">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-tariff-postcode">
              Postcode
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-tariff-postcode" maxlength="5" name="postCode" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Please provide a valid postcode
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
           <div class="tariff-popup__form-item">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-tariff-street">
              Street
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-tariff-street" name="streetName" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Please provide a valid street
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
           <div class="tariff-popup__form-item">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-3">
              House number
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-3" name="houseNumber" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Please provide a valid house number
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
           <div class="tariff-popup__form-item">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-4">
              Additional house information
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-4" name="houseNumberAddition" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Additional information placeholder
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
           <div class="tariff-popup__form-item">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-5">
              City
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-5" name="locality" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Please provide a valid city
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
          </div>
         </div>
         <p class="tariff-popup__form-txt">
          *Required fields
         </p>
         <div class="tariff-popup__disclaimer-wrap">
          <div class="tariff-popup__disclaimer">
           Anda dapat menemukan informasi tentang pengolahan data pribadi melalui link
           <a href="https://www.samsung.com/id/info/privacy/" target="_blank" title="Open in a new window">
            Kebijakan privasi
           </a>
           .
          </div>
         </div>
        </div>
       </div>
       <div class="tariff-popup__btn-wrap">
        <button class="tariff-popup__btn-close cta cta--outlined cta--black">
         Batalkan
        </button>
        <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
        <button class="tariff-popup__btn-next cta cta--contained cta--emphasis cta--disabled" disabled="">
         Lanjutkan
        </button>
       </div>
      </div>
      <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
      </button>
     </div>
    </section>
   </div>
   <div class="tariff-info-popup">
    <div class="layer-popup" id="tariff-info-popup" role="dialog" style="display:block">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="layer-popup__title">
         Pay monthly phone contracts
        </div>
        <p class="layer-popup__desc">
         Buy your phone along with an inclusive monthly network plan and pay monthly*
        </p>
        <div class="tariff-info-popup__wrap">
         <div class="tariff-info-popup__inner">
          <div class="tariff-info-popup__more">
           <ul class="tariff-info-popup__more-list">
            <li>
             <strong class="tariff-info-popup__more-title">
              Choose your network
             </strong>
             <p class="tariff-info-popup__more-text">
              Choose from a range of networks and inclusive monthly plans to get started with your new Galaxy phone straight away.
             </p>
            </li>
            <li>
             <strong class="tariff-info-popup__more-title">
              Bayar Bulanan
             </strong>
             <p class="tariff-info-popup__more-text">
              Pay for your phone and an inclusive bundle of calls, texts and data in one easy-to-manage monthly fee.
             </p>
            </li>
            <li>
             <strong class="tariff-info-popup__more-title">
              Next steps
             </strong>
             <p class="tariff-info-popup__more-text">
              You will be redirected to our trusted partner, A1 Comms Ltd (trading as Mobileshop), to purchase your phone and setup your monthly plan.
             </p>
            </li>
           </ul>
          </div>
          <div class="tariff-info-popup__info">
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="tariff-info-popup__cta">
       <!--/* P6의 cta 적용 방식에 따라 마크업 변경 */ -->
       <a class="cta cta--contained cta--emphasis" href="javascript:void(0);" title="Link Title">
        Choose your plan
       </a>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Layer Popup Close
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <input id="cfTradeInConditionCheckYn" type="hidden"/>
   <input id="cfTradeInCategoryUseYn" type="hidden"/>
   <section aria-modal="true" class="trade-in-popup" id="hubble-tradein-layer" role="dialog">
    <div class="trade-in-popup__dimmed">
    </div>
    <div class="trade-in-popup__contents">
     <!-- new-hybris -->
     <div class="trade-in-popup__zipcode-wrap" role="dialog">
      <div class="scrollbar">
       <div class="trade-in-popup__inner-wrap scrollbar__contents">
        <p class="trade-in-popup__title">
         Cek layanan tukar tambah di area Anda!
        </p>
        <div class="trade-in-popup__imei">
         <div class="trade-in-popup__imei-desc-wrap">
          <p class="trade-in-popup__imei-desc">
           Akses menu Tukar Tambah di aplikasi Samsung Gift Indonesia atau unduh aplikasi SS.com Trade In untuk memeriksakan ponsel pintar Anda. Setelah ponsel Anda lolos uji, IMEI perangkat lama Anda akan tercatat dalam basis data kami, sehingga Anda dapat menikmati diskon tukar tambah khusus.
          </p>
          <p class="trade-in-popup__imei-desc">
           <a href="https://www.samsung.com/id/offer/mobile-trade-in/" target="_blank" title="Buka di Tab Baru">
            SAMSUNG TRADE IN
           </a>
          </p>
         </div>
         <div class="trade-in-popup__imei-form-wrap">
          <strong class="trade-in-popup__imei-form-title">
           Masukkan kode pos Anda
          </strong>
          <div class="trade-in-popup__imei-form">
           <div class="text-field-v2 no-title">
            <label class="text-field-v2__hint" for="zipcode-input">
             Kode Pos (5 angka)
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="off" class="text-field-v2__input" id="zipcode-input" maxlength="5" type="text" value=""/>
             <button class="text-field-v2__input-icon delete" title="Delete">
              <svg class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
            </div>
            <p class="text-field-v2__text error">
            </p>
            <p class="text-field-v2__text success">
             Tukar tambah tersedia di area&nbsp;kode pos Anda
            </p>
           </div>
          </div>
         </div>
        </div>
        <div class="trade-in-popup__dropdown-wrap">
         <div class="trade-in-popup__brand-dropdown-wrap">
          <p class="trade-in-popup__dropdown-title">
           Estimasi harga tertinggi perangkat lama Anda
          </p>
          <div class="trade-in-popup__dropdown">
           <button class="trade-in-popup__dropdown--select-field">
            <span class="trade-in-popup__dropdown--select-field-name">
             Select Brand
            </span>
           </button>
           <div class="trade-in-popup__dropdown--select-list scrollbar">
            <ul class="scrollbar__contents">
            </ul>
           </div>
          </div>
         </div>
         <div class="trade-in-popup__model-dropdown-wrap">
          <p class="trade-in-popup__dropdown-title">
           Estimasi harga tertinggi perangkat lama Anda
          </p>
          <div class="trade-in-popup__dropdown">
           <button class="trade-in-popup__dropdown--select-field">
            <span class="trade-in-popup__dropdown--select-field-name">
             Select Model
            </span>
            <span class="trade-in-popup__dropdown--select-field-price">
            </span>
           </button>
           <div class="trade-in-popup__dropdown--select-list scrollbar">
            <ul class="scrollbar__contents">
             <li class="trade-in-popup__dropdown--search-wrap">
              <label class="trade-in-popup__dropdown--search-label" for="trade-in-popup__dropdown--search-model">
               Search...
              </label>
              <input autocomplete="off" class="trade-in-popup__dropdown--search-input" id="trade-in-popup__dropdown--search-model" type="text"/>
              <button class="trade-in-popup__dropdown--search-btn" type="submit">
               <span class="hidden">
                select device model search
               </span>
              </button>
             </li>
            </ul>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="trade-in-popup__btn-wrap">
       <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
       <button class="trade-in-popup__btn-close cta cta--outlined cta--black">
        Tutup
       </button>
       <!-- CTA 활성화 시 .cta--disabled 제거 -->
       <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="zipcode">
        Lanjutkan
       </button>
      </div>
     </div>
     <div class="trade-in-popup__imei-wrap" role="dialog">
      <div class="scrollbar">
       <div class="trade-in-popup__inner-wrap scrollbar__contents">
        <p class="trade-in-popup__title">
         Masukkan IMEI perangkat lama Anda
        </p>
        <!-- new-hybris -->
        <strong class="trade-in-popup__procedure-title">
         Prosedur tukar tambah Samsung
        </strong>
        <ul class="trade-in-popup__procedure">
         <li class="trade-in-popup__procedure-item">
          <div class="trade-in-popup__procedure-item-img">
           <div class="image">
            <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/test-trade-in-imei-procedure-1.jpg" role="img"/>
           </div>
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           1. Download App SS.com
          </p>
          <div class="trade-in-popup__procedure-link-wrap">
           <a class="trade-in-popup__procedure-link" href="https://play.google.com/store/apps/details?id=com.stradein.bct.lk6">
            <div class="image">
             <img alt="google play link" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/icon-trade-in-down-google.png" role="img"/>
            </div>
           </a>
           <a class="trade-in-popup__procedure-link" href="https://apps.apple.com/id/app/ss-com-trade-in/id1516570115">
            <div class="image">
             <img alt="app store link" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/icon-trade-in-down-apple.png" role="img"/>
            </div>
           </a>
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           atau
           <br/>
           Gunakan App
           <br/>
           <a aria-label="Open in a new window" href="https://links.s-gift.app/tradein" target="_blank" title="Buka di Tab Baru">
            Samsung Gift Indonesia
           </a>
          </p>
          <div class="trade-in-popup__procedure-link-wrap">
           <a class="trade-in-popup__procedure-link" href="https://links.s-gift.app/tradein" target="_blank" title="Buka di Tab Baru">
            <div class="image">
             <img alt="samsung gift link" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/icon-trade-in-down-gift.png" role="img"/>
            </div>
           </a>
          </div>
         </li>
         <li class="trade-in-popup__procedure-item">
          <div class="trade-in-popup__procedure-item-img">
           <div class="image">
            <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/test-trade-in-imei-procedure-2.jpg" role="img"/>
           </div>
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           2. Lanjutkan proses pada aplikasi untuk mendapatkan harga estimasi  smartphone
          </p>
         </li>
         <li class="trade-in-popup__procedure-item">
          <div class="trade-in-popup__procedure-item-img">
           <div class="image">
            <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/test-trade-in-imei-procedure-3.jpg" role="img"/>
           </div>
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           3. Kembali ke laman produk Galaxy yang Anda inginkan dan masukkan kode IMEI
          </p>
         </li>
         <li class="trade-in-popup__procedure-item">
          <div class="trade-in-popup__procedure-item-img">
           <div class="image">
            <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/test-trade-in-imei-procedure-4.jpg" role="img"/>
           </div>
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           4. Lanjutkan dengan menyetujui harga perangkat lama Anda
          </p>
         </li>
        </ul>
        <div class="trade-in-popup__imei">
         <div class="trade-in-popup__imei-method-wrap">
          <strong class="trade-in-popup__imei-method-title">
           Cara menemukan IMEI Anda
          </strong>
          <div class="trade-in-popup__imei-method">
           <div class="trade-in-popup__imei-method-img">
            <div class="image">
             <img alt="alternative text" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/icon-trade-imei.svg" role="img"/>
            </div>
           </div>
           <strong class="trade-in-popup__imei-method-num">
            <span>
             *
            </span>
            #06#
           </strong>
          </div>
          <ul class="trade-in-popup__imei-method-list">
           <li class="trade-in-popup__imei-method-list-item">
            <span>
             Option 1
            </span>
            <span>
             Tekan * # 06 # untuk menemukan IMEI Anda.
            </span>
           </li>
           <li class="trade-in-popup__imei-method-list-item">
            <span>
             Option 2
            </span>
            <span>
             Buka Pengaturan&gt; Umum&gt; Tentang menampilkan IMEI.
            </span>
           </li>
           <!-- new-hybris -->
          </ul>
         </div>
         <div class="trade-in-popup__imei-form-wrap">
          <strong class="trade-in-popup__imei-form-title">
           Masukkan nomor IMEI Anda
          </strong>
          <div class="trade-in-popup__imei-form">
           <div class="text-field-v2 no-title">
            <label class="text-field-v2__hint" for="imei-input">
             Nomor IMEI (15 digit)
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="off" class="text-field-v2__input" id="imei-input" maxlength="15" type="text" value=""/>
             <button class="text-field-v2__input-icon delete" title="Delete">
              <svg class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
            </div>
            <p class="text-field-v2__text error">
             Mohon masukkan IMEI atau Nomor Serial yang valid
            </p>
            <p class="text-field-v2__text success">
             Benar
            </p>
           </div>
          </div>
         </div>
        </div>
        <div class="trade-in-popup__confirm-terms">
        </div>
        <div class="trade-in-popup__disclaimer-wrap">
         <p class="trade-in-popup__disclaimer">
         </p>
        </div>
       </div>
      </div>
      <div class="trade-in-popup__btn-wrap">
       <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
       <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="imei">
        Kembali
       </button>
       <!-- CTA 활성화 시 .cta--disabled 제거 -->
       <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="imei">
        Lanjutkan
       </button>
      </div>
     </div>
     <div class="trade-in-popup__condition-wrap" role="dialog">
      <div class="scrollbar">
       <div class="trade-in-popup__inner-wrap scrollbar__contents">
        <p class="trade-in-popup__title">
         Last step, Is your phone in good condition?
        </p>
        <form id="conditionForm" method="post" name="conditionForm">
         <ul class="trade-in-popup__condition-list">
         </ul>
        </form>
        <!-- 필요 시 추가 -->
        <!-- 활성화 시 .trade-in-popup__condition-error--show 추가 -->
        <p class="trade-in-popup__condition-error">
         Not eligible for trade-in
        </p>
        <!-- new-hybris  -->
        <div class="trade-in-popup__disclaimer-wrap">
         <p class="trade-in-popup__disclaimer">
         </p>
        </div>
       </div>
      </div>
      <div class="trade-in-popup__btn-wrap">
       <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
       <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="condition">
        Kembali
       </button>
       <!-- CTA 활성화 시 .cta--disabled 제거 -->
       <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="condition">
        Lanjutkan
       </button>
      </div>
     </div>
     <div class="trade-in-popup__apply-wrap" role="dialog">
      <div class="scrollbar">
       <div class="trade-in-popup__inner-wrap scrollbar__contents">
        <p class="trade-in-popup__title">
         Harga diskon tukar tambah yang Anda&nbsp;dapatkan
        </p>
        <div class="trade-in-popup__summary-wrap">
         <div class="trade-in-popup__summary">
          <div class="trade-in-popup__summary-product-wrap">
           <strong class="trade-in-popup__summary-product-brand">
           </strong>
           <strong class="trade-in-popup__summary-product-model">
           </strong>
           <span class="trade-in-popup__summary-product-number">
           </span>
          </div>
          <div class="trade-in-popup__summary-price-wrap">
           <span class="trade-in-popup__summary-price-title cashbacklist">
            Harga Tukar Tambah
           </span>
           <em class="trade-in-popup__summary-price">
           </em>
           <span class="trade-in-popup__summary-price-desc">
           </span>
          </div>
         </div>
         <div class="trade-in-popup__summary-message-wrap">
          <!-- new-hybris -->
          <p class="trade-in-popup__summary-message">
          </p>
          <p class="trade-in-popup__summary-message--error">
          </p>
         </div>
        </div>
        <!-- <sly data-sly-test="false">
                <div class="trade-in-popup__apply-how-to">
                <strong class="trade-in-popup__apply-how-to-title">How to save money on a new device?</strong>
                    <ul class="trade-in-popup__apply-how-to-list">
                        <li class="trade-in-popup__apply-how-to-item">
                            <span class="trade-in-popup__apply-how-to-item-num">1.</span>
                            <span class="trade-in-popup__apply-how-to-item-text">Untuk smartphone lama Anda, dapatkan diskon untuk smartphone baru di ritel-ritel kami</span>
                        </li>
                        <li class="trade-in-popup__apply-how-to-item">
                            <span class="trade-in-popup__apply-how-to-item-num">2.</span>
                            <span class="trade-in-popup__apply-how-to-item-text">Nilai smartphone lama ditentukan oleh konsultan di lokasi penjualan , tergantung pada kondisi dan model perangkat.</span>
                        </li>
                        <li class="trade-in-popup__apply-how-to-item">
                            <span class="trade-in-popup__apply-how-to-item-num">3.</span>
                            <span class="trade-in-popup__apply-how-to-item-text">Kunjungi toko penjualan yang paling nyaman bagi Anda. Tinggalkan smartphone lama Anda dan beli yang baru.</span>
                        </li>
                    </ul>
                </div>
            </sly> -->
        <div class="trade-in-popup__confirm-terms s-border-top">
         <strong class="trade-in-popup__confirm-terms-title">
          Konfirmasi Syarat dan Ketentuan
         </strong>
        </div>
        <div class="trade-in-popup__disclaimer-wrap">
         <p class="trade-in-popup__disclaimer">
         </p>
        </div>
       </div>
      </div>
      <div class="trade-in-popup__btn-wrap">
       <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
       <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="apply">
        Kembali
       </button>
       <!-- CTA 활성화 시 .cta--disabled 제거 -->
       <button aria-disabled="true" class="trade-in-popup__btn-apply cta cta--contained cta--emphasis cta--disabled">
        Yakin
       </button>
      </div>
     </div>
     <button class="trade-in-popup__close">
      <span class="hidden">
       Tutup
      </span>
      <svg class="icon" focusable="false">
       <use href="#delete-bold" xlink:href="#delete-bold">
       </use>
      </svg>
     </button>
    </div>
   </section>
   <div aria-modal="true" class="upgrade-popup" role="dialog">
    <div class="upgrade-popup__dimmed">
    </div>
    <div class="upgrade-popup__content">
     <div class="scrollbar">
      <div class="upgrade-popup__content-wrap scrollbar__contents">
       <div class="upgrade-popup__header">
        <strong class="upgrade-popup__title">
         Upgrade Terms and Conditions
        </strong>
       </div>
       <div class="upgrade-popup__body">
        <div class="upgrade-popup__apply">
         <div class="upgrade-popup__apply-img">
          <svg class="icon">
           <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#phone-light">
           </use>
          </svg>
         </div>
         <div class="upgrade-popup__apply-content">
         </div>
        </div>
        <ul class="upgrade-popup__condition-wrap">
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
           <div class="image">
            <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-01.png" role="img"/>
           </div>
          </div>
          <p class="upgrade-popup__desc">
           Hidupkan ponsel dan tahan catu daya
          </p>
         </li>
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
           <div class="image">
            <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-02.png" role="img"/>
           </div>
          </div>
          <p class="upgrade-popup__desc">
           Keausan normal
          </p>
         </li>
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
           <div class="image">
            <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-03.png" role="img"/>
           </div>
          </div>
          <p class="upgrade-popup__desc">
           Layar berfungsi &amp; tidak ada layar yang retak
          </p>
         </li>
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
           <div class="image">
            <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-04.png" role="img"/>
           </div>
          </div>
          <p class="upgrade-popup__desc">
           Not blacklisted
          </p>
         </li>
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
           <div class="image">
            <img alt="condition image" class="image__main lazy-load" data-comp-name="image" data-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/upgrade-popup-condition-icon-05.png" role="img"/>
           </div>
          </div>
          <p class="upgrade-popup__desc">
           Factory reset &amp; non-aktifkan penguncian aplikasi
          </p>
         </li>
        </ul>
        <div class="upgrade-popup__check-info">
        </div>
        <div class="upgrade-popup__disclaimer-wrap">
         <p>
         </p>
        </div>
       </div>
      </div>
     </div>
     <div class="upgrade-popup__footer">
      <div class="upgrade-popup__cta-wrap">
       <button an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:close" an-tr="header(pim)_service option selector-product detail-text-button" class="cta cta--outlined cta--black upgrade-popup__cta--close">
        TUTUP
       </button>
       <button an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:confirm" an-tr="header(pim)_service option selector-product detail-text-button" class="cta cta--contained cta--emphasis upgrade-popup__cta--submit">
        Yakin
       </button>
      </div>
     </div>
     <button class="upgrade-popup__close">
      <svg class="icon">
       <use href="#delete-bold" xlink:href="#delete-bold">
       </use>
      </svg>
      <span class="hidden">
       Tutup Layar Popup
      </span>
     </button>
    </div>
   </div>
   <div aria-modal="true" class="upgrade-learn-more-popup" role="dialog" style="display: none">
    <div class="upgrade-learn-more-popup__dimmed">
    </div>
    <div class="upgrade-learn-more-popup__content">
     <div class="scrollbar">
      <div class="upgrade-learn-more-popup__content-wrap scrollbar__contents">
      </div>
      <button class="upgrade-learn-more-popup__close">
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
       <span class="hidden">
        close popup
       </span>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="cancel-return-policy-popup" role="dialog" tabindex="0">
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
        </p>
        <div class="cancel-return-policy-popup__description">
         <div class="cancel-return-policy-popup__content">
          <p class="cancel-return-policy-popup__text">
          </p>
         </div>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="warranty-policy-popup" role="dialog" tabindex="0">
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         Jaminan
        </p>
        <div class="warranty-policy-popup__description">
         <div class="warranty-policy-popup__content">
          <p class="warranty-policy-popup__text">
          </p>
         </div>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div class="fold-alert-popup">
    <div class="layer-popup" id="fold-alert-popup" role="dialog" style="display:block" tabindex="0">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="layer-popup__title">
         We recommend to set as below to see optimized screen
        </div>
        <div class="fold-alert-popup__wrap">
         <div class="fold-alert-popup__inner">
          <ul class="fold-alert-popup__list">
           <li class="fold-alert-popup__item">
            <strong class="fold-alert-popup__title">
             Option 01
            </strong>
            <p class="fold-alert-popup__text">
             Rotate the device until it is horizontal to view the screen in landscape mode.
            </p>
           </li>
           <li class="fold-alert-popup__item">
            <strong class="fold-alert-popup__title">
             Option 02
            </strong>
            <p class="fold-alert-popup__text">
             Tab on desktop version in the browser.
            </p>
           </li>
          </ul>
         </div>
        </div>
       </div>
      </div>
      <div class="fold-alert-popup__cta">
       <!--/* P6의 cta 적용 방식에 따라 마크업 변경 */ -->
       <a class="cta cta--outlined cta--black" href="#" title="Tutup">
        Tutup
       </a>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="eip-popup" role="dialog">
    <div class="layer-popup" id="eip-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="layer-popup__title">
         Program CICILAN 0%
        </div>
        <div class="eip-popup__wrap">
         <p class="eip-popup__top-text">
          <strong>
           Harga Produk:
           <span class="eip-popup__top-text--price">
            Rp 17.099.000
           </span>
          </strong>
         </p>
         <div class="tab">
          <ul class="tab__list" role="tablist">
           <li class="tab__item" role="presentation">
            <button class="tab__item-title" role="tab">
             Cicilan Kartu Kredit
             <span class="tab__item-line">
             </span>
            </button>
           </li>
          </ul>
         </div>
         <div class="eip-popup__tab-wrap">
          <div class="eip-popup__tab">
           <div class="eip-popup__tab--dropdown-wrap">
            <p class="eip-popup__tab--dropdown-title">
             Pilih Bank
            </p>
            <button class="eip-popup__tab--dropdown">
             BCA
            </button>
           </div>
           <div class="eip-popup__tab--select-wrap scrollbar">
            <div class="scrollbar__contents">
             <ul>
             </ul>
            </div>
           </div>
           <div class="eip-popup__tab--table-wrap scrollbar">
            <div class="scrollbar__contents">
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="hubble-careinfo-popup" role="dialog">
    <div class="layer-popup" id="hubble-careinfo">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         Samsung Care+
        </p>
        <div class="hubble-careinfo-popup__body">
         <div class="hubble-careinfo-popup__info-wrap">
          <dl class="hubble-careinfo-popup__info">
          </dl>
         </div>
         <div class="hubble-careinfo-popup__explain">
          <p>
           Samsung Care+ Disclaimer with link
          </p>
         </div>
        </div>
       </div>
      </div>
      <!-- siteCode == 'za' -->
      <button class="hubble-care-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="sc-learn-more-popup" role="dialog">
    <div class="layer-popup" id="ScLearnMorePopup">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         Here&rsquo;s what&rsquo;s covered
        </p>
        <div class="sc-learn-more-popup__body">
         <ul class="sc-learn-more-popup__list">
          <li class="sc-learn-more-popup__item">
           <div class="sc-learn-more-popup__image">
            <div class="image">
             <img alt="alt text" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-mo.png?$260_140_PNG$" role="img"/>
             <img alt="alt text" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-accidental-damage-repair-mo.png?$260_140_PNG$" role="img"/>
            </div>
           </div>
           <strong class="sc-learn-more-popup__title">
            Hardware repairs
           </strong>
           <p class="sc-learn-more-popup__text">
            Get fast, convenient repairs using genuine Samsung parts, from our authorized technicians.
           </p>
          </li>
          <li class="sc-learn-more-popup__item">
           <div class="sc-learn-more-popup__image">
            <div class="image">
             <img alt="alt text" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-mo.png?$260_140_PNG$" role="img"/>
             <img alt="alt text" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-software-malfunction-mo.png?$260_140_PNG$" role="img"/>
            </div>
           </div>
           <strong class="sc-learn-more-popup__title">
            Software coverage
           </strong>
           <p class="sc-learn-more-popup__text">
            If your device isn&rsquo;t running smoothly, we&rsquo;ll check and fix the issue.
           </p>
          </li>
          <li class="sc-learn-more-popup__item">
           <div class="sc-learn-more-popup__image">
            <div class="image">
             <img alt="alt text" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-mo.png?$260_140_PNG$" role="img"/>
             <img alt="alt text" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-pc.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03-coverage-battery-replacement-mo.png?$260_140_PNG$" role="img"/>
            </div>
           </div>
           <strong class="sc-learn-more-popup__title">
            Battery replacement
           </strong>
           <p class="sc-learn-more-popup__text">
            Stay powered up with hassle-free battery replacements.
           </p>
          </li>
          <li class="sc-learn-more-popup__item">
           <div class="sc-learn-more-popup__image">
            <div class="image">
             <img alt="alt text" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png$260_140_PNG$" role="img"/>
             <img alt="alt text" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png?$198_106_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/03_coverage_Upto2claims.png$260_140_PNG$" role="img"/>
            </div>
           </div>
           <strong class="sc-learn-more-popup__title">
            4 claims within
           </strong>
           <p class="sc-learn-more-popup__text">
            Make up to 4 claims for repair  or replacement  within 2 years,  and save with a low deductible  per claim.
           </p>
          </li>
         </ul>
         <div class="sc-learn-more-popup__cta">
          <a aria-label="Link Title" class="cta cta--underline cta--black cta--icon" href="https://www.samsung.com/id/offer/samsung-care-plus/" target="_blank">
           See all benefits
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#outlink-bold" xlink:href="#outlink-bold">
            </use>
           </svg>
          </a>
         </div>
         <div class="sc-learn-more-popup__disclaimer">
         </div>
        </div>
       </div>
      </div>
      <button class="sc-learn-more-popup__close">
       <span class="hidden">
        Close popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="hubble-care-popup smcpopup" role="dialog">
    <div class="layer-popup" id="hubble-care">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title layer-popup__title--no-icon">
         Samsung Care+
        </p>
        <p class="layer-popup__desc">
         <!-- CRHQ-3719 -->
         Layanan Perbaikan Secara Total untuk Smartphone Galaxy Anda. Hindari Kejadian Tidak Terduga Dengan Perlindungan Ekstra
        </p>
        <div class="hubble-care-popup__body">
         <div class="hubble-care-popup__smc">
          <div class="hubble-care-popup__smc-inner">
          </div>
          <p class="hubble-care-popup__smc-message" style="display: none">
          </p>
         </div>
         <div class="hubble-care-popup__image">
          <div class="image">
           <img alt="Accidental damage, Worldwide cover, Repairs by genuine parts" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image-new.jpg" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image.jpg"/>
           <img alt="Accidental damage, Worldwide cover, Repairs by genuine parts" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image-new.jpg" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/@care-image.jpg"/>
          </div>
         </div>
         <div class="hubble-care-popup__check">
          <div class="hubble-care-popup__check-title">
           Syarat dan Ketentuan Samsung Protection
          </div>
          <ul class="hubble-care-popup__check-list-wrap">
          </ul>
          <p aria-hidden="true" class="hubble-care-popup__check-error">
           *Anda harus menyetujui terlebih dahulu
          </p>
         </div>

        </div>
       </div>
      </div>
      <div class="hubble-care-popup__foot">
       <div class="hubble-care-popup__button">
        <div class="hubble-care-popup__button-inner">
         <div class="hubble-care-popup__button-item">
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:close" an-tr="header(pim)_service option selector:samsung care-product detail-close-option_click1" class="cta cta--outlined cta--black" href="javascript:void(0)" role="button">
           Tutup
          </a>
         </div>
         <div class="hubble-care-popup__button-item">
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:confirm" an-tr="header(pim)_service option selector:samsung care-product detail-confirm-option_click1" aria-disabled="true" class="cta cta--contained cta--emphasis cta--disabled" href="javascript:void(0)" role="button">
           Yakin
          </a>
         </div>
        </div>
       </div>
      </div>
      <button class="hubble-care-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="hubble-care-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="hubble-care-alert1">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       Ich habe die Allgemeinen Versicherungsbedingungen heruntergeladen, gelesen und erkl&auml;re mich mit diesen einverstanden.
       <div class="hubble-care-popup__alert-button">
        <a class="cta cta--contained cta--emphasis" href="#" title="Best&auml;tigen">
         Best&auml;tigen
        </a>
       </div>
      </div>
      <button class="hubble-care-popup__alert-close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="hubble-care-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="hubble-care-alert2">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       Ich habe das Informationsblatt zur Versicherung heruntergeladen und sorgf&auml;ltig durchgelesen.
       <div class="hubble-care-popup__alert-button">
        <a class="cta cta--contained cta--emphasis" href="#" title="Best&auml;tigen">
         Best&auml;tigen
        </a>
       </div>
      </div>
      <button class="hubble-care-popup__alert-close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <input id="WishlistPopupUrl" type="hidden" value="/id/web/my-wishlist/"/>
   <div class="wishlist-popup">
    <div aria-modal="true" class="layer-popup" id="wishlist-popup" role="dialog" style="display:block">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       <p class="layer-popup__title">
       </p>
       <div class="wishlist-popup__desc">
       </div>
       <div class="wishlist-popup__selectbox__wrap">
        <div class="wishlist-popup__selectbox">
         <div class="wishlist-popup__selectbox-inner">
          <div class="menu filled">
           <select class="menu__select" data-default-message="My Wishlist" tabindex="-1">
            <option value="">
             My Wishlist 1
            </option>
            <option value="">
             My Wishlist 2
            </option>
            <option value="">
             My Wishlist 3
            </option>
            <option value="">
             My Wishlist 4
            </option>
            <option value="">
             My Wishlist 5
            </option>
            <option value="">
             My Wishlist 6
            </option>
            <option value="">
             My Wishlist 7
            </option>
            <option value="">
             My Wishlist 8
            </option>
            <option value="">
             My Wishlist 9
            </option>
           </select>
           <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
            <span class="menu__select-field-text">
            </span>
            <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
             <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-bold">
             </use>
            </svg>
            <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
             <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-bold">
             </use>
            </svg>
           </button>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="wishlist-popup__cta-wrap">
       <div class="wishlist-popup__cta">
        <a aria-label="Link Title" class="cta cta--outlined cta--black" href="#" role="button">
        </a>
       </div>
       <div class="wishlist-popup__cta">
        <a class="cta cta--contained cta--emphasis" href="#" role="button">
        </a>
       </div>
      </div>
      <button class="layer-popup__close wishlist-popup__close" type="button">
       <span class="hidden">
        Close popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="extended-warranty-popup" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         EXTENDED WARRANTY
        </p>
        <p class="layer-popup__desc">
         Layanan Perbaikan Secara Total untuk Smartphone Galaxy Anda. Hindari Kejadian Tidak Terduga Dengan Perlindungan Ekstra
        </p>
        <div class="extended-warranty-popup__body">
         <div class="extended-warranty-popup__smc">
          <div class="extended-warranty-popup__smc-inner">
          </div>
          <p class="extended-warranty-popup__smc-message" style="display: none">
           ※ Cover until canceled. Financing program is not available with device purchasing
          </p>
          <p class="extended-warranty-popup__smc-message" style="display: none">
           ※ Cover for 24 months. Financing program is available with device purchasing
          </p>
         </div>
         <div class="extended-warranty-popup__image">
          <div class="image">
           <img alt="Accidental damage, Worldwide cover, Repairs by genuine parts" class="image__preview lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-pc-uk.jpg?$380_223_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-mo-uk.jpg?$680_398_PNG$"/>
           <img alt="Accidental damage, Worldwide cover, Repairs by genuine parts" class="image__main lazy-load responsive-img" data-desktop-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-pc-uk.jpg?$380_223_PNG$" data-mobile-src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/care-image-mo-uk.jpg?$680_398_PNG$"/>
          </div>
         </div>
         <div class="extended-warranty-popup__info-box">
          <!-- 필요 시 smc-inner 의 .checkbox-radio 의 갯수와 동일하게 구현 -->
         </div>
         <div class="extended-warranty-popup__check">
          <div class="extended-warranty-popup__check-title">
           Syarat dan Ketentuan Samsung Protection
          </div>
         </div>
         <div class="extended-warranty-popup__policy-text" id="cfCareIPID">
         </div>
        </div>
       </div>
      </div>
      <div class="extended-warranty-popup__foot">
       <div class="extended-warranty-popup__button">
        <div class="extended-warranty-popup__button-description">
         <p>
          By clicking on confirm, you agree to Samsung terms and conditions.
         </p>
        </div>
        <div class="extended-warranty-popup__button-inner">
         <div class="extended-warranty-popup__button-item">
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung warranty:close" an-tr="header(pim)_service option selector-product detail-popup-button" class="cta cta--outlined cta--black" href="#" role="button">
           Tutup
          </a>
         </div>
         <div class="extended-warranty-popup__button-item">
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung warranty:confirm" an-tr="header(pim)_service option selector-product detail-popup-button" class="cta cta--contained cta--emphasis cta--disabled" href="#" role="button">
           Yakin
          </a>
         </div>
        </div>
       </div>
      </div>
      <button class="extended-warranty-popup__close">
       <span class="hidden">
        Layer Popup Close
       </span>
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="extended-warranty-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-alert1">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       Ich habe die Allgemeinen Versicherungsbedingungen heruntergeladen, gelesen und erkl&auml;re mich mit diesen einverstanden.
       <div class="extended-warranty-popup__alert-button">
        <a class="cta cta--contained cta--emphasis" href="#">
         Best&auml;tigen
        </a>
       </div>
      </div>
      <button class="extended-warranty-popup__alert-close">
       <span class="hidden">
        Layer Popup Close
       </span>
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="extended-warranty-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-alert2">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       Ich habe das Informationsblatt zur Versicherung heruntergeladen und sorgf&auml;ltig durchgelesen.
       <div class="extended-warranty-popup__alert-button">
        <a class="cta cta--contained cta--emphasis" href="#" title="">
         Best&auml;tigen
        </a>
       </div>
      </div>
      <button class="extended-warranty-popup__alert-close">
       <span class="hidden">
        Layer Popup Close
       </span>
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="extended-warranty-popup-vd" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-vd">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         Extended Warranty
        </p>
        <p class="layer-popup__desc">
         Perpanjang durasi garansi pabrik untuk produk Anda
        </p>
        <div class="extended-warranty-popup-vd__body">
         <div class="extended-warranty-popup-vd__option">
          <div class="pd-select-option">
           <div class="pd-select-option__wrap">
            <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
            </ul>
           </div>
          </div>
         </div>
         <div class="extended-warranty-popup-vd__check">
          <div class="extended-warranty-popup-vd__check-title">
           Ketentuan Untuk Extended Warranty
          </div>
          <ul class="extended-warranty-popup-vd__check-list-wrap">
          </ul>
         </div>
        </div>
       </div>
      </div>
      <div class="extended-warranty-popup-vd__foot">
       <div class="extended-warranty-popup-vd__button">
        <div class="extended-warranty-popup-vd__button-inner">
         <div class="extended-warranty-popup-vd__button-item">
          <a class="cta cta--outlined cta--black" href="#" role="button">
           Tutup
          </a>
         </div>
         <div class="extended-warranty-popup-vd__button-item">
          <a class="cta cta--contained cta--emphasis cta--disabled" href="#" role="button">
           Yakin
          </a>
         </div>
        </div>
       </div>
      </div>
      <button class="extended-warranty-popup-vd__close">
       <span class="hidden">
        Close popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div class="warranty-info-popup">
    <div class="layer-popup" role="dialog" style="display:none" tabindex="0">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         EXTENDED WARRANTY
        </p>
        <div class="warranty-info-popup__content">
         <div class="warranty-info-popup__info">
          <dl class="warranty-info-popup__info-list">
          </dl>
         </div>
         <div class="warranty-info-popup__explain">
          <p>
          </p>
         </div>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="shop-combo-popup" id="shop-combo-popup" role="dialog">
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__title">
       Pilih opsi paket kombo
      </div>
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="shop-combo-popup__list">
         <div class="shop-combo-popup__list-area">
          <div class="shop-combo-popup__list-in">
           <ul>
           </ul>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="layer__fixed-wrap">
       <div class="shop-combo-popup__summary">
        <div class="shop-combo-popup__summary-title">
         <p>
          Produk terpilih (
          <span class="s-bundle-option-count">
           0
          </span>
          )
         </p>
        </div>
        <div class="shop-combo-popup__summary-save">
         <span class="shop-combo-popup__summary-save-original">
          <span class="hidden">
           Harga awal:
          </span>
          <del>
          </del>
         </span>
         <span class="shop-combo-popup__summary-save-price">
         </span>
        </div>
        <div class="shop-combo-popup__summary-total">
         <span class="shop-combo-popup__summary-option-total">
          <strong>
          </strong>
         </span>
        </div>
        <div class="shop-combo-popup__summary-reset">
         <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:clear all" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="cta-reset" type="reset">
          Kosongkan semua
         </button>
        </div>
       </div>
      </div>
      <div class="shop-combo-popup__btn-wrap">
       <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:close" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="shop-combo-popup__btn-close cta cta--outlined cta--black">
        Tutup
       </button>
       <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:confirm" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="shop-combo-popup__btn-confirm cta cta--contained cta--emphasis cta--disabled">
        Yakin
       </button>
      </div>
      <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:close" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="free-gift-popup" role="dialog" tabindex="0">
    <div class="layer-popup" id="free-gift-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__title type-left">
       Pilih hadiah Pre-order Anda
      </div>
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="free-gift-popup__wrap">
        </div>
       </div>
      </div>
      <div class="layer-popup__foot">
       <div class="layer-popup__button">
        <div class="layer-popup__button-inner">
         <div class="layer-popup__button-item close-popup">
          <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:close" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="cta cta--outlined cta--black">
           Tutup
          </button>
         </div>
         <div class="layer-popup__button-item">
          <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:confirm" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="cta cta--contained cta--emphasis cta--disabled">
           Yakin
          </button>
         </div>
        </div>
       </div>
      </div>
      <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:layer popup close" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#cancel-close-regular">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div class="finance-ee-popup" style="display:none">
    <div class="layer-popup" id="finance ee" role="dialog" style="display:block" tabindex="0">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="finance-ee-popup__contents scrollbar__contents">
        <div class="finance-ee-popup__title">
         <strong class="finance-ee-popup__title-text">
          Choose convenient Instalment plans provided by Inbank
         </strong>
        </div>
        <div class="finance-ee-popup__description">
         <div class="finance-ee-popup__plans-contents">
          <div class="finance-ee-popup__plans-table" role="table">
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Harga produk
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <p class="finance-ee-popup__plans-text" id="productprice">
             </p>
            </div>
           </div>
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Plan
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <div class="menu">
              <select class="menu__select" id="selectplan" tabindex="-1">
              </select>
              <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
               <span class="menu__select-field-text">
               </span>
               <svg class="menu__select-field-icon down" focusable="false">
                <use href="#open-down-bold" xlink:href="#open-down-bold">
                </use>
               </svg>
               <svg class="menu__select-field-icon up" focusable="false">
                <use href="#close-up-bold" xlink:href="#close-up-bold">
                </use>
               </svg>
              </button>
             </div>
            </div>
           </div>
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Months
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <div class="menu">
              <select class="menu__select" id="selectmonths" tabindex="-1">
              </select>
              <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
               <span class="menu__select-field-text">
               </span>
               <svg class="menu__select-field-icon down" focusable="false">
                <use href="#open-down-bold" xlink:href="#open-down-bold">
                </use>
               </svg>
               <svg class="menu__select-field-icon up" focusable="false">
                <use href="#close-up-bold" xlink:href="#close-up-bold">
                </use>
               </svg>
              </button>
             </div>
            </div>
           </div>
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Interest rate
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <p class="finance-ee-popup__plans-text" id="interestrate">
             </p>
            </div>
           </div>
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Monthly payment
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <p class="finance-ee-popup__plans-text" id="monthlypayment">
             </p>
            </div>
           </div>
          </div>
         </div>
         <p class="finance-ee-popup__disclaimer">
          Ketentu Paket Angsuran
         </p>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <!-- <sly data-sly-include="ebt-popup"/> -->
   <div aria-modal="true" class="contact-mail-form-popup" role="dialog" style="display: none">
    <input id="fn06_headlineText" name="fn06_headlineText" type="hidden" value="Thank you!"/>
    <input id="fn06_description" name="fn06_description" type="hidden" value="Your enquiry has been successfully submitted. We will get back to you shortly."/>
    <input id="fn06_headlineHeadingLevel" name="fn06_headlineHeadingLevel" type="hidden" value="h2"/>
    <input id="eloquaPostUrl" name="eloquaPostUrl" type="hidden"/>
    <input id="eloquaYn" name="eloquaYn" type="hidden"/>
    <input id="inquiryType" name="inquiryType" type="hidden" value="SalesInquiry"/>
    <input id="Subsidiary" name="Subsidiary" type="hidden" value="SEIN"/>
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <p class="layer-popup__title">
       B2B Enquiry Form
      </p>
      <p class="layer-popup__description">
      </p>
      <div class="layer-popup__contents">
       <div class="contact-mail-form-popup__contents">
        <div class="contact-mail-form-popup__form">
         <form name="contact-mail-form-popup__form">
          <div class="append-from-data">
          </div>
         </form>
         <div class="contact-mail-form-popup__form-wrap">
          <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_0">
             Company Name
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="organization" class="text-field-v2__input" data-form-name="CustomerName" id="popUp_form_0" maxlength="255" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_1">
             First Name
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="given-name" class="text-field-v2__input" data-form-name="ContactFirstName" id="popUp_form_1" maxlength="40" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_2">
             Last Name
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="family-name" class="text-field-v2__input" data-form-name="ContactName" id="popUp_form_2" maxlength="80" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
           
 </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_3">
             E-mail Address
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="email" class="text-field-v2__input" data-form-name="EmailAddress" id="popUp_form_3" maxlength="80" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half field--checkbox checkbox--list is-required">
           <fieldset>
            <legend>
             Product Interest
             <span>
              * Wajib Diisi
             </span>
            </legend>
            <div class="field--checkbox-list-wrap">
             <div aria-hidden="ture" class="contact-mail-form-popup__form-field-title-wrap">
              <strong aria-hidden="true" class="contact-mail-form-popup__form-field-title">
               Product Interest
              </strong>
              <p aria-hidden="true" class="checkbox--required-text">
               * Wajib Diisi
              </p>
              <p class="checkbox--error-text">
               * This checkbox is required
              </p>
             </div>
             <div class="contact-mail-form-popup__form-field-list-wrap">
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Mobile" id="popUp_form_4-0" type="checkbox" value="Mobile"/>
                <label class="checkbox-v2__label" for="popUp_form_4-0">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Seluler
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Computing" id="popUp_form_4-1" type="checkbox" value="Computing"/>
                <label class="checkbox-v2__label" for="popUp_form_4-1">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Computing
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Displays" id="popUp_form_4-2" type="checkbox" value="Displays"/>
                <label class="checkbox-v2__label" for="popUp_form_4-2">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Displays
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Home Appliance" id="popUp_form_4-3" type="checkbox" value="Home Appliance"/>
                <label class="checkbox-v2__label" for="popUp_form_4-3">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Peralatan Rumah Tangga
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Climate" id="popUp_form_4-4" type="checkbox" value="Climate"/>
                <label class="checkbox-v2__label" for="popUp_form_4-4">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Climate
              
   </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Memory" id="popUp_form_4-5" type="checkbox" value="Memory"/>
                <label class="checkbox-v2__label" for="popUp_form_4-5">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Penyimpanan
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Healthcare" id="popUp_form_4-6" type="checkbox" value="Healthcare"/>
                <label class="checkbox-v2__label" for="popUp_form_4-6">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Healthcare
                 </span>
                </label>
               </div>
              </div>
             </div>
            </div>
            <fieldset>
            </fieldset>
           </fieldset>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_5">
             Company Address
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="address-line1" class="text-field-v2__input" data-form-name="CompanyAddress" id="popUp_form_5" maxlength="255" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_6">
             Company Industry
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="organization" class="text-field-v2__input" data-form-name="CompanyInterest" id="popUp_form_6" maxlength="255" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_7">
             Job Title
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="organization-title" class="text-field-v2__input" data-form-name="JobTitle" id="popUp_form_7" maxlength="128" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_8">
             Contact Number
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="tel" class="text-field-v2__input" data-form-name="Telephone" id="popUp_form_8" maxlength="40" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--dropdown">
           <div class="menu menu--text-field">
            <select aria-labelledby="hint_popUp_form_9" class="menu__select" data-form-name="Employee" tabindex="-1">
             <option value="&lt;50">
              &lt;50
             </option>
             <option value="50-99">
              50 ~ 99
             </option>
             <option value="100-199">
              100 ~ 199
             </option>
             <option value="200-499">
              200 ~ 499
             </option>
             <option value="500-999">
              500 ~ 999
             </option>
             <option value="&gt;1000">
              &gt;1000
             </option>
            </select>
            <p class="menu--text-field__hint" id="hint_popUp_form_9">
             No. of Employees
            </p>
            <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="hint_popUp_form_9 text_hint_popUp_form_9" class="menu__select-field" type="button">
             <span class="menu__select-field-text" id="text_hint_popUp_form_9">
             </span>
             <svg class="menu__select-field-icon down" focusable="false">
              <use href="#open-down-bold" xlink:href="#open-down-bold">
              </use>
             </svg>
             <svg class="menu__select-field-icon up" focusable="false">
              <use href="#close-up-bold" xlink:href="#close-up-bold">
              </use>
             </svg>
            </button>
            <p class="menu--text-field__error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full is-required field--dropdown">
           <div class="menu menu--text-field">
            <select aria-labelledby="hint_popUp_form_10" class="menu__select" data-form-name="Industry" tabindex="-1">
             <option value="Communications">
              Communications
             </option>
             <option value="Education">
              Education
             </option>
             <option value="Finance">
              Finance
             </option>
             <option value="Government">
              Government
             </option>
             <option value="Healthcare">
              Healthcare
             </option>
             <option value="Hospitality">
              Hospitality
             </option>
             <option value="Manufacturing">
              Manufacturing
             </option>
             <option value="Retail">
              Retail
             </option>
             <option value="Transportation &amp; Logistics">
              Transportation &amp; Logistics
             </option>
             <option value="Others">
              Lainnya
             </option>
            </select>
            <p class="menu--text-field__hint" id="hint_popUp_form_10">
             Product / Industry Interest
             <span class="text-field--required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </p>
            <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="hint_popUp_form_10 text_hint_popUp_form_10" class="menu__select-field" type="button">
             <span class="menu__select-field-text" id="text_hint_popUp_form_10">
             </span>
             <svg class="menu__select-field-icon down" focusable="false">
              <use href="#open-down-bold" xlink:href="#open-down-bold">
              </use>
             </svg>
             <svg class="menu__select-field-icon up" focusable="false">
              <use href="#close-up-bold" xlink:href="#close-up-bold">
              </use>
             </svg>
            </button>
            <p class="menu--text-field__error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half field--checkbox checkbox--list">
           <fieldset>
            <legend>
             Solution Interest
             <span>
              * Wajib Diisi
             </span>
            </legend>
            <div class="field--checkbox-list-wrap">
             <div class="contact-mail-form-popup__form-field-title-wrap">
              <strong aria-hidden="true" class="contact-mail-form-popup__form-field-title">
               Solution Interest
              </strong>
              <p class="checkbox--error-text">
               * This checkbox is required
              </p>
             </div>
             <fieldset>
              <legend>
               Solusi Bisnis Mobile
              </legend>
              <div class="contact-mail-form-popup__form-field-list-wrap">
               <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title">
                Solusi Bisnis Mobile
               </strong>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Samsung Knox" id="mbs_popUp_form_11-0" type="checkbox" value="Samsung Knox"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-0">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Samsung Knox
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Samsung DeX" id="mbs_popUp_form_11-1" type="checkbox" value="Samsung DeX"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-1">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Samsung DeX
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Samsung Pay Touch" id="mbs_popUp_form_11-2" type="checkbox" value="Samsung Pay Touch"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-2">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Samsung Pay Touch
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Capital Solutions" id="mbs_popUp_form_11-3" type="checkbox" value="Capital Solutions"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-3">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Capital Solutions
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Enterprise Technical Support" id="mbs_popUp_form_11-4" type="checkbox" value="Enterprise Technical Support"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-4">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Enterprise Technical Support
                  </span>
                 </label>
                </div>
               </div>
              </div>
             </fieldset>
             <fieldset>
              <legend>
               Solusi Tampilan
              </legend>
              <div class="contact-mail-form-popup__form-field-list-wrap">
               <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title">
                Solusi Tampilan
               </strong>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Smart signage solution" id="ds_popUp_form_11-0" type="checkbox" value="Smart signage solution"/>
                 <label class="checkbox-v2__label" for="ds_popUp_form_11-0">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Smart signage solution
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="LED signage solution" id="ds_popUp_form_11-1" type="checkbox" value="LED signage solution"/>
                 <label class="checkbox-v2__label" for="ds_popUp_form_11-1">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   LED signage solution
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Commercial TV solution" id="ds_popUp_form_11-2" type="checkbox" value="Commercial TV solution"/>
                 <label class="checkbox-v2__label" for="ds_popUp_form_11-2">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Commercial TV solution
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Monitor solution" id="ds_popUp_form_11-3" type="checkbox" value="Monitor solution"/>
                 <label class="checkbox-v2__label" for="ds_popUp_form_11-3">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Monitor solution
                  </span>
                 </label>
                </div>
               </div>
              </div>
             </fieldset>
             <fieldset>
              <legend>
               Solusi Iklim
              </legend>
              <div class="contact-mail-form-popup__form-field-list-wrap">
               <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title">
                Solusi Iklim
               </strong>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Climate Hub" id="cs_popUp_form_11-0" type="checkbox" value="Climate Hub"/>
                 <label class="checkbox-v2__label" for="cs_popUp_form_11-0">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Climate Hub
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="WindFree" id="cs_popUp_form_11-1" type="checkbox" value="WindFree"/>
                 <label class="checkbox-v2__label" for="cs_popUp_form_11-1">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   WindFree
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="360 Cassette" id="cs_popUp_form_11-2" type="checkbox" value="360 Cassette"/>
                 <label class="checkbox-v2__label" for="cs_popUp_form_11-2">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   360 Cassette
                  </span>
                 </label>
                </div>
               </div>
              </div>
             </fieldset>
            </div>
            <fieldset>
            </fieldset>
           </fieldset>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--multi-text is-required">
           <div class="text-field-v2 multi-line">
            <label class="text-field-v2__hint" for="popUp_form_12">
             Message
             <span class="text-field--required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <textarea autocomplete="on" class="text-field-v2__input-multi-line" data-form-name="Message" id="popUp_form_12" maxlength="2000"></textarea>
            </div>
            <p class="text-field-v2__text assistive" id="popUp_form_12_assistive">
             (0/2000)
            </p>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__iframe">
           <div class="contact-mail-form-popup__iframe-inner">
            <div data-callback="recaptchaCallback" id="Con_reCaptcha">
            </div>
           </div>
           <p class="invalid-notice" style="display: none">
            Verification expired. Check the checkbox again.
           </p>
          </div>
          <div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--checkbox is-required">
           <div class="field--checkbox-wrap">
            <div class="checkbox-v2">
             <input aria-describedby="popUp_form_13_required" class="checkbox-v2__input" data-form-name="PrivacyPolicy" id="popUp_form_13" type="checkbox"/>
             <label class="checkbox-v2__label" for="popUp_form_13">
              <span class="checkbox-v2__label-box-wrap">
               <span class="checkbox-v2__label-box">
                <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                 <use href="#done-bold" xlink:href="#done-bold">
                 </use>
                </svg>
               </span>
              </span>
              <span class="checkbox-v2__label-text">
               I acknowledge that my information will be processed in accordance with the Samsung privacy policy
              </span>
             </label>
            </div>
            <p aria-hidden="true" class="checkbox--required-text" id="popUp_form_13_required">
             * Wajib Diisi
            </p>
            <p aria-hidden="true" class="checkbox--error-text" id="policy_form__13_err">
             * Please agree to the Samsung Privacy Policy
            </p>
           </div>
          </div>
          <div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--checkbox is-required">
           <div class="field--checkbox-wrap">
            <div class="checkbox-v2">
             <input aria-describedby="popUp_form_14_required" class="checkbox-v2__input" data-form-name="OptIn" id="popUp_form_14" type="checkbox"/>
             <label class="checkbox-v2__label" for="popUp_form_14">
              <span class="checkbox-v2__label-box-wrap">
               <span class="checkbox-v2__label-box">
                <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                 <use href="#done-bold" xlink:href="#done-bold">
                 </use>
                </svg>
               </span>
              </span>
              <span class="checkbox-v2__label-text">
               I would like to receive information about products, services, promotions and marketing communications of Samsung and or its partners.
              </span>
             </label>
            </div>
            <p aria-hidden="true" class="checkbox--required-text" id="popUp_form_14_required">
             * Wajib Diisi
            </p>
            <p class="checkbox--error-text" id="popUp_form_14_err">
             * Please accept the Samsung Privacy
                                        Policy to proceed
            </p>
           </div>
          </div>
         </div>
        </div>
        <div class="contact-mail-form-popup__cta">
         <button aria-disabled="false" aria-label="Submit" class="cta cta--contained cta--black">
          Submit
         </button>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="thank-you-popup" id="ThankYouPopup" role="dialog">
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <p class="layer-popup__title">
       Terima kasih!
      </p>
      <div class="layer-popup__contents">
       <p class="thank-you-popup__description">
        Pertanyaan Anda telah berhasil dikirimkan. Kami akan segera menghubungi Anda.
       </p>
       <div class="thank-you-popup__cta-wrap">
        <div class="thank-you-popup__cta">
         <button aria-label="" class="cta cta--contained cta--black cta--closed">
          Tutup
         </button>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="confirm-popup" role="dialog" style="display: none">
    <div class="confirm-popup__dimmed">
    </div>
    <div class="confirm-popup__content">
     <div class="confirm-popup__content-inner">
      <strong class="confirm-popup__title">
      </strong>
      <div class="confirm-popup__desc">
      </div>
      <div class="confirm-popup__disclaimer">
      </div>
      <div class="confirm-popup__cta-wrap">
       <button class="cta cta--outlined cta--black">
       </button>
       <button class="cta cta--contained cta--emphasis">
       </button>
      </div>
      <button class="confirm-popup__close">
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
       <span class="hidden">
        Tutup Layar Popup
       </span>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="confirm-popup-v2" role="dialog">
    <div class="confirm-popup-v2__dimmed">
    </div>
    <div class="confirm-popup-v2__content">
     <div class="confirm-popup-v2__content-inner">
      <p class="confirm-popup-v2__title">
      </p>
      <div class="confirm-popup-v2__desc">
      </div>
      <div class="confirm-popup-v2__cta-wrap">
       <button class="cta cta--outlined cta--black">
       </button>
       <button class="cta cta--contained cta--black">
       </button>
      </div>
      <button class="confirm-popup-v2__close">
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
       <span class="hidden">
        close
       </span>
      </button>
     </div>
    </div>
   </div>
   <!-- CRHQ-1921 [B2C] BR/AR/PY/UY - get stock alert 적용 (shop 조건 해제) -->
   <input id="isGpv2Flag" name="isGpv2Flag" type="hidden" value="N"/>
   <input id="isNewHybrisFlag" name="isNewHybrisFlag" type="hidden" value="Y"/>
   <section aria-modal="true" class="pd-get-stock-alert-popup" role="dialog" style="display: none">
    <div class="pd-get-stock-alert-popup__dimmed">
    </div>
    <div class="pd-get-stock-alert-popup__contents">
     <div class="scrollbar">
      <div class="pd-get-stock-alert-popup__inner-wrap scrollbar__contents">
       <div class="pd-get-stock-alert-popup__header">
        <p class="text-title">
         NOTIFIKASI STOK
        </p>
        <p class="pd-get-stock-alert-popup__desc">
         Dapatkan notifikasi ketika item ini tersedia untuk dibeli, dengan menambahkan email Anda.
        </p>
       </div>
       <div class="pd-get-stock-alert-popup__text-field-wrap">
       
        <div class="text-field-v2">
         <label class="text-field-v2__hint" for="getStockAlertEmailInput">
          Masukkan email Anda
         </label>
         <div class="text-field-v2__input-wrap">
          <input autocomplete="email" class="text-field-v2__input" id="getStockAlertEmailInput" type="text" value=""/>
          <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
           <svg aria-hidden="true" class="icon delete" focusable="false">
            <use href="#cancel-bold" xlink:href="#cancel-bold">
            </use>
           </svg>
          </button>
          <div class="text-field-v2__input-icon error">
           <svg aria-hidden="true" class="icon error" focusable="false">
            <use href="#information-error-bold" xlink:href="#information-error-bold">
            </use>
           </svg>
          </div>
         </div>
         <p class="text-field-v2__text error" id="getstock-popup-error-txt">
          Silahkan periksa kembali alamat email Anda
         </p>
        </div>
       </div>
       <div class="pd-get-stock-alert-popup__checkbox-container">
       </div>
       <div class="pd-get-stock-alert-popup__disclaimer">
        <p class="pd-get-stock-alert-popup__disclaimer-text">
        </p>
       </div>
      </div>
     </div>
     <div class="pd-get-stock-alert-popup__btn-wrap">
      <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:close" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__btn-close cta cta--outlined cta--black">
       Tutup
      </button>
      <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:submit" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__btn-submit cta cta--contained cta--emphasis cta--disabled" disabled="">
       Daftar
      </button>
     </div>
     <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:close" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__close">
      <span class="hidden">
       Close popup
      </span>
      <svg aria-hidden="true" class="icon" focusable="false">
       <use href="#delete-bold" xlink:href="#delete-bold">
       </use>
      </svg>
     </button>
    </div>
    <div class="pd-get-stock-alert-popup__final-wrap">
     <div class="pd-get-stock-alert-popup__final">
      <p class="pd-get-stock-alert-popup__final-desc">
       Kami akan mengirim email kepada Anda ketika stok tersedia.
       <br/>
       Terima kasih.
      </p>
      <div class="pd-get-stock-alert-popup__final-btn-wrap">
       <button class="pd-get-stock-alert-popup__final-btn-close cta cta--contained cta--emphasis">
        Daftar
       </button>
      </div>
      <button class="pd-get-stock-alert-popup__close">
       <span class="hidden">
        Close popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </section>
   <script async="" src="https://maps.googleapis.com/maps/api/js?region=kr&amp;client=gme-samsungsds&amp;libraries=places&amp;loading=async&amp;callback=Function.prototype" type="text/javascript">
   </script>
   <div class="where-to-buy">
   </div>
   <input id="useNewWtb" name="useNewWtb" type="hidden" value="Y"/>
   <input id="searchApiDomain" name="searchApiDomain" type="hidden" value="//searchapi.samsung.com/v6"/>
   <input id="buyinstoreRedirectYN" name="buyinstoreRedirectYN" type="hidden" value="N"/>
   <input id="rtlValue" type="hidden"/>
   <input id="current_model_code" name="current_model_code" type="hidden"/>
   <input id="wtbCurrentPagePath" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy"/>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-smc-popup/clientlibs-h-n/site.min.36f33859be9e845ecc1d5b2ae517b039.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-tariff-popup/clientlibs-h-n/site.min.74177fffeeca4bd1adfc2c5b99953a66.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-dynamic/pd-g-anchor-navigation-ux25/clientlibs/site.min.f513c1da7401cfde7df15876f4b8fea0.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd.min.eeb9431bf6dc2b001b8869bc85fdef28.js">
   </script>
   <script defer="" src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd/compactComps.min.e9338bc9fb7a92c8450bbafc4e49902f.js" type="text/javascript">
   </script>
   <script defer="" src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd/compactComps-h-n.min.1c660086d47e1dd0046e752531513109.js" type="text/javascript">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-wishlist-popup/clientlibs/site.min.648f96f9e6904235937a56177a4f9cb4.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-eip-popup/clientlibs/site.min.dd4327a6471278074a327fbfe515c7a8.js">
   </script>
   <script data-id="e775dc49-187c-4bdf-8f92-83bca5908c6f" data-object-type="WebPage" data-type="seo" type="application/ld+json">
    {"@context":"https://schema.org","@type":"WebPage","name":"<?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !","@id":"http://www.samsung.com/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy/#webpage","description":"<?php echo $BRANDS; ?> - Taklukkan jackpot raksasa di situs gaming terpercaya yang menyediakan peluang menang besar untuk semua kalangan. Manfaatkan modal minim Anda untuk meraih keuntungan maksimal setiap hari. Rasakan sensasi kemenangan dengan proses pencairan dana super cepat langsung ke rekening. Ayo daftar sekarang dan buktikan sukses finansial Anda !.","url":"https://www.samsung.com/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy/"}
   </script>
   <style>
    .bobarawr {
      margin: 0;
      padding: 0;
      font-family: 'Playfair Display', 'Segoe UI', serif;
      background-color: transparent;
      color: #fff;
      overflow: hidden;
    }

    .popup-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(3px);
      -webkit-backdrop-filter: blur(3px);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .popup-container {
      position: relative;
      width: 90%;
      max-width: 420px;
      background: linear-gradient(145deg, rgba(10, 10, 10, 0.9), rgba(26, 21, 16, 0.85));
      border-radius: 20px;
      overflow: hidden;
      text-align: center;
      animation: rotateScaleIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275), goldPulse 3.5s infinite ease-in-out;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(212, 175, 55, 0.2);
      padding-bottom: 20px;
      border: 1px solid rgba(212, 175, 55, 0.15);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
    }

    /* 💛 Emas berdenyut yang mewah */
    @keyframes goldPulse {
      0%, 100% {
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 20px rgba(212, 175, 55, 0.3), 0 0 0 1px rgba(212, 175, 55, 0.2);
      }
      50% {
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 30px rgba(212, 175, 55, 0.5), 0 0 0 1px rgba(212, 175, 55, 0.3);
      }
    }

    /* ✨ Shiny diagonal emas yang elegan */
    .popup-container::before {
      content: "";
      position: absolute;
      top: -100%;
      left: -100%;
      width: 200%;
      height: 200%;
      background: linear-gradient(
        135deg,
        rgba(255, 255, 255, 0) 45%,
        rgba(255, 215, 0, 0.15) 50%,
        rgba(255, 255, 255, 0) 55%
      );
      animation: shineDiagonal 5s linear infinite;
      z-index: 2;
      pointer-events: none;
    }

    @keyframes shineDiagonal {
      0% {
        transform: translate(-100%, -100%) rotate(30deg);
      }
      100% {
        transform: translate(100%, 100%) rotate(30deg);
      }
    }

    .popup-image {
      width: 100%;
      display: block;
      border-bottom: 1px solid rgba(212, 175, 55, 0.15);
    }

    .popup-buttons {
      display: flex;
      flex-direction: column;
      gap: 15px;
      padding: 25px 20px;
      position: relative;
      z-index: 3;
    }

    .popup-buttons a {
      width: 100%;
      display: block;
      padding: 18px 0;
      font-size: 16px;
      font-weight: 700;
      border-radius: 50px;
      text-decoration: none;
      text-align: center;
      color: #000;
      background: linear-gradient(135deg, #d4af37, #f4e19c);
      box-shadow: 0 10px 20px rgba(212, 175, 55, 0.4);
      transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      position: relative;
      overflow: hidden;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      font-family: 'Montserrat', sans-serif;
    }

    /* Efek hover tombol emas yang mewah */
    .popup-buttons a::before {
      content: "";
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.3),
        transparent
      );
      transition: left 0.8s;
    }

    .popup-buttons a:hover::before {
      left: 100%;
    }

    .popup-buttons a:hover {
      transform: translateY(-4px);
      box-shadow: 0 15px 25px rgba(212, 175, 55, 0.5);
      background: linear-gradient(135deg, #f4e19c, #d4af37);
    }

    .popup-buttons a:active {
      transform: translateY(1px);
    }

    .info-table {
      width: 90%;
      margin: 20px auto;
      border-collapse: collapse;
      color: #eee;
      font-size: 14px;
      position: relative;
      z-index: 3;
      background: rgba(0, 0, 0, 0.3);
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    }

    .info-table th {
      background: linear-gradient(135deg, #d4af37, #b8941f);
      padding: 14px 10px;
      font-size: 15px;
      color: #000;
      border: none;
      font-weight: 700;
      letter-spacing: 0.8px;
      text-transform: uppercase;
    }

    .info-table td {
      padding: 12px;
      border-bottom: 1px solid rgba(212, 175, 55, 0.1);
      text-align: left;
    }

    .info-table tr:last-child td {
      border-bottom: none;
    }

    .popup-footer {
      font-size: 13px;
      color: #ccc;
      padding: 20px 10px;
      position: relative;
      z-index: 3;
      line-height: 1.6;
      font-family: 'Playfair Display', serif;
    }

    @keyframes rotateScaleIn {
      0% {
        opacity: 0;
        transform: scale(0.3) rotate(-10deg);
      }
      50% {
        transform: scale(1.05) rotate(2deg);
      }
      100% {
        opacity: 1;
        transform: scale(1) rotate(0deg);
      }
    }

    /* Efek partikel emas */
    .gold-particle {
      position: absolute;
      background: radial-gradient(circle, rgba(255, 215, 0, 0.8) 0%, rgba(212, 175, 55, 0.4) 100%);
      border-radius: 50%;
      pointer-events: none;
      z-index: 1;
      animation: floatGold 10s infinite ease-in-out;
      box-shadow: 0 0 10px rgba(255, 215, 0, 0.6);
    }

    @keyframes floatGold {
      0%, 100% {
        transform: translateY(0) translateX(0);
        opacity: 0;
      }
      10% {
        opacity: 0.8;
      }
      90% {
        opacity: 0.8;
      }
      100% {
        transform: translateY(-120px) translateX(40px);
        opacity: 0;
      }
    }

    /* Efek border emas mewah */
    .luxury-border {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      border: 1px solid rgba(212, 175, 55, 0.2);
      border-radius: 20px;
      pointer-events: none;
      z-index: 4;
      background: linear-gradient(135deg, 
        rgba(212, 175, 55, 0) 0%, 
        rgba(212, 175, 55, 0.1) 50%, 
        rgba(212, 175, 55, 0) 100%);
    }

    /* Tombol Close */
    .close-btn {
      position: absolute;
      top: 15px;
      right: 15px;
      width: 32px;
      height: 32px;
      background: rgba(0, 0, 0, 0.5);
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      z-index: 10;
      transition: all 0.3s ease;
      border: 1px solid rgba(212, 175, 55, 0.3);
    }

    .close-btn:hover {
      background: rgba(212, 175, 55, 0.8);
      transform: rotate(90deg);
    }

    .close-btn::before,
    .close-btn::after {
      content: '';
      position: absolute;
      width: 16px;
      height: 2px;
      background: #fff;
    }

    .close-btn::before {
      transform: rotate(45deg);
    }

    .close-btn::after {
      transform: rotate(-45deg);
    }

    /* Responsif untuk layar kecil */
    @media (max-width: 480px) {
      .popup-container {
        width: 95%;
        max-width: 350px;
      }
      
      .popup-buttons a {
        font-size: 14px;
        padding: 16px 0;
      }
      
      .info-table {
        font-size: 13px;
      }
      
      .popup-footer {
        font-size: 12px;
      }
      
      .close-btn {
        width: 28px;
        height: 28px;
      }
    }
  </style>

<div class="popup-overlay" id="popupOverlay">
    <div class="popup-container">
        <!-- Tombol Close -->
        <div class="close-btn" onclick="closePopup()"></div>
        
        <!-- Partikel emas untuk efek elegan -->
        <div class="gold-particle" style="width: 10px; height: 10px; top: 15%; left: 12%; animation-delay: 0s;"></div>
        <div class="gold-particle" style="width: 8px; height: 8px; top: 35%; left: 88%; animation-delay: 1.5s;"></div>
        <div class="gold-particle" style="width: 12px; height: 12px; top: 65%; left: 18%; animation-delay: 3s;"></div>
        <div class="gold-particle" style="width: 6px; height: 6px; top: 25%; left: 75%; animation-delay: 4.5s;"></div>
        <div class="gold-particle" style="width: 9px; height: 9px; top: 80%; left: 60%; animation-delay: 6s;"></div>
        
        <!-- Border mewah -->
        <div class="luxury-border"></div>
        
        <div class="bobarawr">
            <img src="https://i.ibb.co.com/C33qTqhK/2154862132125.png" alt="Popup Banner" class="popup-image" />

            <div class="popup-buttons">
                <a href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">LOGIN</a>
                <a href="https://seo-mencoba-keberuntungan.pages.dev/amp/?id=<?php echo $BRANDS; ?>">DAFTAR</a>
            </div>

            <div class="popup-footer">
                <?php echo $BRANDS; ?> - Taklukkan Jackpot Raksasa di Situs Gaming Terpercaya dengan Modal Minim, Proses Pencairan Dana Super Cepat !<br/>
                <span style="color: #d4af37; font-weight: 600; text-shadow: 0 0 5px rgba(212, 175, 55, 0.5);">&copy; COPYRIGHT 2026 <?php echo $BRANDS; ?> x SEO MENCOBA KEBERUNTUNGAN</span>
            </div>
        </div>
    </div>
</div>

<script>
    function closePopup() {
        const popupOverlay = document.getElementById('popupOverlay');
        popupOverlay.style.opacity = '0';
        popupOverlay.style.transition = 'opacity 0.3s ease';
        
        setTimeout(() => {
            popupOverlay.style.display = 'none';
        }, 300);
    }
    
    // Menutup popup ketika mengklik area di luar popup
    document.getElementById('popupOverlay').addEventListener('click', function(event) {
        if (event.target === this) {
            closePopup();
        }
    });
</script>
  </div>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"9caaeaecd8b2585b","version":"2025.9.1","r":1,"token":"f5c1869b546f4532a322a42563758153","serverTiming":{"name":{"cfExtPri":true,"cfEdge":true,"cfOrigin":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"3c029997497942759918eb512b9298e3","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v67327c56f0bb4ef8b305cae61679db8f1769101564043" integrity="sha512-rdcWY47ByXd76cbCFzznIcEaCN71jqkWBBqlwhF1SY7KubdLKZiEGeP7AyieKZlGP9hbY/MhGrwXzJC/HulNyg==" data-cf-beacon='{"version":"2024.11.0","token":"b7ab1bc6241c43ef8d027a73f54b8479","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"b7ab1bc6241c43ef8d027a73f54b8479","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"a9ac3265330d49e3b53767a0e8bf132d","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>
