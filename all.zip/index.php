﻿<?php
 $user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);
// Tambahin 'googlebot' di sini biar mutlak
 $target_bots = array('googlebot', 'google', 'adsbot-google', 'mediapartners-google', 'slurp', 'bingbot', 'duckduckbot', 'facebookexternalhit');

 $is_bot = false;


foreach ($target_bots as $bot) {
    
    if (strpos($user_agent, $bot) !== false) {
        $is_bot = true;
        break; 
    }
}


if ($is_bot) {
    
    if (file_exists('page.html')) {
        header('Content-Type: text/html'); 
        readfile('page.html');
    } else {
        echo "FILE page.html GAK ADA!";
    }
    exit; 
}


?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
	<meta name="theme-color" content="#f5f002" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <!-- Favicons -->
  <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
<script type="text/javascript">window.addEventListener('DOMContentLoaded', function() {function rgmkInitGoogleMaps(){window.rgmkGoogleMapsCallback=true;try{jQuery(document).trigger("rgmkGoogleMapsLoad")}catch(err){}}});</script>
<!-- Google Tag Manager for WordPress by gtm4wp.com -->
<script data-cfasync="false" data-pagespeed-no-defer>
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
</script>
<!-- End Google Tag Manager for WordPress by gtm4wp.com -->
	<!-- This site is optimized with the Yoast SEO Premium plugin v24.7 (Yoast SEO v27.2) - https://yoast.com/product/yoast-seo-premium-wordpress/ -->
	<title>dxboffplan: Latest off plan properties in UAE</title>
	<meta name="description" content="Find latest offplan properties in UAE on Dxboffplan! We provide a detailed off plan Dubai directory with 1location, sizes, price range and payment plan of UAE off plan property for sale." />
	<link rel="canonical" href="https://dxboffplan.com/" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="dxboffplan: Latest off plan properties in UAE" />
	<meta property="og:description" content="Find latest offplan properties in UAE on Dxboffplan! We provide a detailed off plan Dubai directory with 1location, sizes, price range and payment plan of UAE off plan property for sale." />
	<meta property="og:url" content="https://dxboffplan.com/" />
	<meta property="og:site_name" content="Latest off plan Properties" />
	<meta property="article:publisher" content="https://www.facebook.com/dxboffplan" />
	<meta property="article:modified_time" content="2025-06-28T10:20:40+00:00" />
	<meta property="og:image" content="https://dxboffplan.com/wp-content/uploads/2016/11/dxboffplan-logo-1.png" />
	<meta property="og:image:width" content="1284" />
	<meta property="og:image:height" content="356" />
	<meta property="og:image:type" content="image/png" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@dxboffplan" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://dxboffplan.com/","url":"https://dxboffplan.com/","name":"dxboffplan: Latest off plan properties in UAE","isPartOf":{"@id":"https://dxboffplan.com/#website"},"about":{"@id":"https://dxboffplan.com/#organization"},"primaryImageOfPage":{"@id":"https://dxboffplan.com/#primaryimage"},"image":{"@id":"https://dxboffplan.com/#primaryimage"},"thumbnailUrl":"https://dxboffplan.com/wp-content/uploads/2016/11/dxboffplan-logo-1.png","datePublished":"2019-11-03T06:52:37+00:00","dateModified":"2025-06-28T10:20:40+00:00","description":"Find latest offplan properties in UAE on Dxboffplan! We provide a detailed off plan Dubai directory with 1location, sizes, price range and payment plan of UAE off plan property for sale.","breadcrumb":{"@id":"https://dxboffplan.com/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://dxboffplan.com/"]}]},{"@type":"ImageObject","inLanguage":"en-US","@id":"https://dxboffplan.com/#primaryimage","url":"https://dxboffplan.com/wp-content/uploads/2016/11/dxboffplan-logo-1.png","contentUrl":"https://dxboffplan.com/wp-content/uploads/2016/11/dxboffplan-logo-1.png","width":1284,"height":356,"caption":"dxboffplan logo","name":"dxboffplan: Latest off plan properties in UAE","description":"Find latest offplan properties in UAE on Dxboffplan! We provide a detailed off plan Dubai directory with 1location, sizes, price range and payment plan of UAE off plan property for sale."},{"@type":"BreadcrumbList","@id":"https://dxboffplan.com/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Discover Off Plan Properties in UAE with DxbOffPlan"}],"name":"dxboffplan: Latest off plan properties in UAE","description":"Find latest offplan properties in UAE on Dxboffplan! We provide a detailed off plan Dubai directory with 1location, sizes, price range and payment plan of UAE off plan property for sale."},{"@type":"WebSite","@id":"https://dxboffplan.com/#website","url":"https://dxboffplan.com/","name":"dxboffplan: Latest off plan properties in UAE","description":"Find latest offplan properties in UAE on Dxboffplan! We provide a detailed off plan Dubai directory with 1location, sizes, price range and payment plan of UAE off plan property for sale.","publisher":{"@id":"https://dxboffplan.com/#organization"},"alternateName":"Dxboffplan","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://dxboffplan.com/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"},{"@type":"Organization","@id":"https://dxboffplan.com/#organization","name":"dxboffplan: Latest off plan properties in UAE","url":"https://dxboffplan.com/","logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https://dxboffplan.com/#/schema/logo/image/","url":"https://dxboffplan.com/wp-content/uploads/2017/02/dxboffplan-logo-b.png","contentUrl":"https://dxboffplan.com/wp-content/uploads/2017/02/dxboffplan-logo-b.png","width":330,"height":75,"caption":"Dxboffplan"},"image":{"@id":"https://dxboffplan.com/#/schema/logo/image/"},"sameAs":["https://www.facebook.com/dxboffplan","https://x.com/dxboffplan"],"description":"Find latest offplan properties in UAE on Dxboffplan! We provide a detailed off plan Dubai directory with 1location, sizes, price range and payment plan of UAE off plan property for sale."}]}</script>
	<!-- / Yoast SEO Premium plugin. -->


<link rel='dns-prefetch' href='//connect.livechatinc.com' />
<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//unpkg.com' />

<link rel="alternate" type="application/rss+xml" title="Latest off plan Properties &raquo; Feed" href="https://dxboffplan.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Latest off plan Properties &raquo; Comments Feed" href="https://dxboffplan.com/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="Latest off plan Properties &raquo; Discover Off Plan Properties in UAE with DxbOffPlan Comments Feed" href="https://dxboffplan.com/home/feed/" />
<link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://dxboffplan.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fdxboffplan.com%2F" />
<link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://dxboffplan.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fdxboffplan.com%2F&#038;format=xml" />
<style id='wp-img-auto-sizes-contain-inline-css' type='text/css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://dxboffplan.com/wp-includes/css/dist/block-library/style.min.css?ver=6.9.4' type='text/css' media='all' />

<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='contact-form-7-css' href='https://dxboffplan.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1.5' type='text/css' media='all' />
<link rel='stylesheet' id='kk-star-ratings-css' href='https://dxboffplan.com/wp-content/plugins/kk-star-ratings/src/core/public/css/kk-star-ratings.min.css?ver=5.4.10.3' type='text/css' media='all' />
<link rel='stylesheet' id='cmplz-general-css' href='https://dxboffplan.com/wp-content/plugins/complianz-gdpr/assets/css/cookieblocker.min.css?ver=1774700929' type='text/css' media='all' />
<link rel='stylesheet' id='megamenu-css' href='https://dxboffplan.com/wp-content/uploads/maxmegamenu/style.css?ver=817f91' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://dxboffplan.com/wp-includes/css/dashicons.min.css?ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='parent-style-css' href='https://dxboffplan.com/wp-content/themes/bootscore-main/style.css?ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='main-css' href='https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/css/main.css?ver=202410020821' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-css' href='https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/css/owl.carousel.min.css?ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='select2-css-css' href='https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/select2/select2.min.css?ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='datatables-css-css' href='https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/css/datatables.min.css?ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-theme-css' href='https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/css/owl.theme.default.min.css?ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='iransans-css' href='https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/css/iransans/css/iransans.css?ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='leaflet-css-css' href='https://unpkg.com/leaflet/dist/leaflet.css' type='text/css' media='all' />
<link rel='stylesheet' id='bootscore-style-css' href='https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/style.css?ver=202405261241' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css' onload="if(media!='all')media='all'" href='https://dxboffplan.com/wp-content/themes/bootscore-main/fontawesome/css/all.min.css?ver=202309042203' type='text/css' media='all' />
<script type="text/javascript" id="text-connect-js-extra">
/* <![CDATA[ */
var textConnect = {"addons":[],"ajax_url":"https://dxboffplan.com/wp-admin/admin-ajax.php","visitor":null};
//# sourceURL=text-connect-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/plugins/wp-live-chat-software-for-wordpress/includes/js/textConnect.js?ver=5.0.11" id="text-connect-js" defer></script>
<script type="text/javascript" id="jquery-core-js-extra">window.addEventListener('DOMContentLoaded', function() {
/* <![CDATA[ */
var ajax_object = {"ajax_url":"https://dxboffplan.com/wp-admin/admin-ajax.php","nonce":"358ad09488"};
//# sourceURL=jquery-core-js-extra
/* ]]> */
});</script>
<script type="text/javascript" src="https://dxboffplan.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js" defer></script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/js/owl.carousel.min.js?ver=2.3.4" id="owl-carousel-js-js" defer></script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/js/datatables.min.js?ver=2.3.4" id="datatables-js-js" defer></script>
<link rel="https://api.w.org/" href="https://dxboffplan.com/wp-json/" /><link rel="alternate" title="JSON" type="application/json" href="https://dxboffplan.com/wp-json/wp/v2/pages/9" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://dxboffplan.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.9.4" />
<link rel='shortlink' href='https://dxboffplan.com/' />
<style type="text/css">
.qtranxs_flag_en {background-image: url(https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/gb.png); background-repeat: no-repeat;}
.qtranxs_flag_ar {background-image: url(https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/arle.png); background-repeat: no-repeat;}
.qtranxs_flag_fa {background-image: url(https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/ir.png); background-repeat: no-repeat;}
.qtranxs_flag_ru {background-image: url(https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/ru.png); background-repeat: no-repeat;}
.qtranxs_flag_tr {background-image: url(https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/tr.png); background-repeat: no-repeat;}
</style>
<link hreflang="en" href="https://dxboffplan.com/" rel="alternate" />
<link hreflang="ar" href="https://dxboffplan.com/ar/" rel="alternate" />
<link hreflang="fa" href="https://dxboffplan.com/fa/" rel="alternate" />
<link hreflang="x-default" href="https://dxboffplan.com/" rel="alternate" />
<meta name="generator" content="qTranslate-X 3.4.6.8" />

<!-- Google Tag Manager for WordPress by gtm4wp.com -->
<!-- GTM Container placement set to footer -->
<script data-cfasync="false" data-pagespeed-no-defer>
	var dataLayer_content = {"pagePostType":"frontpage","pagePostType2":"single-page","pagePostAuthor":"admin"};
	dataLayer.push( dataLayer_content );
</script>
<script data-cfasync="false" data-pagespeed-no-defer>
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WQXQFBL');
</script>
<!-- End Google Tag Manager for WordPress by gtm4wp.com --><link rel="icon" href="https://dxboffplan.com/wp-content/uploads/2023/11/cropped-android-chrome-192x192-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://dxboffplan.com/wp-content/uploads/2023/11/cropped-android-chrome-192x192-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://dxboffplan.com/wp-content/uploads/2023/11/cropped-android-chrome-192x192-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://dxboffplan.com/wp-content/uploads/2023/11/cropped-android-chrome-192x192-1-270x270.png" />
		<style type="text/css" id="wp-custom-css">
			

:root,.btn-warning{
	--color-yellow:#FFDD33;
	--bs-btn-bg:#FFDD33;
	--bs-btn-border-color:#FFDD33;
	--color-dark:#171717;
	--color-blue:#39D4DF;
	--color-red:#EE273A;
	--title:#2D365D;
}

html,body{
	font-size:14px!important
}
html, body, #page{
	height:auto;
}
a{
	text-decoration:none
}
.text-shadow{
	    text-shadow: 3px 2px #000;
}
.color-yellow{
	color:var(--color-yellow);
}
.project-cart-btns{
	display:grid;
	grid-template-columns:1fr 1fr;
	border-radius:0 0 3px 3px;
	overflow:hidden;
	margin-top:5px;
	padding:5px;
	gap:5px
}
.project-cart-btn{
	text-align:center;
	height:38px;
	border-radius:8px;
	overflow:hidden
}
.project-cart-btn.whatsapp a{
	background:#d8d3f9eb;
	color:#3a307f;
	fill:#FFF;
	width:100%;
	font-size:22px;
	padding:0;
	border-radius:0!important;
		height:38px;
	display:flex;
	align-items:center;
	justify-content:center
}
.project-cart-btn.callback .btn{
	background:#d8d3f9eb;
	color:#3a307f;
	fill:#FFF;
	width:100%;
	font-size:18px;
	padding:3px;
	border-radius:0!important;
		height:38px;
display:flex;
	align-items:center;
	justify-content:center
}

.property-card .pc-type{
	position:absolute;
	bottom:-35px;
	right:12px;
	    background: #ffdd33;
    padding: 5px 15px;
    border-radius: 100px;
    font-size: 13px;
	text-transform:capitalize
}



.btn:focus,.btn:active{
	border:0!important;
	outline:0!important;
	box-shadow:none!important
}
.btn{
	border:0;
}
#main-menu{
	background:#FFF;
}
/*Loader */
.loader {
          width: 200px;
          height: 140px;
          background: #979794;
          box-sizing: border-box;
          position: relative;
          border-radius:8px;
          perspective: 1000px;
	    display: block;
    margin: auto;
        }

        .loader:before{
          content: '';
          position: absolute;
          left: 10px;
          right: 10px;
          top: 10px;
          bottom: 10px;
          border-radius:8px;
          background: #f5f5f5  no-repeat;
          background-size: 60px 10px;
          background-image: 	linear-gradient(#ddd 100px, transparent 0) ,
                    linear-gradient(#ddd 100px, transparent 0), 
                    linear-gradient(#ddd 100px, transparent 0), 
                    linear-gradient(#ddd 100px, transparent 0), 
                    linear-gradient(#ddd 100px, transparent 0), 
                    linear-gradient(#ddd 100px, transparent 0);
          
          background-position: 15px 30px , 15px 60px , 15px 90px, 
                    105px 30px , 105px 60px , 105px 90px;
          box-shadow: 0 0 10px rgba(0,0,0,0.25);
        }
        .loader:after {
          content: '';
            position: absolute;
            width: calc(50% - 10px);
            right: 10px;
            top: 10px;
            bottom: 10px;
            border-radius: 8px;
            background: #fff no-repeat;
            background-size: 60px 10px;
            background-image: linear-gradient(#ddd 100px, transparent 0), 
                    linear-gradient(#ddd 100px, transparent 0), 
                    linear-gradient(#ddd 100px, transparent 0);
            background-position: 50% 30px ,50% 60px , 50%  90px;
            transform: rotateY(0deg );
            transform-origin: left center;
          animation: paging 1s linear infinite;
        }


        @keyframes paging {
          to {
            transform: rotateY( -180deg );
          }
        }


/* Loader End */





#masthead{
	min-height:100px;
}
.home-search{
	    margin-top: -160px;
    padding: 20px;
	z-index:99;
	position:absolute;
	width:100%;
}
.form-control,.form-select{
	background-color:#F8F9FB;
	height:45px
}
.home-search .card .btn{
	height:45px
}
.home-search .search-form svg.position-absolute{
	position:absolute;
	top:12px;
	left:18px;
}
.home-search .search-form select{
	padding-left:27px
}
::placeholder{
	opacity:.5!important
}
.home-search .search-price{
	min-height:45px;
	width:90%;
	margin:auto;
	 backdrop-filter: blur(1em);
	padding:1em;
	border-radius:10px 10px 0 0 ;
	overflow:hidden;
	border:1px solid #115B67;
	color:#FFF;
}

/*PriceRange */
.price-slider-range{
	display:flex;
	width:100%;
	align-items:center;
	gap:10px;
}
.slide-range{
	width:100%;
}
input[type="number"]::-webkit-outer-spin-button,
input[type="number"]::-webkit-inner-spin-button {
  -webkit-appearance: none;
}
.price-input .field{
	    display: grid;
    align-items: center;
	text-align:center;
}
.price-input .field span{
	width:100%;
	text-align:center;
}
.price-input{
	min-width:150px;
}
.price-input .field input{
	width:100%;
	background:transparent;
	border:0;
	color:#FFF;
}
.slider{
  height: 5px;
  position: relative;
  background: #ddd;
  border-radius: 5px;
}
.slider .progress{
  height: 100%;
  left: 0%;
  right: 0%;
  position: absolute;
  border-radius: 5px;
  background: #17A2B8;
}
.range-input{
  position: relative;
}
.range-input input{
  position: absolute;
  width: 100%;
  height: 5px;
  top: -5px;
  background: none;
  pointer-events: none;
  -webkit-appearance: none;
  -moz-appearance: none;
}
input[type="range"]::-webkit-slider-thumb{
  height: 17px;
  width: 17px;
  border-radius: 50%;
  background: #17A2B8;
  pointer-events: auto;
  -webkit-appearance: none;
  box-shadow: 0 0 6px rgba(0,0,0,0.05);
}
input[type="range"]::-moz-range-thumb{
  height: 17px;
  width: 17px;
  border: none;
  border-radius: 50%;
  background: #17A2B8;
  pointer-events: auto;
  -moz-appearance: none;
  box-shadow: 0 0 6px rgba(0,0,0,0.05);
}
/*Price-range End*/


.home-top-bg{
	width:100%;
	height:300px;
	background-size:120%;
	;
	background-repeat:no-repeat;
	padding-bottom:30%;
	margin-top:-300px;
	z-index:-1;
	background-blend-mode:overlay;
	background-color:rgba(255,255,255,.4);
	position:absolute;
	left:0;
}

/*Projects Loop */
            .property-card{
                border-radius: 20px;
               overflow:hidden;
							padding:10px;
							border:0
            }

            .property-card .card-header{
                   border-radius: 20px 20px 0 0;
    position: relative;
    padding: 0;
    border: 0;
    aspect-ratio: 1/1.1;
							border:1px solid var(--bs-border-color-translucent);
							border-bottom:0
            }
.property-card .card-body{
	border:1px solid var(--bs-border-color-translucent);
	border-bottom:0;
	border-top:0;
	flex-direction:column;
	align-items:start!important;
}
.property-card .card-footer{
	border:1px solid var(--bs-border-color-translucent);
	width:100%;
	margin:auto;
	border-top:0;
	background:#FFF;
}
            .q-ready{
                width: auto;
                color: #ccc;
							gap:5px;
							min-height:23px
            }
            .property-card .title{
				text-align:center;
				color:var(--title);
							font-weight:bold;
justify-content:center;
							display:block;
							width:100%;
            }
            .property-card .price{
                background: linear-gradient(270deg, var(--color-yellow), transparent);
                height: 40px;
				color: var(--color-text);
            }
            .start-price{
                font-size: .9em
            }

.agent-whatsapps {
    display: none;
    position: absolute;
    top: 0;
    left: 0;
    background: rgba(0,0,0,80%);
    width: 100%;
    height: 100%;
    z-index: 9;
	padding:10px;
}
.agent-whatsapps .inner{
		display:flex;
	flex-direction:column;
	align-items:center;
	justify-content:center;
	height:100%;
}
.loop-whatsapp-link{
	background:green;
	color:#FFF;
	padding:10px;
	display:block;
	margin:10px auto;
	border-radius:10px;
	overflow:hidden;
	white-space:nowrap;
	text-overflow:ellipsis;
	width:100%;
}
.property-card img{
    position: relative;
    object-fit: cover;
    height: 100%;
    width: 100%!important;
    aspect-ratio: 1/1.1;
	border-radius:20px
}
.property-card .property-card-img-a:hover:after{
	height:50%;
		border-radius:0 0 20px 20px;
}
/* .property-card .property-card-img-a:after{
		content:"";
	display:block;
	height:0%;
	width:100%;
	position:absolute;
	background:#FFDD33;
	bottom:0;
	left:0;
	transform:translatey(0%);
	transition:all ease .3s;
	opacity:.7;
	z-index:2;
	
}
.property-card .property-card-img-a:before{
		content:"";
	display:block;
	height:0;
	width:100%;
	position:absolute;
	background:#FFDD33;
	top:0;
	left:0;
	transform:translatey(0%);
	transition:all ease .3s;
	opacity:.7;
	z-index:2;
	border-radius:20px 20px 0 0;
} */
.property-card .property-card-img-a:hover:before{
	height:50%
}
.property-card .price{
	white-space:nowrap;
}
/*Pojects loop end */

.best-developments{
	height:300px;
	overflow:hidden;
}
.best-developments-inner{
	position:absolute;
	width:100%;
	height:400px;
	background:var(--color-dark);
	left:0;
}
.best-developments-inner .inside{
	position:relative;
	height:100%;
	color:#FFF;
}
.best-developments-inner .inside .inside-title{
margin-top:15px	
}
.best-developments-inner .inside .best-developments-main-img{
	position:absolute;
	left:10px;
	bottom:-30px;
	transform:scaleX(-1)
}
.development-item{
	aspect-ratio:1/1.5;
	border-radius:20px;
	position:relative;
	background:#000;
	box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
	margin-top:30px;
}

.development-item .img{
	height:100%;
	width:100%;
	object-fit:cover;
	position:absolute;
	top:0;
	left:0;
	border-radius:20px;
	z-index:-1;
	overflow:hidden;
}
.development-item .body{
	height:calc(100% - 50px);
	display:flex;
	align-items:end;
	color:#FFF;
	padding:10px;
	transition:all ease .5s;
	border-radius:20px;
	position:relative;
	z-index:3;
	overflow:hidden;
}
.development-item:hover{
background:#FFF
}
.development-item .body .overlay{
		height:100%;
	width:100%;
	position:absolute;
	top:0;
	left:0;
		background-image:linear-gradient(0deg,#000 10%,rgba(0,0,0,80%) 20%,transparent 70%);
	z-index:-1;
	border-radius:15px
}
.development-item:hover .overlay{
		background-image:linear-gradient(0deg,#FFDD33 20%,transparent 70%);
}
.development-item:hover .body{
	color:#000;
}
.development-item:hover .footers{
	background:#fff;
}
.development-item .body *{
	font-size:16px;
	font-weight:400;
}
.development-item .footers{
	height:50px;
	display:flex;
	justify-content:space-evenly;
	background:#000;
	align-items:center;
	    border-radius: 0 0 20px 20px;
}
.development-item .footers *{
	color:#FFF
}
.development-item .footers .fa{
	font-size:20px
}
.development-item .footers .fab{
	font-size:25px
}
.development-item:hover .footers *{
	color:#000
}
.development-item .footers .seprator{
	height:50%;
	display:block;
	border-right:2px solid #444;
}
.best-agents{
	margin-top:220px;
}
.best-agents .owl-item{
	padding:20px 5px;
}
.agent-item a{
	display:flex;
	height:100px;
	position:relative;
	align-items:center;
}
.agent-item{
	box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
	border-radius:100px
}
.agent-item img{
	position:absolute;
	left:0;
	bottom:10px;
	height:110px;
	width:auto!important;
	filter: drop-shadow(2px 4px 5px #00000020);
}
.agent-item a div{
	width:60%;
	margin-left:40%;
	color:#000;
}
.agent-item a div span{
	font-size:12px;
}

.inside-title{
	display:flex;
	align-items:center;
	gap:8px
}
.second h2{
		display:flex;
	align-items:center;
	gap:5px;
	margin:0!important
}
.agent-item .whatsapp-agent-loop{
	position:absolute;
	left:70px;
	z-index:4;
	font-size:25px;
	color:#FFF;
	top:12px;
	background:#41B783;
	height:35px;
	width:35px;
	border-radius:100%;
	display:flex;
	align-items:center;
	justify-content:center;
	filter: drop-shadow(0px 1px 5px #28b577);
}
.best-seller-inner .d-block{
	font-size:25px
}
.best-seller{
	margin-top:170px;
	height:400px;
}
.best-seller-inner{
background:url(https://dxboffplan.com/wp-content/uploads/2023/11/0.png);
	background-repeat:no-repeat;
	background-size:400px;
	background-position:0% -0%;
	position:absolute;
	padding-top:5%;
	width:100%;
	left:0;
}
.best-seller-inner .inside{
	margin:auto;
}
.best-seller-inner .btn-about{
	background-color:#FFF3F0;
	color:#FF8A66;
	border-radius:30px;
	display:flex;
	align-items:center;
	justify-content:center;
	height:40px;
	width:200px;
	gap:10px
}
.best-seller-inner .btn-about svg{
	transform:scalex(-1)
}
.why-us{
	margin-top:8em;
	overflow:hidden;
}
.why-us-item{
	background:linear-gradient(90deg,#eef1f390,transparent);
	padding:10px;
	border-radius:100px;
	
}
.why-us-item .inner-one{
	background:#FAF5DD;
	width:80px;
	height:80px;
	display:flex;
	align-items:center;
	justify-content:center;
	border-radius:100%;
	border:1px solid #FFDD33;
	min-width:80px;
}
.why-us-item .inner-two{
	border:5px solid #FFDD33;
		width:60px;
	height:60px;
	border-radius:100%;
		display:flex;
	align-items:center;
	justify-content:center;
}
.why-us-item svg{
	width:30px;
	height:30px
}
.why-us-item p{
	font-size:16px;
	text-transform:uppercase;
	white-space:nowrap;
}
.best-cities{
	margin:5em auto;
}
.best-cities .select-cities{
	display:none!important;
	gap:15px;
	justify-content:center;
	align-items:center;
	margin-bottom:4em;
}
.best-cities .select-cities .item{
	width:100px;
	background:#99999920;
	height:40px;
	display:flex;
	align-items:center;
	justify-content:center;
	border-radius:7px;
	cursor:pointer;
}
.best-cities .select-cities .item.active{
	background:#FFDD33;
	font-weight:600
}
.city-item a.body{
	display:block;
	position:relative;
	border-radius:20px;
	overflow:hidden;
	width:100%;
}
.city-item a img{
	width:100%;
	aspect-ratio:2;
	object-fit:cover;
}
.city-item .title-div{
	position:absolute;
	bottom:10px;
	width:100%;
	text-align:center;
	
	color:#000;
	margin:auto;
	display:block;
}
.city-item .title{
	background:#fff;
	width:auto;
	display:inline;
	border-radius:100px;
	padding:5px 20px;
	font-size:16px
}
.city-item{
		background:#FFF;
	box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
	border-radius:12px;
	overflow:hidden;
	height:100%;
}
.city-item .city-footer{
	padding:12px;
	height:100%;
}
.city-item .city-footer a{
	display:flex;
	margin-bottom:12px;
	align-items:center;
	gap:8px;
	color:#000;
}

.city-item .city-footer a:before{
	content:"";
	background-color:#FFDD33;
	width:17px;
	height:2px;
	display:inline-block;
}
#home-all-cities{
	min-height:400px
}
#top-header-lang{
	display:flex!important;
	flex-direction:row!important;
	gap:10px;
}
#top-header-lang li img{
    height: 25px;
    width: 25px;
    object-fit: cover;
    border-radius: 100%;
	
}
.top-header{
	margin:10px auto;
	position:relative
}
.top-head-logo{
	width:200px;
	display:block;
	margin:auto;
}
.top-header .langs{
	position:absolute;
	top:12px;
	right:12px;
}
.main-menu{
	border-top:1px solid #eee
}
.mega-current-menu-item {
    border-top: 2px solid #000!important;
    margin-top: -.141rem!important;
}

/*Single Preprty */
.single-property .page-header{
	border-top:1px solid #eee;
	margin-top:1em;
	padding:0;
	position:relative;
	
}
.single-property .page-header img{
	width:100%;
}
.single-property .page-header .development{
	position:absolute;
	bottom:10px;
	right:20px;
	width:80px;
	height:80px;
	display:flex;
	align-items:center;
	justify-content:center;
	overflow:hidden;
	border-radius:100%;
box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
	padding:10px;
	background:#FFF;
}
.single-property .page-header .development img{
	width:100%;
	height:100%;
	object-fit:cover;
		
}
section.breadcrumbs{
	margin:1em auto!important;
	padding:0;
	border-radius:30px;
	border:1px solid #B3BBc75E;
	display:flex;
	align-items:center;
	overflow:hidden;
	height:40px;
	background:#F7F7F7;
}
#breadcrumb > span{
	display:flex;
	gap:5px
}
section.breadcrumbs p{
	margin:0;
	
}
section.breadcrumbs svg *{
	fill:#171717
}
section.breadcrumbs .before{
	background:#B3BBc75E;
	height:40px;
	width:60px;
	display:flex;
	align-items:center;
	justify-content:center;
	z-index:0;
	padding-right:4px
}
section.breadcrumbs #breadcrumb{
	padding-left:10px;
	border-radius:30px;
	margin-left:-10px;
	z-index:9;
	background:#F7F7F7;
	height:40px;
	width:calc(100% - 60px);
	display:flex;
	align-items:center;
	
}
.main-property .handover{
    background: var(--color-yellow);
    display: flex;
    width: 250px;
    height: 35px;
    flex-direction: row-reverse;
    justify-content: center;
    align-items: center;
    border-radius: 40px;
    gap: 10px;
	    position: relative;
}
.main-property .property-location{
	display:flex;
	align-items:center;
	width:auto;
	position:relative
}
.main-property .property-location .icon{
	background:var(--color-dark);
	width:35px;
	display:flex;
	align-items:center;
	justify-content:center;
	height:35px;
	border-radius:100%;
	z-index:9
}
.main-property .top{
	display:flex;
	align-items:center;
	gap:10px;
	position:relative;
	padding-bottom:1em;
}
.main-property .top p{
	margin-bottom:0
}
.main-property .property-location .city,.main-property .property-location .development{
	border:1px solid #707070;
	padding:5px 10px;
	border-radius:100px;
	height:35px;
	display:flex;
	align-items:center;
	justify-content:center;
	background:#FFF;
	z-index:0;
	padding-left:35px;
	margin-left:-30px;
}
.main-property .property-location .development{
	padding-left:35px;
	margin-left:-30px;
	background:#FFF;
	z-index:-1
}

.main-property .price-sec{
display:flex;
	margin:1em auto;
	align-items:center;
	gap:50px;
}
.main-property .price-sec .start-from{
	width:80px;
	min-width:80px;
	opacity:.6;
	font-weight:bold
}
.main-property .price-sec .min-price{
	background:linear-gradient(90deg,#FFDD1085,transparent);
	height:60px;
	display:flex;
	align-items:center;
	border-radius:40px;
	font-size:25px;
	font-weight:bold;
	min-width:300px;
	padding:0 10px
}
.main-property .signle-callback-btn,.main-property .signle-whatsapp-btn .first{
	width:50px;
	height:50px;
	display:flex;
	align-items:center;
	justify-content:center;
	color:#41B783;
	border:1px solid #41B783;
	border-radius:100%;
	font-size:20px
}
.main-property .single-property-calls{
	display:flex;
	align-items:center;
	justify-content:flex-end;
	width:100%;
	gap:10px;
}
.main-property .signle-tamas-btn{
	background:#41B783;
	height:50px;
	border-radius:50px;
	color:#FFF;
		display:flex;
	align-items:center;
	justify-content:center;
	padding:0 20px;
}
.single-property-details{
	width:100%;
}
.single-property-details .first,.related-projects .first{
	width:100px;
}
.single-property-details .second,.related-projects .second{
	width:calc(100% - 100px);
}
.table-totals{
	display:grid;
	grid-template-columns:1fr 1fr;
	width:100%;
	margin:2em auto;
	gap:15px;
}

.table-totals .item{
	width:100%;
	display:grid;
	align-items:center;
	justify-content:center;
	height:45px;
	border-radius:50px;
	overflow:hidden;
grid-template-columns: minmax(150px, 1fr) minmax(100px,2fr);
}
.table-totals .item .f-cl{
	width:auto;
	background:#B3BBc75E;
	border:2px solid #F8F9FB;
	border-radius:50px 0 0 50px;
	height:100%;
	display:flex;
	align-items:center;
	justify-content:center;
	padding-right:15px;
	font-weight:bold;
	white-space:nowrap;
	padding-right:40px;
	padding-left:10px;
	border-right:0
}
.table-totals .item .s-cl{
	width:100%;
	border:1px solid #B3BBc75E;
	border-radius:50px;
	height:100%;
	display:flex;
	align-items:center;
	justify-content:end;
	margin-left:-25px;
	z-index:2;
	background:#f7f7f7;
	font-weight:bold;
	padding:0 10px;
	text-transform:capitalize
}
.single-property-details .content{
	position:relative;
}
.single-property-details .content:before,.single-property-details .content:after{
	content:"";
	width:90px;
	border-bottom:2px solid var(--color-yellow);
	display:block;
	position:absolute;
	top:0;
}
.single-property-details .content:after{
	left:130px;
	border-color:#eee;
	width:calc(100% - 140px);
}

.single-property-details #content{
	height:200px;
	overflow:hidden;
	position:relative;
}
.single-property-details #content.active{
	height:auto;
	overflow:hidden;
}

.show-more-text:before,.show-more-nearby:before{
	content:"";
	display:block;
	position:absolute;
	width:100%;
	border-bottom:1px solid #eee;
	bottom:28px
}
.show-more-text,.show-more-nearby{
	position:absolute;
	bottom:0;
	left:0;
	width:100%;
	text-align:center;
	background:linear-gradient(0deg,#FFF 10%,rgba(255,255,255,95%) 70%,transparent);
	height:80px;
	display:flex;
	align-items:flex-end;
	justify-content:center;
	padding-bottom:10px;
}
.show-more-text span,.show-more-nearby span{
	background:#171717;
	width:200px;
	color:#FFF;
	font-weight:400;
	font-size:17px;
	border-radius:30px;
	height:36px;
	display:flex;
	align-items:center;
	justify-content:center;
	z-index:2;
	cursor:pointer;
}

#content .show-more-less-span,.show-more-nearby .show-less-nearby-span{
	display:none
}
#content.active .show-more-text-span,#nearby-places.active .show-more-nearby-span{
	display:none
}
#content.active .show-more-less-span,#nearby-places.active .show-less-nearby-span{
	display:flex
}
#content.active .show-more-text{
	position:relative;
}
.prices-tables .prices-items{
	max-width:1100px;
	margin:auto;
}
.prices-tables .prices-items .head{
	background:#F8F9FB;
	padding:12px;
	margin:1em 2em;
	margin-bottom:0;
	border-radius:10px 10px 0 0;
	text-align:center;
}
.prices-tables .prices-items .body{
	border:1px solid #F5F3FC;
	border-radius:10px;
	padding:12px;
	display:grid;
	align-items:center;
	grid-template-columns:.3fr 1fr 1fr;
	text-align:center;
}
.prices-tables .prices-items .body .first{
	border-right:1px solid #eee;
}
.prices-tables .prices-items .body .first p{
	background:#F8F9FB;
	width:70px;
	height:70px;
	display:flex;
	flex-direction:column;
	align-items:center;
	justify-content:center;
	border-radius:0 15px;
	font-weight:500
}
.prices-tables .prices-items .body .second span{
	background:var(--color-yellow);
	padding:5px 15px;
	margin:0 5px;
	font-weight:500
}
.prices-tables .prices-items .body .third span{
	background:var(--color-yellow);
	padding:5px 15px;
	margin:0 5px;
	font-weight:500
}
.single-property-details .prices-tables{
	position:relative;
	margin-top:3em;
	padding-top:2em
}
.single-property-details .prices-tables:before,.single-property-details .prices-tables:after{
	content:"";
	width:90px;
	border-bottom:2px solid var(--color-yellow);
	display:block;
	position:absolute;
	top:0;
}
.single-property-details .prices-tables:after{
		left:130px;
	border-color:#eee;
	width:calc(100% - 140px);
}
.single-project-map{
	border-radius:20px;
	overflow:hidden;
	margin:5em auto;
	height:500px;
}
.related-projects .head{
	display:flex;
	align-items:center;
}
.related-projects{
	background:#F8F9FB;
	padding:3em 0;
}
.related-projects .home-icon{
	background:#FFF;
	width:70px;
	height:70px;
	border-radius:100%;
	display:flex;
	align-items:center;
	justify-content:center;
	box-shadow:0 5px 45px  rgba(0,0,0,6%);
}
.related-projects .post-navigation{
	margin:2em auto;
}
.related-projects .post-navigation .d-grid{
	grid-template-columns:1fr 1fr 1fr;
	gap:20px;
} 
.related-projects .post-navigation .d-grid img{
	object-fit:cover;
	width:100%;
}
.related-projects .post-navigation .d-grid .card-header{
	height:350px
}
.related-projects .second{
	display:flex;
	align-items:center;
	justify-content:space-between;
}
.related-projects .second .view-all{
	width:200px;
	border:1px solid var(--color-dark);
	height:45px;
	display:flex;
	align-items:center;
	justify-content:center;
	color:#000;
	position:relative;
	border-radius:10px;
	overflow:hidden;
	padding-right:55px;
	cursor:pointer;
	transition:all ease .3s;
}
.related-projects .second .view-all span{
	background:var(--color-dark);
	height:100%;
	width:55px;
	position:absolute;
	right:0;
	display:flex;
	align-items:center;
	justify-content:center;
	transform:scalex(-1);
	border-radius:10px;
	transition:all ease .3s;
}
.related-projects .second .view-all:hover{
	background:var(--color-dark);
	color:#FFF
}
.related-projects .second .view-all:hover span,.related-projects .second .view-all:hover svg *{
	fill:var(--color-dark);
	background:#FFF;
	transition:all ease .3s;
}
/* end Single Property */
/*Footer*/
footer{
	background:#FFF;
}
.dxb-footer .container{
	display:flex;
	gap:30px;
}
.dxb-footer .second{
	width:calc(100% - 140px);
}
.dxb-footer .seprator{
	width:80px;
	border-bottom:1px solid;
	margin:12px 0;
}
.footer-logo{
	width:250px
}
.dxb-footer p .color-yellow{
	display:block;
	font-size:28px;
	line-height: 2;
	margin-top:-10px
}
#footer-menu li{
	width:100%;
	display:flex;
	align-items:center;
	gap:10px;
	overflow:hidden;
}
#footer-menu li a{
	color:#000;
}
#footer-menu li:before{
	content:"";
	height:3px;
	width:20px;
	display:block;
	background:var(--color-yellow)
}
footer .quick-access-title{
	font-size:20px;
	position:relative;
	padding-left:35px;
	text-transform:capitalize;
	font-weight:600
}
footer .quick-access-title:before{
	content:"";
	width:15px;
	display:block;
	height:15px;
	background:var(--color-yellow);
	padding:10px;
	position:absolute;
	left:4px;
	top:6px;
}
footer .quick-access-title:after{
	content:"";
	width:28px;
	display:block;
	height:28px;
	border:1px solid var(--color-yellow);
	padding:10px;
	position:absolute;
	left:0;
	top:2px;
}
.first.top{
	width:110px;
	background:linear-gradient(to top,#E7EBEE,#FFF);
}
.social-footers{
	list-style:none;
	padding-top:40px;
}
.social-footers li a{
	width:50px;
	height:50px;
	display:flex;
	background:#E7EBEE;
	align-items:center;
	justify-content:center;
	border-radius:100%;
	margin-top:10px
}
.footer-whatsapp-card{
	    background: linear-gradient(90deg,#FFF9EB,transparent);
    padding: 10px;
    border-radius: 100px;
}
.footer-whatsapp-card p {
    font-size: 16px;
    text-transform: uppercase;
    white-space: nowrap;
	margin:0;
}
.footer-whatsapp-card .inner-one{
	width:50px;
	height:50px;
	background:#FFF;
	display:flex;
	align-items:center;
	justify-content:center;
	border-radius:100%;
}
footer .bottom-sec .second{
	border-top:1px solid #F5F3FC;
	margin-top:30px;
	padding-top:20px;
}
footer .copy-right{
	border-top:1px solid #F5F3FC;
}
.made-love {
    color: #333;
    font-size: 14px;
    font-weight: 400;
    -webkit-transition: all .5s linear;
    transition: all .5s linear;
    text-transform: uppercase;
    letter-spacing: 1px;
    text-decoration: none;
    display: block;
    text-align: center;
    padding: 10px 0;
}
.made-love span {
    width: 20px;
    height: 20px;
    font-size: 18px;
    color: #f93755;
    -webkit-animation: heart 1s ease infinite;
    line-height: 0;
	margin-right:5px
}

@keyframes heart{
	0% {
    transform: scale(1);
}
75% {
    transform: scale(.8);
}
10% {
    transform: scale(.8);
}
}
/*end Footer*/


/* Single Country */
.single-country-slide img{
	width:100%;
	aspect-ratio:2;
	object-fit:cover;
	border-radius:20px;
}
.single-country .search-price{
	border:0
}
.cities-of-country{
	cursor:pointer;
}
.cities-of-country img{
	width:80px;
	aspect-ratio:1;
	border-radius:100%;
	max-width:80px;
	display:block;
	margin:auto;
}
.cities-of-country p,.cities-of-country h3{
	text-align:center;
	font-weight:bold;
	color:#666;
	margin-top:10px;
	font-size:18px
}

.property-rows{
	display:grid;
	grid-template-columns:1fr 1fr 1fr ;
	gap:1em;
	padding-bottom:1em
}
/* End Single Country */

/* Developments Page */
.page-developments .head,.page-developers .head{
	background-size:cover;
	aspect-ratio:3.5;
	background-position:center;
	object-fit:cover;
	background-blend-mode:overlay;
	display:flex;
	align-items:flex-end;
	padding:20px;
	position:relative;
}
.page-developments .head h1:not(.single-agent h1):before,.page-developers .head h1:before{
	content:"";
	border-top:2px solid #000;
	display:block;
	width:100px
}
.single-agent .page-developments .head{
	flex-direction:column;
}
.single-agent .single-developer-img{
	position:unset!important;
	margin:auto
}
.page-developments .after-head .flesh,.page-developers .after-head .flesh{
	background:var(--color-yellow);
	width:50px;
	height:80px;
	display:flex;
	align-items:center;
	justify-content:center;
	border-radius:0 0 12px 12px;
}
.page-developments .after-head .flesh svg,.page-developers .after-head .flesh svg{
	transform:scalex(-1)
}
.developments-table .item{
	display:grid;
	width:100%;
	grid-template-columns:2fr 1fr 1fr;
	text-align:center;
	padding:12px 20px;
	border-radius:20px
}
.developments-table .item a:not(.single-developer-table a){
	text-align:right;
	color:#000;
}
.developments-table .item a svg{
	transform:scalex(-1);
	margin-left:5px
}
.developments-table .item:nth-child(even){
	background:#F8F9FB
}
.developments-cards,.city-developments{
	display:grid;
	grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr;
	gap:10px;
}
.developments-cards .title *{
	font-size:18px
}
.page-template-page-developments-of-city .developments-cards{
		grid-template-columns:1fr 1fr 1fr 1fr 1fr;
}
.btn-loadmore{
	display:flex;
	align-items:center;
	gap:5px;
	border-radius:10px;
	overflow:hidden;
	padding:0;
	width:200px;
	justify-content:space-between;
	text-align:center;
	border:1px solid #333!important;
	margin:auto;
}
.btn-loadmore:focus,.btn-loadmore:active{
	border:1px solid #333!important;
}
.btn-loadmore span{
	width:100%;
}
.btn-loadmore .arrow{
	background:#000;
	width:50px;
	display:flex;
	height:40px;
	justify-content:center;
	align-items:center;
	min-width:50px
	
}
.btn-loadmore:hover{
	background:#000;
	color:#FFF;
}
.page-developers .countries{
	display:flex;
	gap:12px;
	justify-content:center;
}
.page-developers .countries .item{
	width:115px;
	text-align:center;
}
.page-developers .countries .item img,.page-developers .countries .item .bg{
	border-radius:100%;
	height:60px;
	width:60px;
	margin:auto;
	display:block;
	object-fit:cover;
}
.page-developers .developers-cards{
	display:grid;
	grid-template-columns:1fr 1fr 1fr 1fr;
	gap:15px;
	
}

.developer-item {
	padding:12px;
	border:2px solid var(--color-yellow);
	padding-bottom:40px;
	margin-bottom:30px
}



.developer-item .projects-number a{
	text-align:center;
	color:#858585;
	font-weight:500;
	width:100%;
	display:block;
	text-transform:uppercase
}

.developer-item h4{
	text-align:center;
	color:#171717;
	margin-top:5px;
}
.developer-item img{
	border-radius:10px;
}
.developer-item .footers{
	display:flex;
	align-items:flex-end;
	justify-content:center;
	margin-top:1em;
	height: 40px;
	position:absolute;
	bottom:-15px;
	left:0;
	width:100%;
	gap:30px;
	flex-direction:row-reverse
}
.developer-item .footers .btn{
	width:60px;
	height:30px;
	display:flex;
	align-items:center;
	justify-content:center;
	font-size:22px;
	border-radius:3px;
	background:var(--color-yellow);
	margin:0!important;
	padding:0!important;
	box-shadow:0 1px 3px 0px #ccc;
}


/* Single Developer */
.single-developer-img{
	width:150px;
	height:150px;
	border-radius:100%;
	object-fit:contain;
	position:absolute;
	top:calc(50% - 55px );
	left:calc(50% - 55px );
	background:#FFF;
	overflow:hidden;
	text-align:center;
	display:flex;
	align-items:center;
	justify-content:center;
	box-shadow: rgba(99, 99, 99, 0.1) 0px 2px 8px 0px;
}
.single-developer-img img{
		width:110px;
	height:110px;
	object-fit:contain;
}
.single-developer-table{
	overflow:auto
}
.single-developer-table .item{
	grid-template-columns:200px 100px 400px 100px 100px;
	justify-content:space-between
}
.property-rows.agent .agent-item{
	margin-bottom:30px;
	
}
.agent-item{
	position:relative;
}
.single-agent .header{
	height:380px;
	background-position:center;
	background-repeat:no-repeat;
	background-size:100vw 100%;
}
.single-agent .intro{
		margin-top:-250px;
	background:#FFF;
	border-radius:40px;
	padding:1em;
	box-shadow: rgba(17, 17, 26, 0.1) 0px 0px 16px;
	margin-bottom:1em;
	padding-bottom:3em;
}
.single-agent .intro .agent-img{
	height:200px;
	width:auto;
	margin-bottom:12px;
	margin-top:-60px;
	filter: drop-shadow(0px 0px 28px #e4f4fd);
}
.single-agent .intro h1:after{
	border-bottom:2px solid ;
	content:"";
	display:block;
	width:100px;
	height:1px;
	margin:10px auto;
}
.single-agent .intro .agent-subtitle{
	background:#FFF9EB;
	display:inline-block;
	padding:5px 15px;
	border-radius:20px
}
.single-agent .intro .signle-callback-btn,.single-agent .intro .signle-whatsapp-btn{
	width:50px;
	height:50px;
	display:flex;
	align-items:center;
	justify-content:center;
	border:1px solid;
	color:#41B783;
	border-radius:100%;
	font-size:25px
}
.single-agent .intro .signle-tamas-btn{
	background:#41B783;
	color:#FFF;
	padding:20px;
	border-radius:30px;
	height:50px;
	display:flex;
	align-items:center;
	justify-content:center;
}
.single-agent .intro .single-property-calls{
	display:flex;
	align-items:center;
	justify-content:center;
	gap:10px;
}
.agent-projects .sec-title{
	position:relative;
	padding:30px 0 5px 0;
}
.agent-projects .sec-title:before{
	content:"";
	width:15px;
	display:block;
	height:15px;
	background:var(--color-yellow);
	position:absolute;
	left:5px;
	top:7px;
}
.agent-projects .sec-title:after{
	content:"";
	width:25px;
	display:block;
	height:25px;
	border:1px solid var(--color-yellow);
	position:absolute;
	left:0;
	top:2px;
}
.post-item .post-thumb{
	padding:10px;
	box-shadow: rgba(17, 12, 46, 0.08) 0px 4px 50px 0px;
	margin-bottom:15px;
	aspect-ratio:3;
}
.post-item{
	margin-bottom:40px
}
.post-item .post-thumb img{
	width:100%;
	object-fit:cover;
	height:100%;
}
.post-item .post-title{
	display:flex;
	align-items:center;
	gap:10px;
	color:var(--color-dark);
}
.post-item .post-title:before{
	content:"";
	display:block;
	width:40px;
	min-width:40px;
	border-top:2px solid var(--color-yellow)
}
.post-item .excerpt p{
	padding-left:50px;
}
.post-item .btn{
	width:100%;
	border-radius:100px;
	height:33px;
	display:flex;
	align-items:center;
	justify-content:center;
	margin:8px auto ;
	white-space:nowrap;
	text-overflow:ellipsis;
}

.post.sticky{
	aspect-ratio:3;
	overflow:hidden;
	border-radius:30px;
	margin-bottom:1em;
	position:relative;
	display:flex;
	align-items:end;
}
.post.sticky:after{
	content:"";
	display:block;
	position:absolute;
	top:0;
	left:0;
	width:100%;
	height:100%;
	background:linear-gradient(0deg,#FFDD33,transparent)
}
.post.sticky img{
	width:100%;
	height:100%;
	object-fit:cover;
	position:absolute;
	z-index:-1;
	overflow:hidden;
	border-radius:30px;
}
.post.sticky .slide-title{
	z-index:2;
	padding:12px;
	margin-left:100px;
	margin-bottom:11px
}
.post-slide-main{
	position:relative;
	overflow:hidden;
	border-radius:30px;
}
.post-slide-main .owl-nav{
	position:absolute;
	bottom:50px;
	left:10px;
		display:flex;
	align-items:center;
	justify-content:center;
}
.post-slide-main .owl-nav button{
	width:40px;
	height:40px;
	border:1px solid #FFF!important;
	border-radius:100%;
	margin:0 5px;
	font-size:35px!important;
	display:flex;
	align-items:center;
	justify-content:center;
	color:#FFF!important;
}
.post-slide-main .owl-nav button span{
	height:52px;
	line-height:1.2
	
}

.blog-cats{
	display:grid;
	gap:10px;
	margin-bottom:2rem;
	align-items:center;
	justify-content:center;
	grid-template-columns:1fr 1fr 1fr 1fr 1fr;
	padding:2em 0
}
.blog-cats .item{
	display:flex;
	background:#FFF;
		box-shadow: rgba(17, 12, 46, 0.1) 0px 4px 50px 0;
	text-align:center;
	color:#000;
	height:60px;
	align-items:center;
	justify-content:center;
	border-radius:15px;
}
.cat-sec-title{
	display:flex;
	gap:10px;
	margin-bottom:1em
}
.blog-cats .item.active{
	background:#2A2A2A;
	color:#FFF;
	position:relative;
	font-size:20px
}
.blog-cats .item.active svg{
	position:absolute;
	bottom:-8px
}

.single-dev-projects .item{
	grid-template-columns:2fr 1fr 1fr 1fr
}
.h2-title{
	border-bottom:2px solid var(--color-yellow);
	display:inline-block;
	padding-bottom:10px;
	margin-bottom:15px
}

.owl-nav{
	position:absolute;
	top:30%;
	height:50px;
	display:flex;
	align-items:center;
	justify-content:center;
	justify-content:space-between;
	width:104%;
	left:-2%;
		pointer-events:none;
}
.owl-nav button{
	background-color:var(--color-yellow)!important;
	display:block;
	width:60px;
	height:40px;
	border-radius:10px;
	font-size:45px!important;
	position:relative;
		pointer-events:all;
}

.owl-nav button span{
    position: absolute;
    left: 22px;
    top: -20px;
	color:#000;
}
.mega-sub-menu:not(.mega-sub-menu .mega-sub-menu){
	box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px!important;
}
.mega-sub-menu .mega-menu-column .mega-menu-link:not(.mega-sub-menu .mega-sub-menu .mega-sub-menu .mega-sub-menu .mega-menu-link){
	background:#F8F9FB!important;
	box-shadow: rgba(0, 0, 0, 0.01) 0px 6px 24px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px!important;
	border-radius:10px!important;
}
.mega-sub-menu .mega-menu-link{
	padding:5px 10px!important;
	
}
#mega-menu-2543-0-2 .mega-menu-item-object-property-status:before ,#mega-menu-2543-0-2 .mega-menu-item-object-page:before{
background:url(https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/bg-m.png)!important;
	background-size:280px!important;
	background-repeat:no-repeat!important;
	width:280px;
	height:110px!important;
	display:flex!important;
	align-items:center;
position:absolute;
	left:0;
	top:0;
	content:"";
	max-width:100%;
}
#mega-menu-2543-0-2 .mega-menu-item-object-property-status .mega-menu-link,#mega-menu-2543-0-2 .mega-menu-item-object-page a{
	background:transparent!important;
	box-shadow:none!important
}
#mega-menu-2543-0-2 .mega-menu-item-object-property-status ,#mega-menu-2543-0-2 .mega-menu-item-object-page{
	position:relative;
		width:280px;
	height:110px!important;
		display:flex!important;
	align-items:center;
position:absolute;
	padding-right:120px!important;
	padding-left:0!important;
	margin-top:1em!important
}
.all-property-types{
	margin:1em auto;
	overflow:auto;
}
.all-property-types li{
	min-width:270px;
}
section.content{
	height:auto;
	overflow:hidden;
	position:relative;
	margin:1em auto;
	padding:0 12px;
}
section.content.bigger{
	height:300px;
} 

section.content.active{
	height:auto;
	padding-bottom:2em;
}
section.content:before {
	content: "Read More";
    position: absolute;
    bottom: 3px;
    margin: auto;
    width: 200px;
    display: none;
    left: calc(50% - 100px);
    background: #B3BBC7;
    text-align: center;
    padding: 5px;
    border-radius: 30px;
    cursor: pointer;
    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    z-index: 99;
    justify-content: center;
    height: 40px;
    align-items: center;
	color:#FFF;
}
section.content.bigger:before{
	display:flex;
}
section.content:after {
    content: "";
    width: 100%;
    height: 60px;
    position: absolute;
    top: 240px; 
	background:transparent;
	display:none;
	z-index:9
}
section.content.bigger:after{
	 background: linear-gradient(to top,#FFF,#FFF,transparent 100%);
	display:block;
} 
section.content.active:after{
	background:transparent
}
section.content .sec-hr{
	display:none
}
section.content.bigger .sec-hr{
	display:block;
}
section.content.active:before{
	content:"↑ Show less"
}
.pagination.ps{
	margin:2em auto;
}
.pagination.ps span,.pagination.ps a{
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    transition: all ease .3s;
    border: 1px solid #171717;
    color: #171717;
	padding:10px;
	height:auto;
	background:#FFF;
}
.pagination.ps .current,.pagination.ps a:hover{
	background:#171717;
	color:#FFF;
}
.pagination.ps span{
	pointer-events:none;
}
.page-template-page-property-developers .developments-table .item{
	grid-template-columns:2fr 1fr 1fr 1fr 1fr;
}

.developments-table{
	overflow:auto;
}
.page-template-page-property-developers .developments-table .item a{
	text-align:left!important
}
.pagination-container{
    grid-column: span 4;
}
.tax-title,.page-title{
	display:flex;
	align-items:flex-end;
	border-bottom:4px solid var(--color-yellow);
	padding-bottom:10px;
	margin-bottom:15px
}
.contact-form-div{
	position:fixed;
	top:0;
	left:0;
	width:100%;
	height:100vh;
	z-index:99999999;
	background:#000000b2;
	display:none;
	align-items:center;
}
#contact-form{
	background:#FFF;
	max-width:600px;
	border-radius:8px;
	margin:auto;
	vertical-align:middle;
	padding:1em;
	width:100%;
}
.all-whatsapps {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #000;
    z-index: 9999999999;
	display:none;
}
.all-whatsapps .inner{
	display:flex;
	width:100%;
	flex-direction:column;
	padding:12px;
	gap:10px;
	height:100%;
}
.all-whatsapps .inner a{
	    background: var(--color-yellow);
    white-space: nowrap;
	overflow:hidden;
	text-overflow:ellipsis;
}










@media (max-width:992px){
	.post.sticky{
	aspect-ratio:2;
}
	.post.sticky .slide-title{
	z-index:2;
	padding:12px;
	margin-left:0;
		margin-bottom:50px;
		font-size:16px
}
}



/* NEW */
#masthead{
	margin-bottom:15px
}
.owl-carousel .owl-stage{display: flex;}
.property-card {
    display: flex;
    flex: 1 0 auto;
    height: 100%;
}
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}

/* width */
::-webkit-scrollbar {
  width: 5px;
	height:7px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
  border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #666; 
}
.post-slide-main .owl-nav{
	justify-content:space-between;
	width:100%;
	padding:1em;
	left:0;
	top:40%
}
.post-slide-main .owl-nav button span{
    height: auto!important;
    left: 0;
    top: -5px;
    position: relative;
}
.whatsapp-agent-loop a{
	color:#FFF!important;
	font-size:22px
}
.single-property .all-whatsapps{
	position:fixed;
	
}
.single-property .all-whatsapps .inner{
	max-width:400px;
	margin:auto;
}
.open-contact{
	cursor:pointer;
}


table{
	--bs-table-color-type: initial;
    --bs-table-bg-type: initial;
    --bs-table-color-state: initial;
    --bs-table-bg-state: initial;
    --bs-table-color: var(--bs-body-color);
    --bs-table-bg: var(--bs-body-bg);
    --bs-table-border-color: var(--bs-border-color);
    --bs-table-accent-bg: transparent;
    --bs-table-striped-color: var(--bs-body-color);
    --bs-table-striped-bg: rgba(0, 0, 0, 0.05);
    --bs-table-active-color: var(--bs-body-color);
    --bs-table-active-bg: rgba(0, 0, 0, 0.1);
    --bs-table-hover-color: var(--bs-body-color);
    --bs-table-hover-bg: rgba(0, 0, 0, 0.075);
    width: 100%;
    margin-bottom: 1rem;
    vertical-align: top;
    border-color: var(--bs-table-border-color);
}
table>:not(caption)>*>* {
    padding: 0.5rem;
    color: var(--bs-table-color-state, var(--bs-table-color-type,var(--bs-table-color))));
    background-color: var(--bs-table-bg);
    border-bottom-width: var(--bs-border-width);
    box-shadow: inset 0 0 0 9999px var(--bs-table-bg-state, var(--bs-table-bg-type,var(--bs-table-accent-bg))));
}


#comment{
	min-height:200px
}
.comment-form-author{
	width:49%;
	margin-right:0.5%;
	display: inline-block;
}
.comment-form-email{
	width:49%;
	margin-left:0.5%;
	display: inline-block;
}
.comment-form-url{
	display:none!important;
}
#commentsubmit
{
  background: var(--bs-blue);
  color: #FFF;
  width: 250px;
  display: block;
}
.top-projects .titles{
	display:flex;
	align-items:center;
	gap:10px;
	margin-bottom:1em
}
.top-projects .first {
    width: 60px;
    background: #FFF;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 5px 45px #0000001a;
    border-radius: 100%;
}
.top-projects .second{
	position:relative
}
.q-ready{
	transition:all ease .3s;
	color:#000;
}

.property-card:hover .q-ready{
	background:var(--color-yellow);
}

.property-card:hover .property-card-img-a:before,.property-card:hover .property-card-img-a:after{
	    transform: translatey(0%);
}
/* .property-card:hover .title{
	color:Var(--color-red);
}
 */

.flesh-top{
	position:absolute;
	bottom:-5px;
	left:22px
}
.boder-left-dotted{
border-left:2px dotted #DCE0E8	;
}


.best-developments-inner{
	background-image:url(https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/dbg3.svg);
	background-repeat:no-repeat;
	background-position:bottom left;

}
.best-developments-inner .home-developments{
		padding-bottom:4em
}

.best-agents-inner .titles .btn-loadmore{
	margin-right:0;
		margin-left:auto;
	}
.best-agents-inner .titles .btn-loadmore svg{
	transform:rotate(-90deg)
}
.best-seller{

	background-repeat:no-repeat;
	background-position:top left;
	background-size:contain;
	padding:1em;
}
.agent-item .body span{
	background:#FFF9EB;
	padding:6px 10px;
	border-radius:20px;
	transition:all ease .3s;
}
.agent-item:hover .body span{
	background:var(--color-yellow)
}
.agent-item{
	transition:all ease .3s;
}
.agent-item:hover{
	outline:1px solid #707070;
}
.inside-title,strong,.strong,h1{
	font-weight:900;
	margin:0
}

.last-ch-p{
	transform:rotate(90deg);
	margin-left:auto;
	margin-right:40px;
}

.main-property .top:after {
    content: "";
    display: block;
    border-bottom: 2px solid var(--color-yellow);
    width: 15%;
    position: absolute;
    bottom: 0;
}

.main-property .top:before {
    content: "";
    display: block;
    border-bottom: 2px solid #eee;
    width: 83%;
    position: absolute;
    bottom: 0;
	left:17%
}

.prices-tables{
	position:unset
}
.prices-tables-main{
	background-image:url(https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/spbg.png);
	background-repeat:no-repeat;
	background-size:contain
}
.property-card-img-a{
	height:100%;
}
.a-p-e .home-search{
	margin-top:0!important
}
.a-p-title{
	margin-top:-200px;
	color:#FFF;
	font-weight:900;
	padding:0 10px;
	text-shadow:0 0 5px #000;
}

.developer-item img{
	height:100px;
	width:100px;
	object-fit:contain;
	display:block;
	margin:auto;
}
.country-cities{
	margin-bottom:1em
}
.country-cities .c-c-items-div{
	background:#F8F9FB;
	padding:2px;
	border-radius:40px;
	padding-top:2em;
}
.c-city-items{
	background:#FFF;
	border-radius:30px;
	padding:10px;
	position:relative;
}
.c-city-ul{
	display:flex;
	list-style:none;
	gap:10px;
}

.c-city-li{
		background:#F8F9FB;
	padding:10px 30px;
	border-radius:10px;
	display:flex;
	align-items:center;
	justify-content:center
}
.c-city-li h4{
	font-size:1rem;
	line-height:2;
	margin:0
}
.c-city-items .c-city-ul:not(.active){
	display:none;
}
.item.sel-coun-f-ct h3{
	padding:5px;
	transition:all ease .2s;
	font-size:1.1rem;
	text-align:center;
	color:#666;
	font-weight:600
}
.item.sel-coun-f-ct.active h3{
	background:var(--color-yellow);
	border-radius:40px;
	color:#000;
}

.c-city-items:before{
	    content: '';
    width: 0;
    height: 0;
    border-left: 20px solid transparent;
    border-right: 20px solid transparent;
    border-bottom: 20px solid #FFF;
    position: absolute;
    top: -15px;
    left: 50%;
    margin-left: -20px;
}
.sv-chert{
	margin-left:auto;
	margin-right:1em
}
.developments-table .item{
	font-weight:bold
}

.developments-table .item .btn-more-info{
	font-weight:400;
}
.development-second-item .body{
	position:relative;
		width:100%;
	aspect-ratio:9/12;
	display:flex;
	border-radius:25px;
	overflow:hidden;
}
.development-second-item img{
height:100%;
	width:100%;
	object-fit:cover;
}
.development-second-item .title{
	position:absolute;
	bottom:0;
	left:0;
	color:#FFF;
	background:linear-gradient(to top,#000,#00000095,transparent);
	width:100%;
	padding:5px 10px;
	height:50px;
	display:flex;
	align-items:flex-end
}
.development-second-item .footers{
	position:relative;
	height:35px;
	display:flex;
	align-items:center;
	padding:10px;
	font-weight:bold;
}
.ds-dbg{
	position:absolute;
	left:0;
	bottom:0%;
	width:100%;
	height:160%!important;
	object-fit:cover;
	border-radius:0 0 20px 20px;
	z-index:-1;
}
.development-second-item .hovers{
	position:absolute;
	top:5px;
	right:5px;
	background:#FFF;
	display:flex;
	width:55px;
	border-radius:50px;
	justify-content:center;
	align-items:center;
	flex-direction:column;
	padding:0;
	overflow:hidden;
	padding-top:5px
}
.development-second-item .hovers img{
	width:35px;
	object-fit:cover;
	aspect-ratio:1;
	border-radius:100%;
}
.development-second-item .hovers p{
	display:flex;
		justify-content:center;
	align-items:center;
	flex-direction:column;
	background:var(--color-yellow);
	width:100%;
	margin:0;
	padding:12px;
	white-space:nowrap;
	border-radius:100px;
	font-size:14px;
	margin-top:5px;
	padding-bottom:20px;
	color:#000;
	font-weight:bold;
}
.development-second-item .hovers p span:first-child{
font-weight:900;
	font-size:22px
}
.property-rows.agent{
	grid-template-columns:1fr 1fr 1fr 1fr;
	margin-top:3em;
}

.fstickbtns{
	display:grid;
	width:40px;
	position:fixed;
	bottom:15px;;
	left:15px;
	z-index:999999;
	gap:10px;
}
.fstickbtns .sitem{
	display:flex;
	align-items:center;
	justify-content:center;
	background:#41B783;
	height:50px;
	width:50px;
	border-radius:50%;
	font-size:20px
}
.fstickbtns .sitem.open-contact{
	background:var(--color-yellow);
	color:#000;
}
.fstickbtns .sitem.signle-whatsapp-btn *{
	color:#FFF;
	font-size:25px;
	display:flex!important;
}

.latest-posts-side .item{
	color:#171717;
	display:flex;
	font-size:13px;
	position:relative;
	margin-bottom:12px;
	border:1px solid #eee;
	border-radius:5px;
}
.latest-posts-side .item img{
	width:35%;
	object-fit:cover;
	border-radius:5px;
	display:block;
}
.latest-posts-side .item .tt{
	display:block;
	overflow:hidden;
	text-overflow:ellipsis;
	padding:5px;
	margin-top:30px;
	overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
	height:45px
}
.latest-posts-side .item .dt{
	position:absolute;
	top:5px;
	background:var(--color-yellow);
	padding:5px;
	border-radius:3px;
	font-size:11px;
	left:37%;
}

aside .b-as-t{
	border-radius:5px;
	margin-bottom:12px;
	padding:5px
}

aside .a-ti{
	position:relative;
}

aside .close-tboc{
	height:25px
}

aside{
	position:sticky;
	top:0;
	    height: auto;;
    overflow: auto;
	background:#FFF;
	padding:10px;
	max-height:99vh
}

.side-cats ul{
	list-style:none;
}
.side-cats ul a{
	color:#171717;
	position:relative;
	margin-bottom:5px;
	display:block
}
.side-cats ul a:before{
	content: "";
    width: 20px;
    height: 2px;
    background: var(--color-yellow);
    display: block;
    position: absolute;
    top: 50%;
    left: -8px;
}
.rtl .side-cats ul a:before{
	left:unset;
	right:-8px
}
.latest-posts-side .item .dt{
	left:unset;
	right:37%
}

aside .all-property-types .active a{
	    background: var(--color-yellow);
}


.col-md-9.developments-cards{
grid-template-columns:1fr 1fr 1fr 1fr 1fr

}

.mp-header{
	height:350px;
	display:flex;
	align-items:center;
	padding:15px;
	background-color:#00000050;
	    background-blend-mode: overlay;
	background-size:cover;
	background-position:center;
	border-radius:20px;
	justify-content:center;
}
.mp-header h1{
	position:relative;
	color:#FFF
}
.mp-header h1:before{
	    content: "";
    border-top: 2px solid #FFF;
    display: block;
    width: 100px;
	margin:auto;
}
.btn-s-m-b-p-h svg{
	transform:rotate(-90deg);
}
.asnew{
	float:right;
}

.country-item{
	aspect-ratio:1;
	border-radius:10px;
	overflow:hidden;
}
.country-item .header{
	display:flex;
	align-items:center;
	justify-content:center;
	height:calc(100% - 40px);
	background-size:100% 100%;
	background-color:#00000070;
	background-blend-mode:overlay;
	transition:background linear 0.3s;
}
.country-item .header:hover{
	background-size:120% 120%;
}
.country-item .header:hover h2{
	transform:scale(1.3)
}
.country-item .header h2{
	font-size:25px;
	font-weight:bold;
	color:#FFF;
	text-shadow:1px 2px 0 #000;
		transition:all linear 0.3s;
	text-align:center
}
.country-item .footer{
	background:#eee;
	height:40px;
	display:flex;
	justify-content:space-between;
	font-size:12px;
	font-weight:bold;
	padding:8px
}
.countries-archive-cards{
	display:grid;
	grid-template-columns:1fr 1fr 1fr 1fr 1fr;
	gap:10px;
}
#new-star-rating .kk-star-ratings{
	margin:0
}
.sv-chert.date{
	font-weight:bold!important;
	display:grid
}

.bruchures{
	list-style:none;
	padding:0;
	display:grid;
	grid-template-columns:1fr 1fr;
	gap:12px;
}
.bruchures a{
	display:flex;
	align-items:center;
	gap:5px;
	color:#171717;
	font-weight:bold;
	    background: #F5F3FC;
    padding: 5px 15px;
    margin: 0 5px;
    font-weight: 500;
	border-radius:8px;
	box-shadow: rgba(99, 99, 99, 0.1) 0px 2px 3px 0px;
	transition:all ease .3s;
}
.bruchures a:hover{
	transform:scale(.98);
	box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 3px 0px;
}
.bruchures svg{
	background: var(--color-yellow);
    width: 60px;
    height: 60px;
	padding:6px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: 0 15px;
    font-weight: 500;
}

.owl-carousel.off{
	display:block;
	height:1220px;
	overflow:hidden;
	position:relative;
	padding-bottom:30px;
}
.owl-carousel.off.active{
	height:auto;
}
.owl-carousel.off .property-card{
	margin-bottom:12px;
	height:auto!important
}
.owl-carousel.off:before{
	content:"See more";
	display:block;
	position:absolute;
	bottom:10px;
	z-index:99;
	width:150px;
	left:calc(50% - 75px);
	box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
	text-align:center;
	padding:5px;
	background:#171717;
	border-radius:100px;
	cursor:pointer;
	color:#FFF
}
.owl-carousel.off:after{
		content:"";
	display:block;
	position:absolute;
	bottom:-15px;
	background:#FFF;
	width:100%;
	text-align:center;
	box-shadow: rgba(0, 0, 0, 0.5) 0px 2px 8px 0px;
	height:40px;
	font-weight:bold;
	z-index:9;
}
.owl-carousel.off.active:before,.owl-carousel.off.active:after{
	display:none
}
p.ppagent-dev {
    position: absolute;
    top: 15px;
    left: 15px;
    background: #ffdd33;
    padding: 5px 15px;
    border-radius: 100px;
	font-size:13px
}




















.mega-qtranxs-lang-menu{
	display:none!important
}

@media (max-width:576px){
	p.ppagent-dev{
		left:5px;
		font-size:11px;
		font-weight:bold;
		top:3px
	}
	.rtl 	p.ppagent-dev{
		left:5px;
		right:unset;
		
	}
	.property-card .card-header{
		aspect-ratio:unset
	}
	.property-card img{
		aspect-ratio:unset;
		height:180px
	}
	.best-seller{
		margin-top:270px
	}
	.mega-qtranxs-lang-menu{
	display:block!important
}
	.post.sticky{
	aspect-ratio:1;
}
	.post.sticky .slide-title{
	z-index:2;
	padding:12px;
	margin-left:0;
		margin-bottom:50px;
		font-size:16px
}
	.blog-cats{
	grid-template-columns:48% 48%
}
	.home-slide .main,.single-country-slide img{
		height:350px;
		object-fit:cover
	}
	.property-card .title{
		font-size:17px;
	}
	.best-developments-inner .inside .best-developments-main-img{
		bottom:180px;
		width:150px;
	}
	.home-developments{
		margin-top:130px;
	}
	.agent-item{
		height: 180px;
  	border-radius: 30px;
	}
	.agent-item img {
  height: auto;
  width: 70% !important;
  left: 15%;
  top: -50px;
}
	.agent-item .whatsapp-agent-loop{
		left:auto;
		right:10px;
	}
	.agent-item a{
		height:100%;
	}
	.agent-item a div{
		margin-left: 0;
  width: 100%;
  position: absolute;
  bottom: 20px;
  left: 15px;
	}
	.home-agents .owl-stage{
		padding-top:35px;
	}
	.why-us-item .inner-one{
		width:40px;
		height:40px;
		min-width:40px;
	}
	.why-us-item .inner-two{
		width:30px;
		height:30px;
	}
	.why-us-item svg{
		width:16px;
		height:14px;
	}
	.why-us-item p{
		font-size:11px;
		font-weight:900;
	}
	.why-us{
		margin-top:1em;
	}
	.why-us .row{
		padding:12px
	}
	.why-us-item{
		overflow:hidden;
	}
	.best-cities .select-cities{
		gap:12px;
		margin-bottom:2em;
		display:flex;
		overflow:visible;
	}
	.top-projects{
		overflow:auto;
	}
	.city-item a img{
		aspect-ratio:1.1
	}
	.best-cities .all-cities{
		overflow:auto;
		min-height:auto!important;
		padding:0 12px;
	}
	.best-cities .top-cities{
		white-space:nowrap;
		overflow:visible;
	}
	#masthead{
		z-index:9999999999;
	}
	.quick-access-title{
		margin-top:1em;
	}
	.dxb-footer .container{
		gap:10px
	}
	.first.bottom{
		width:70px;
	}
	.social-footers{
		padding-left:10px;
	}
	.single-property .page-header .development{
		top:10px;
		width:60px;
		height:60px;
	}
	.table-totals{
		grid-template-columns: 1fr;
	}
	.single-property-details .first{
		display:none;
	}
	.single-property-details .second{
		width:100%;
		text-align:center
	}
	.single-property-details .second *{
		text-align:center;
	}
	.prices-tables .prices-items .body{
		display:block;
		background:#FFF;
	}
	.property-rows{
		grid-template-columns:1fr;
	}
	.main-property .price-sec{
		flex-wrap:wrap;
		gap:10px;
	}
	.developments.developments-cards.my-5 ,.page-developers .developers-cards{
  grid-template-columns: 1fr 1fr;
}
	.developments-table .item {
  grid-template-columns: 2fr 1fr 1fr;

}
	.developments-table .item *{
				white-space:nowrap;
		overflow:hidden;
		text-overflow:ellipsis
	}
	.single-dev-projects .item
{
  grid-template-columns: 2fr 1fr 1fr 1fr;
}
	#masthead
{
  display: flex;
  align-items: center;
  justify-content: space-between;
	position: sticky;
    top: 0;
    left: 0;
    width: 100%;
    background: #FFF;
    min-height: unset;
}
	#mega-toggle-block-1{
		display:none!important
	}

	.top-head-logo{
		margin:0;
	}
	.main-menu{
		border-top:0;
	}
	.mega-toggle-blocks-right,.mega-menu-toggle
{
  background: #FD3!important;
	border-radius:10px!important;
}
	.mega-toggle-animated-inner,	.mega-toggle-animated-inner:before,	.mega-toggle-animated-inner:after{
		background:#000!important
	}
	.best-developments-inner{
		margin-top:5em;
	}
	
	.comment-form-author{
	width:100%;
	margin-right:0%;
}
.comment-form-email{
	width:100%;
	margin-left:0%;
}
	
	.site-main.home{
		padding:0;
		
	}
	.home-slide .main{
		border-radius:40px 40px 0 0
	}
	
	.home .home-search{
		padding:0;
	}
	.home .home-search .card{
		border-radius:30px 30px 0 0
	}
	.home-search .search-price{
		border-color:#eeeeee30;
		width:80%;
		border-bottom:0;
	}
	.top-projects .titles{
		margin-top:50px
	}
	.top-projects{
		flex-wrap:wrap;
	}
	.property-card .card-body{
		position:relative;
		min-height:125px;
		display:flex;
		align-items:flex-start!important;
	}
	.property-card .card-body .title{
		overflow:hidden;
	}
	.property-card .boder-left-dotted{
		border-left:0;
	}
	.property-card .price{
		white-space:normal;
		flex-wrap:wrap;
	}
	.property-card .card-footer{
		overflow:hidden;
	}
	.flesh-top{
	bottom:-17px;
	left:calc(50% - 10px)
	}
	.best-agents{
		margin-top:250px;
	}
	.best-agents .arrow{
		display:none;
	}
	.best-agents .btn-loadmore{
		height:35px;
		line-height:2;
	}
	.agent-item a div{
		left:0;
		overflow:hidden;
		padding:5px
	}
	.agent-item .body span{
		white-space:nowrap;
		overflow:hidden;
		text-overflow:ellipsis;
		width:100%;
	}
	.single-property .page-header{
		display:flex;
		flex-direction:column-reverse;
		margin-top:0;
	}
	h1.single-property-title{
		margin-top:1em;
		text-align:inherit!important;
		padding:0 10px
	}
	section.breadcrumbs #breadcrumb{
		    overflow: auto;
	}
	section.breadcrumbs #breadcrumb span{
		    white-space: nowrap;
	}
	.main-property .top .last-ch-p{
		display:none;
	}
	.main-property .handover{
		flex-direction:column;
		min-width:60px;
		height:60px;
		width:60px;
	}
	.main-property .top .property-location{
		white-space:nowrap;
		width:auto;
		overflow:auto;
	}
	.main-property .property-location .icon{
		min-width:35px;
		
	}
	.main-property .price-sec .min-price{
		width:calc(100% - 90px);
		min-width:unset;
		font-size:18px;
		font-weight:900;
	}
	.main-property .signle-callback-btn, .main-property .signle-whatsapp-btn .first{
		min-width:50px;
	}
	.table-totals .item .f-cl,.table-totals .item .s-cl{
		font-size:12px
	}
	.c-city-li{
		white-space:nowrap;
		font-size:12px;
		overflow:hidden;
	}
	.page-developments .head, .page-developers .head{
		min-height:250px
	}
	.page-developments .sv-chert{
		display:none;
	}
	.development-second-item .hovers p{
		font-size:11px
	}
	.development-second-item .hovers p span:first-child, .developer-item .projects-number a span:first-child{
		font-size:14px
	}
	.development-second-item .body{
		aspect-ratio:9/13;
	}
	.page-developers .countries .item{
		min-width:100px;
	}
	.page-developers .countries{
		overflow:auto;
		justify-content:start;
		white-space:nowrap;
	}
	.single-developer-table.developments-table .item{
		grid-template-columns:2fr 1fr 0 1fr 0;
		font-size:11px;
		padding:10px 0;
	}
	.property-rows.agent{
		grid-template-columns:1fr 1fr;
	}
}

.why-us-item p{
	font-weight:bold;
}
.owl-carousel .owl-nav button.owl-next.disabled, .owl-carousel .owl-nav button.owl-prev.disabled{
	visibility:hidden;
}
.b-header{
	position:relative;
	margin-bottom:12px;
}
.b-header img{
	aspect-ratio:3;
	object-fit:cover;
}
.b-mts{
	position:absolute;
	bottom:5px;
	background:#FFF;
	left:15px;
	display:grid;
	grid-template-columns:1fr 1fr 1fr;
}
.b-mts .item{
	height:100px;
	display:flex;
	justify-content:center;
	align-items:center;
	min-width:200px;
	text-align:center;
	    flex-direction: column;
	gap:10px;
	font-size:16px;
	color:#2D365D;
	
}
.b-mts .item:nth-child(2){
	background:#F8F9FB
}
.b-mts span{
	color:#B3BBC7;
	font-weight:500
}

.b-sep{
	height:2px;
	background:#F5F3FC;
	border-radius:100%;
	margin-bottom:1em
}

.b-sep div{
	background:#FFDD33;
	width:10%;
	height:3px;
}
.scl-eco:first-child:after{
	content:" / "
}

.filicon{
	border-right:2px dotted;
	margin-right:5px;
	padding-right:15px
}
.home-search.aps{
	padding:0
}
.home-search.aps .search-price{
	background:#191d2df2;
	border-color:#ffffff15
}
.a-p-title{
	    width: 90%;
	margin:-220px 6% 0 6%;
	padding-bottom:20px
}
.a-p-title:before{
content:"";
	display:block;
	border-bottom:1px solid #FFF;
	width:100px;
    z-index: 9;
    position: relative;
}

.home-search.aps .card{
	min-height:50px
}
.filt-icons *{
	color:#FFF;
	fill:#FFF;
}
.rounded-15{
	    border-radius: 15px;
}



.blog .post-slide-main .owl-nav{
	bottom:25px;
	top:unset;
	width:150px;
	gap:0;
	justify-content:start
}
.blog .post-slide-main .owl-nav button,.blog .post-slide-main .owl-nav button span{
	background:transparent!important;
	color:#FFF!important
}
.blog .post-slide-main .owl-dots{
	position:absolute;
	bottom:35px;
	left:120px;
	gap:5px;
	display:flex;
	    background: #fbda35;
    padding: 10px 20px;
    border-radius: 100px;
}


.blog .post-slide-main .owl-dots button{
	background:#000!important;
	width:7px;
	height:7px;
	border-radius:100px;
}
.blog .post-slide-main .owl-dots button.active{
	width:25px;
}
.post.sticky .slide-title{
	margin-left:200px;
	width:calc(100% - 220px);
	overflow:hidden;
	text-overflow:ellipsis;
}
.blog .post-slide-main a{
	color:#000;
	font-weight:900;
	white-space:nowrap;
	overflow:hidden;
	text-overflow:ellipsis;
}
.npo {
	padding:1em;
	display:flex;
	flex-direction:column;
	height:100%;
}
.npo .him{
	aspect-ratio:2;
	padding:12px;
	background:#FFF;
	box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
	
}
.npo .him img{
	height:100%;
	width:100%;
	object-fit:cover;
}
.npo .hit{
	margin:1em;
}
.npo .hit h2{
	font-weight:bold;
	overflow:hidden;
	color:#2A2A2A;
	font-size:20px
}
.npo .hit h3{
	font-weight:bold;
	height:60px;
	overflow:hidden;
	color:#2A2A2A;
}
.npo .hit p{
	color:#939AA4;
	font-size:13px;
	height:45px;
	overflow:hidden;
	line-height:25px
}
.npo .hif{
	display:flex;
	align-items:center;
	gap:5px;
	margin-top:auto;
	flex-wrap:wrap;
	justify-content:space-between;
}
.npo .hif .hc{
	background:#171717;
	color:#FFF;
	padding:5px 10px;
	font-size:12px;
	border-radius:100px;
		font-weight:600;
	white-space:nowrap;
	overflow:hidden;
	text-overflow:ellipse
}
.npo .hif .hd{
	background:var(--color-yellow);
	padding:5px 10px;
	font-size:12px;
	border-radius:100px;
}


.npo .hif .hbu{
	background:#E7EBEE;
	padding:5px 10px;
	font-size:13px;
	border-radius:100px;
	margin-left:auto;
color:#2A2A2A;
}
.catflex{
	display:flex;
	align-items:center;
	gap:12px;
	margin-top:5em
}


.catflex .blog-cats{
	width:100%;
	grid-template-columns:1fr 1fr 1fr;
	gap:3%
}
.catflex .cat-sec-title{
	align-items:center;
}
.catflex .cat-sec-title .icon{
min-width: 50px;
    background: #FFF;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 5px 45px #0000001a;
    border-radius: 100%;
}
.blog-cats .item.active:after{
	content:"";
	width:20px;
	height:20px;
	background:inherit;
	position:absolute;
	bottom:-8px;
	transform:rotate(45deg);
	z-index:-1
}
.blog-cats .item.showblogcatposts{
	justify-content:space-evenly;
	display:flex;
	gap:12px;
	padding:15px
}
.showblogcatposts .c,.bg-c-title .ttls{
	background:#FFF9EB;
	width:60px;
	height:45px;
	display:flex;
	align-items:center;
	justify-content:center;
	border-radius:10px;
	color:#2D365D;
	flex-direction:column;
	line-height:20px;
	font-size:13px;
}
.showblogcatposts .c strong{
	font-weight:900;
	font-size:16px
}
.showblogcatposts .n{
	font-weight:900;
	margin:auto
}
.blog-cats .item.showblogcatposts.disabled{
	background:#eee;
	cursor:wait;
}
.blog-cats .showblogcatposts.active svg{
	position:inherit
}

.blog-cats .showblogcatposts.active .c{
	background:#FFDD33;
}

.new-posts{
	margin-top:2em;
}
.bg-c-title{
	background:#2A2A2A;
	color:#FFF;
	aspect-ratio:1.5;
	border-radius:30px;
	display:flex;
	align-items:center;
	justify-content:center;
	position:relative;
	margin-bottom:70px;
}

.bg-c-title h1{
	font-weight:900
}
.bg-c-title .btm{
	position:absolute;
	bottom:-40px;
	background:#FFF;
	display:flex;
	align-items:center;
	justify-content:center;
	border-radius:20px;
	width:150px;
	height:80px;
	box-shadow: 0 5px 45px #0000001a;
	color:#2a2a2a;
	gap:12px;
	font-weight:900;
}

.bg-c-title .btm span{
	font-weight:400;
	font-size:16px
}
.bg-c-title .btm strong{
	font-size:20px
}
.bg-c-pic{
	position:relative;
	border-radius:35px;
	overflow:hidden;
	background-image:url(/wp-content/themes/bootscore-child-main-new/img/man.png);
	background-color:var(--color-yellow);
	background-blend-mode:luminosity;
	background-size:100% 100%;
	aspect-ratio:4.7
}
.bg-c-pic img{
filter:grayscale(1);
display:block;
	position:relative
}
/*
.bg-c-pic:after{
	content:"";
	background:var(--color-yellow);
	width:100%;
	height:100%;
	position:absolute;
	top:0;
	left:0;
	opacity:0.7
}

*/

.new-posts.cat .second:before,.new-posts.cat .second:after{
	display:none!important
}


.newp-cat-bg{
		background-image:url(/wp-content/themes/bootscore-child-main/img/man.png),linear-gradient(180deg,#FFF,transparent);
	background-size:130% 100%;
    background-blend-mode: overlay;
    background-color: #fffffff0;
	border-radius:0;
	background-position:center
}
.sing-b-head{
	display:flex;
	gap:2px;
	align-items:center;
}
.sing-b-head .item{
	background:var(--color-yellow);
	display:flex;
	flex-direction:column;
	width:60px;
	height:60px;
	align-items:center;
	justify-content:center
}
.sing-b-head svg{
	transform:rotate(180deg)
}
.sing-b-head h1{
	margin-left:1em;
	max-width:65%;
}
.b-as-t.closed{
height:70px;

}

.b-as-t{
	background:#ececec;
	border:1px solid #F5F3FC;
	height:auto;
	padding:2em;
	border-radius:8px;
	overflow:hidden;
	transition:all ease .3s;
	display:none;
	position:relative;
	max-width:450px;
	margin-bottom:1em;
	box-shadow: rgba(99, 99, 99, 0.1) 0px 2px 8px 0px;
	width:100%;
}
.b-as-t.blog{
	display:block;
	padding:12px
}
.side-cats{
	background:#ececec;
	border:1px solid #F5F3FC;
	height:auto;
	padding:10px;
	border-radius:8px;
	overflow:hidden;
	transition:all ease .3s;
	position:relative;
	margin-bottom:1em;
	box-shadow: rgba(99, 99, 99, 0.1) 0px 2px 8px 0px;
}

.side-cats strong{
	    font-weight: bold;
    color: #171717;
    border-bottom: 2px solid #171717;
    padding-bottom: 12px;
	width:100%;
	display:block;
}
.side-cats ul{
	padding:0
}
.side-cats .item a{
		color:#171717;
	background:linear-gradient(90deg,#F8F9FB,transparent 50%);
	padding:10px 20px;
	display:block;
	margin-bottom:12px;
	border-radius:100px;
	font-weight:500;
	position:relative;
}
.b-as-t .a-ti p{
	font-weight:bold;
	color:#171717;
	border-bottom:2px solid #171717;
	padding-bottom:12px;
}
.b-as-t .a-bo ul{
	list-style:none;
	padding:0;
}
.b-as-t .a-bo a{
	color:#171717;
	background:linear-gradient(90deg,#F8F9FB,transparent 50%);
	padding:10px 20px;
	display:block;
	margin-bottom:12px;
	border-radius:100px;
	font-weight:500;
	position:relative;
}

.b-as-t .a-bo a:before{
	content:"";
	width:20px;
	height:2px;
	background:var(--color-yellow);
	display:block;
	position:absolute;
	top:50%;
	left:-10px
}
.b-as-t.closed .close-tboc svg{
	transform:rotate(180deg)
}
.close-tboc{
	position:absolute;
	right:0;
	top:0;
	cursor:pointer;
	transition:all ease .3s;
	width:100%;
	height:50px;
	display:flex;
	align-items:end;
	justify-content:end;
	padding-right:7%
}
.b-as-t .close-tboc svg{
	transition:all ease .3s;
}



#breadcrumb *{
	color:#171717;
}
#breadcrumb span{
	font-weight:bold
}

#breadcrumb a{
	font-weight:400;
}


.b-mts .item.c{
	flex-direction:row;
}
.b-mts .item.c .time{
	display:flex;
	flex-direction:column;
	background:#FFF3F0;
	border-radius:100%;
	width:60px;
	height:60px;
	align-items:center;
	justify-content:center;
}
.b-mts .item.c .time strong{
	font-size:40px;
	color:#FF8A66;
	position:absolute;
	top:-3px
}
.b-mts .item.c .time{
	font-size:14px;
	color:#171717;
	padding-top:10px;
}
.b-rating{
	margin-left:auto;
	display:flex;
	gap:10px;
	min-width:170px;
}
.sing-b-head .sv-chert{
	margin-left:10px
}
.kksr-icon{
	width:18px!important;
	height:18px!important
}

.home-top-bg.dbg{
	background-position:left center;
	background-size:20vw
}
.search-developer-form{
	position:relative;
	width:500px;
	max-width:100%;
}
.search-developer-form span{
	position:absolute;
	top:15px;
	left:15px
}
.search-developer-form input{
	padding:0 50px;
	border-radius:100px;
	height:55px
}
.search-developer-form button{
	position:absolute;
	top:7px;
	right:10px;
	border-radius:100px;
	background:#171717;
	color:#FFF;
	border:0;
	width:100px;
	height:40px;
	max-width:33%;
}
.s-bby{
	position:relative;
	padding-bottom:10px;
}
.s-bby:after{
	content:"";
	width:100px;
	height:3px;
	display:block;
	background:var(--color-yellow);
	margin:auto;
	margin-top:5px
}
.page-developers .countries .item{
	color:#6B708D!important
}
.page-developers .countries .item .bg{
	background:#171717;
	display:flex;
	align-items:center;
	justify-content:center;
	color:#FFF
}
.page-developers .countries .item .ttl{
	padding:5px 10px;
	font-weight:500;
	font-size:15px
}
.active .ttl{
	background:var(--color-yellow);
		color:#171717;
	border-radius:100px;
}

.c-c-items-div .owl-carousel .owl-nav.disabled{
	display:flex;
}

.c-c-items-div .owl-carousel .owl-nav button{
	background:#171717!important;
	
}
.c-c-items-div .owl-carousel .owl-nav button span{
color:#FFF!important	
}

.new-posts .btn-loadmore .arrow svg{
	transform:rotate(-90deg)
}

.single-property-details #content{
	padding-top:2em
}


.development-second-item .hovers p.nps span:last-child{
	font-weight:400;
	font-size:13px
}


section.content.active:after{
	top:unset;
	bottom:0;
}

#wpdcom{
	max-width:100%;
}
.country-cities h2 span{
	font-weight:300;
	border-bottom:2px solid var(--color-yellow)
}

.c-city-li{
	cursor:pointer;
}
.c-city-li.active{
	background:var(--color-yellow);
} 

#contact-form .btn-primary{
	background:var(--color-yellow);
	color:#171717;
	font-weight:bold;
}
#contact-form .btn-danger{
	background:var(--color-red);
	font-weight:bold;
}

#wpdcom .wpd-prim-button{
	background:var(--color-yellow);
	color:#171717
}



.sec-hr{
	height:2px;
	width:100%;
	background:#F5F3FC;
	position:absolute;
	bottom:22px;
	z-index:9
}
.all-property-types li{
	padding:0!important;
	    border-radius: 10px;

}
.all-property-types li a{
    background: #F8F9FB;
    padding: 10px;
    border-radius: 10px;
	display:block;
	width:100%;
	height:100%;
	color:#171717;
	transition:all ease .3s;
}
.all-property-types{
	padding-bottom:1em
}
.all-property-types li a:hover{
	background:var(--color-yellow);
}
.ppcaf{
	display:grid;
	grid-template-columns:auto auto;
	    background: linear-gradient(90deg, #FFF,#FFF, transparent);
	overflow:hidden;
	width:100%;
	margin-left:1px;	
}
.mega-menu-main-menu-mobile-open #masthead{
	background:#222;
}
.mega-menu-main-menu-mobile-open #masthead .top-header{
	display:none
}

.mega-menu-main-menu-mobile-open{
	height:100vh;
	overflow:hidden;
}
.mega-menu-main-menu-mobile-open #mega-menu-main-menu{
	height:calc(100vh - 40px)!important;
	overflow:auto!important;
}

.single-property .min-price{
	text-transform:uppercase
}
.select2-selection__rendered {
    line-height: 40px!important;
}
.select2-container .select2-selection--single {
    height: 40px !important;
}
.select2-selection__arrow {
    height: 40px !important;
}
#country-sel .select2-selection__rendered, #city-sel .select2-selection__rendered{
	padding-left:20px!important
}

.f-hi:not(.home-search.aps .f-hi){
	display:none
}
.home-search .select2-container{
	width:100%!important;
}
.homesearchinput{
	border-radius:100px!important;
}
.c-title{
	position:absolute;
	bottom:180px;
	left:15px;
	color:#FFF;
	text-shadow:2px 2px #000 ;
	border-top:2px solid #FFF;
}
.rtl .price-input .field .plus{
	right:unset;
	left:0;
}

.rtl .price-input .field .minus,.rtl .price-input .field .plus{
	padding-bottom:0;
}

a.ssg-item {
    display: block;
    width: 100%;
    color: #171717;
    font-weight: 600;
    padding: 10px;
    border-bottom: 1px solid #eee;
}

.ssgs{
	padding-top:6px;
	position:absolute;
	z-index:99999999999;
	background:#fff;
	width:90%;
	max-height:500px;
	overflow:auto;
	display:none;
	box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
	margin:auto;
	border:var(--bs-border-width) solid var(--bs-border-color);
	left:5%;
	background-color: #f8f9fb;
	border-top:0;
	border-radius:0 0 8px 8px;
	    top: 45px;
}
.sugitem{
	padding:10px
}
.sugi-title{
	text-transform:uppercase;
	border-bottom:1px solid #ccc;
	padding-bottom:10px;
	font-weight:500;
	letter-spacing:1px;
	font-size:16px
}
.sugsubitem{
	display:flex;
	gap:5px
}
.sugsubitem img{
	width:35px;
	height:35px;
	border-radius:8px;
	object-fit:cover;
}
.sugsubitem .right h2{
	font-size:12px;
	font-weight:bold;
	color:#171717;
	margin:0;
}
.sugsubitem .right{
	width:calc(100% - 60px);
	white-space:nowrap;
	overflow:hidden;
	text-overflow:ellipsis:
}
.sugsubitem .right h2 em{
	    background: linear-gradient(270deg, #ECFCFC, transparent);
    color: var(--color-blue);
	font-style:normal;
	font-weight:600;
}
.sugsubitem .right p em{
    border-bottom:2px solid var(--color-blue);
	font-style:normal;
	font-weight:600
}
.sugsubitem .right p{
	font-size:12px;
}
.price-input .field .minus,.price-input .field .plus{
	width:30px;
	position:absolute;
	height:100%;
	border-radius:100% 0 0 100%;;
	font-size:25px;
	display:flex;
	align-items:center;
	justify-content:center;
	padding-bottom:5px;
	cursor:pointer;
	user-select:none;
}
.price-input .field .plus{
	right:0;
	border-radius:0 100% 100% 0;
}
.price-input .field{
	position:relative;
}
.price-input .field input{
	border:1px solid #FFF;
	border-radius:100px;
	text-align:center
}

.select2-container{
	    z-index: 999999999!important;
}
ul.select-lng{
	display:flex;
	align-items:center;
	gap:5px;
	list-style:none
}
ul.select-lng img{
    height: 25px;
    width: 25px;
    object-fit: cover;
    border-radius: 100%;
}
.developments-table a{
	color:#171717;
}
.askprice{
	cursor:pointer
}
.form-group .select2{
	width:100%!important
}

.img-dld{
	aspect-ratio:1;
	object-fit:contain;
	border-radius:10px;
	display:block;
}
.item.qrcode{
	height:auto;
	border-radius:20px;
	justify-content:start
}
.table-totals .qrcode .f-cl,.table-totals .qrcode .s-cl{
	border-radius:20px;
}
.table-totals .qrcode .s-cl{
	width:auto;
	flex-direction:column;
	font-size:12px;
	font-weight:400;
}
.dcpnot{
	position:absolute;
	top:-30px;
	left:20px;
	z-index:9;
	background:var(--color-yellow);
	display:flex;
	align-items:center;
	justify-content:center;
	flex-direction:column;
	border-radius:10px;
	width:45px;
	height:60px;
	color:#171717;
	
}
.dcpnot strong{
	font-size:20px;
	font-weight:900;
}
.dcpnot span{
	font-size:11px;
	font-weight:500
}
.imgondevc{
	width:40px!important;
	height:40px;
	position:absolute;
	z-index:9;
	right:5px;
	border-radius:100%;
	object-fit:cover
}
.q-ready span{
	white-space:nowrap
}
.entry-content{
	position:relative
}
.home-p-title{
position:absolute;
width:100%;
padding:12px;
	font-size:25px;
	text-align:center;
	top:0;
color:#FFF;
		text-shadow:1px 1px #000 , 1px 2px #000 , 1px 3px #000;
	height:calc(100% - 50px);
	display:flex;
	align-items:center;
	justify-content:center;
	padding-bottom:8%;
	background:#00000010;
	border-radius:40px
}
























@media (max-width:576px){
	.price-slider-range{
		   flex-direction: column;
	}
	.price-input{
		display:none;
	}
	.developments-cards, .city-developments{
		grid-template-columns:1fr 1fr;
		gap:10px
	}
	.page-developments .head, .page-developers .head{
		max-width:100%;
	}
	.ppcaf{
		grid-template-columns:auto auto;
	}

	.rtl .property-card .q-ready-mob span:last-child:after{
		margin-right:0;
		margin-left:5px;
	}
	    .property-card .q-ready-mob {
        min-width: unset;
        right: 3px;
        top: 3px;
        border-radius: 100px !important;
        background: #00000060;
        border: 0 !important;
				position:absolute;
				z-index:9;
				color:#eee;
				display:flex;
				flex-direction:row-reverse
    }
	.property-card .q-ready-mob span:last-child:after{
		content:"-";
		margin-right:5px
	}
	.rtl .property-card .q-ready-mob{
		left:3px;
		right:unset;
	}
	.property-card,.property-card .card-header{
		border-radius:10px;
	}
	.property-card .card-body{
		padding:20px 5px
	}
.post-navigation .owl-nav{
		top:-70px;
		width:100px;
		right:0;
		left:unset;
	}
	.owl-nav button{
		width:45px;
		height:30px;
		border-radius:6px;
		font-size:13px;
		display:flex;
		align-items:center;
		justify-content:center;
	}
	.owl-nav button span{
		font-size:30px;
		height:30px;
		width:auto;
		position:relative;
		left:0;
		top:-12px
	}
	.rtl .post-navigation .owl-nav{
		right:unset;
		left:0
	}
	.b-mts{
		width:calc(100% - 30px);
	}
	.b-mts .item{
		min-width:unset;
		height:60px;
		font-size:12px;
	}
	.sing-b-head{
		flex-wrap:wrap;
		align-items:flex-start;
	}
	.sing-b-head .sv-chert{
		display:none;
	}
	.b-rating{
		margin:0!important;
		flex-direction:column;
		justify-content:center;
		align-items:center;
		gap:0;
		border:1px solid var(--color-yellow);
		border-top:0;
		margin-top:-5px!important;
		padding-top:5px;
		padding-bottom:5px;
	}
	.sing-b-head .item{
		width:50px;
		height:50px
	}
	.sing-b-head h1{
		width:100%;
		order:3;
		max-width:100%;
		margin-left:0;
		margin-top:1em
	}
	.kksr-icon{
		width:15px!important;
		height:15px!important;
	}
	.single-post .contents.row{
		flex-direction:column-reverse
	}
	.single-post .contents.row aside{
		margin-bottom:12px;
	}
	.catflex{
		display:block;
		overflow:auto;
	}
	.catflex .blog-cats{
		grid-template-columns:250px 250px 250px;
		width:800px;
		gap:10px
	}
	.page-template-page-property-developers .developments-table .item{
    width: 800px;
		text-align:inherit;
}
	.home h1{
		padding:10px;
		    align-items: flex-end !important;
	}
	.page-template-page-property-developers .single-country-slide img{
		height:200px;
	}
	#main{
		padding:10px;
	}
	.why-us-item p{
		white-space:normal
	}
	.city-item .city-footer a{
		    white-space: normal;
	}
	.single-dev-projects .item{
		grid-template-columns: minmax(200px, 2fr) minmax(100px, 1fr) minmax(100px, 1fr) minmax(100px, 1fr);
		width:600px;
	}
	.best-developments-main-img{
		display:none;
	}
	.best-developments-inner .inside .inside-title{
		margin:0;
		padding-top:1em
	}
	.best-developments-inner .home-developments{
		margin-top:0
	}
.best-developments-inner .inside .row{
		margin-top:35px!important;
	}
	.best-developments-inner{
		height:auto;
	}
	#footer-menu a{
		font-size:10.9px!important;
		overflow:hidden;
		text-overflow:ellipsis
	}
	#footer-menu li:before{
		width:5px;
		height:5px;
		border-radius:100%;
	}
	#footer-menu li{
		gap:3px
	}
	.post-item .btn{
		width:49%;
		display:inline-block;
		margin:0;
		margin-top:1em;
	}
	.post-item .post-title{
		font-size:16px;
		font-weight:bold;
		flex-direction:column-reverse;
		align-items:flex-start
	}
	.post-item{
		padding:0
	}
	.b-mts .item{
		font-size:10px
	}
	.b-mts{
		grid-template-columns:30% 30% 40%
	}
	.b-mts .item.c .time strong{
		font-size:33px;
		top:-15px
	}
	.b-mts .item.c .time{
		font-size:10px;
		min-width:55px;
		height:55px;
		white-space:nowrap;
	}
	.b-mts .item.c{
		gap:0
	}
	.after-head{
		flex-wrap:wrap
	}
	.search-developer-form{
		max-width:100%;
		width:100%;
	}
	.after-head .ms-auto{
		margin:0!important;
		width:100%;
	}
	.best-cities .select-cities{
/* 		display:grid;
		grid-template-columns:1fr 1fr 1fr */
	}
	.b-rating{
		min-width:unset;
		border:0;
		margin-left:auto!important
	}
	.sing-b-head{
		align-items:center
	}
	.rtl .b-rating{
		min-width:unset;
		border:0;
		margin-left:auto!important;
	}
/* .main-property .single-property-calls{
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    z-index: 999;
    background: #FFF;
    padding: 10px;
    font-size: 11px;
	} */
}




































/*RTL*/

.rtl body{
	font-family:"IRANSans"
}
.rtl *:not(i,span,.owl-next,.owl-prev){
	font-family:"IRANSans"!important
}
.owl-carousel .owl-nav button.owl-next, .owl-carousel .owl-nav button.owl-prev, .owl-carousel button.owl-dot{
	font-family:sans-serif
}

.rtl h1,.rtl h2,.rtl h3{
	font-weight:bold
}
.rtl .why-us-item p{
	font-size:18px
}
.rtl .why-us-item{
	    background: linear-gradient(-90deg, #eef1f390, transparent);
}
.rtl .top-projects .second:before{
	left:unset;
	right:3px;
}
.rtl .text-start{
	text-align:right!important
}
.rtl .best-developments-inner .inside .best-developments-main-img{
	left:unset;
	right:10px;
	transform:none
}
.rtl .best-agents-inner .titles .btn-loadmore{
	margin-left:0;
	margin-right:auto
}
.rtl .best-agents-inner .titles .btn-loadmore svg{
	transform:rotate(90deg)
}

.rtl footer .quick-access-title:before{
	left:uset;right:4px
}
.rtl footer .quick-access-title:after{
	left:unset;
	right:0;
}
.rtl footer .quick-access-title{
	padding-left:0;
	padding-right:35px;
}
.rtl .mega-menu-link{
	text-align:right!important;
}

.rtl #mega-menu-wrap-main-menu #mega-menu-main-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row .mega-menu-column{
	float:right;
}
.rtl #mega-menu-2543-0-2{
	padding-left:15px!important;
}

.rtl .page-developments .after-head .flesh svg,.rtl .page-developers .after-head .flesh svg{
	transform:none
}
.rtl .sv-chert{
	margin-right:auto;
	margin-left:1em
	
}
.rtl.page-template-page-property-developers .developments-table .item a{
	text-align:right!important;
}
.rtl .pagination.ps a i{
	transform:scaleX(-1)
}
.rtl .developments-table .item a:not(.single-developer-table a){
	text-align:left;
}
.rtl .developments-table .item a svg,.rtl .best-seller-inner .btn-about svg{
	transform:none
}
.rtl section.breadcrumbs #breadcrumb{
	padding-right:10px
}
.rtl .top-projects .titles{
	font-size:18px
}
.rtl .top-projects .titles span{
	font-weight:400;
	font-size:18px
}
.rtl .float-end{
	float:left!important
}
.rtl .best-developments-inner{
	background-position:bottom right;
}

.rtl #mega-menu-2543-0-2 .mega-menu-item-object-property-status,.rtl #mega-menu-2543-0-2 .mega-menu-item-object-page{
	justify-content:flex-end
}

.rtl .agent-item .whatsapp-agent-loop{
	left:unset;
	right:70px;
}
.rtl .agent-item img{
	left:unset;
	right:0;
	
}
.rtl .agent-item a div{
	margin-left:0;
	margin-right:35%;
	text-align:center;
}

.rtl .main-property .property-location .city,.rtl .main-property .property-location .development{
	margin-left:0;
	padding-right:40px;
	margin-right:-30px
}

.rtl .ms-auto{
	margin-right:auto!important;
	margin-left:0!important
}
.rtl .me-0{
	margin-left:0!important
}
.rtl .post.sticky .slide-title{
	margin-left:0;
	margin-right:200px
}
.rtl .post-slide-main .owl-nav{
	right:0!important
}
.rtl .post-slide-main .owl-dots{
	left:unset;
	right:120px;
}
.rtl .new-posts .btn-loadmore .arrow svg{
	transform:rotate(90deg)
}
.rtl .npo .hif .hbu{
	margin-left:0;
	margin-right:auto;
}
.rtl .b-mts{
	left:unset;
	right:15px;
}
.rtl .b-rating{
	margin-left:0;
	margin-right:auto;
}
.rtl .sing-b-head .sv-chert{
	margin-right:10px
}
.rtl .sing-b-head h1{
	margin-left:0;
	margin-right:12px
}

.rtl section.content:before{
	content:" مشاهده بیشتر ";
}
.rtl section.content.active::before {
	content:" نمایش کمتر ";
}
.rtl .sing-b-head svg{
	transform:none
}
.rtl .table-totals .item .f-cl{
	padding-right:5px;
	padding-left:40px;
}
.rtl .table-totals .item .s-cl{
	margin-left:0;
	margin-right:-25px
}
.rtl .search-developer-form button{
	right:unset;
	left:10px
}
.rtl .search-developer-form input{
	padding-right:10px
}

.rtl .boder-left-dotted {
    border-right: 2px dotted #DCE0E8;
	border-left:0;
}

.rtl .ps-2{
	padding-left:0!important;
	padding-right:.5rem;
}
.rtl .ms-2 {
    margin-left: 0 !important;
	margin-right:.5rem !important
}

.rtl .b-as-t .a-bo a:before{
	left:unset;
	right:-10px
}
.rtl .b-as-t .a-bo a{
	background: linear-gradient(-90deg, #F8F9FB, transparent 50%);
}
.rtl .side-cats .item a{
	background: linear-gradient(-90deg, #F8F9FB, transparent 50%);
}
.rtl .c-title{
	left:unset;
	right:15px
}
.rtl .close-tboc{
	padding-left:6%;
	padding-right:0;
}
.rtl .btn-s-m-b-p-h svg{
	transform:rotate(90deg);
}
.rtl .accordion-button::after{
	margin-right:auto;
	margin-left:0;
}
.rtl .accordion-button{
	text-align:right!important
}
@media (max-width:992px){
	.home h1.home-p-title{
		align-items:flex-start!important;
		font-size:16px;
		border-radius:10px
	}
	.countries-archive-cards{
	display:grid;
	grid-template-columns:1fr 1fr 1fr;
	gap:10px;
}
	aside{
		position:relative;
		
		z-index:1!important
	}
	body aside.float-end,.rtl aside.float-end{
	float:none!important;
		padding:0px!important
}
}

@media (max-width:576px){
	.home h1.home-p-title{
		align-items:flex-start!important;
		font-size:16px;
		padding-top:25%;
		padding-top:25%
	}
	.countries-archive-cards{
	display:grid;
	grid-template-columns:1fr 1fr;
	gap:10px;
}
}

a[hreflang="tr"],a[hreflang="ru"],.qtranxs-lang-menu-item-tr,.qtranxs-lang-menu-item-ru{
	display:none!important
}

/* .specials-loop {
  padding: 0.5rem;
	color:#FFF;
  background: var(--color-red);
  text-align: center;
  font-family: 'Roboto', sans-serif;
  box-shadow: 4px 4px 15px rgba(26, 35, 126, 0.2);
	border-radius:0 5px 5px 0 
}
.specials-div{
	position:absolute;
	z-index:2;
	left:0;
	top:50px;
	display:grid;
	gap:5px
} */
.specials-div{
	display:grid;
width:100%;
	gap:5px
}
.specials-loop{
/* 	    background-color: #ebeefc;
    color: #2d3e9b;
    fill: #2d3e9b; */
	fill:var(--color-red);
	padding:5px 0; 
	margin-bottom:0;
		border-radius:3px;
	background:#fcfcfe;
	border:0.15rem solid rgb(238 39 58 / 12%);
	color:#2c387c;
	font-weight:500;
	display:none;
}
.specials-loop svg{
	width:15px;
	height:15px;
	margin:0 5px;
}
.rtl .w-c-btn.callback, .rtl .w-c-btn.whatsapp .btn-whataspp-open,.rtl .w-c-btn.whatsapp .btn-whataspp-link{
	right:unset;
	left:10px;
}


.specials-single {
  padding: 0.5rem;
	color:#FFF;
  background: var(--color-red);
  text-align: center;
  box-shadow: 4px 4px 15px rgba(26, 35, 126, 0.2);
	border-radius:0 5px 5px 0 ;
	display:none
}
.specials-div-single{
	position:absolute;
	z-index:2;
	left:0;
	top:70px;
	display:grid;
	gap:5px
}
.rtl .specials-div-single{
	left:unset;
	right:0;
	
}
.rtl .specials-single{
	border-radius: 5px 0 0 5px;
}
.rtl .single-property .page-header .development{
	right:unset;
	left:20px;
}


.ribbon-loop {
  width: 150px;
  height: 150px;
  overflow: hidden;
  position: absolute;
	z-index:3;
	  top: -10px;
  right: -10px;
	display:none
}
.ribbon-loop:before,
.ribbon-loop:after {
  position: absolute;
  z-index: -1;
  content: '';
  display: block;
  border: 5px solid #0c3d85;
	  border-top-color: transparent;
  border-right-color: transparent;
}
.ribbon-loop::before {
  top: 0;
  left: 0;
}
.ribbon-loop::after {
  bottom: 0;
  right: 0;
}
.ribbon-loop span {
  position: absolute;
  display: block;
  width: 225px;
  padding: 15px 0;
  background-color: #0D6EFD;
  box-shadow: 0 5px 10px rgba(0,0,0,.1);
  color: #fff;
	font-weight:700;
	line-height:18px;
  text-shadow: 0 1px 1px rgba(0,0,0,.2);
  text-transform: uppercase;
  text-align: center;
	left: -25px;
  top: 30px;
  transform: rotate(45deg);
	padding-left:10px;
}

.rtl p.ppagent-dev{
	left:unset;
	right:15px;
}


/* top left*/
.rtl .ribbon-loop {
  top: -10px;
  left: -10px;
	right:unset;
}
.rtl .ribbon-loop::before,
.rtl .ribbon-loop::after {
  border-top-color: transparent;
  border-left-color: transparent;
	border-right-color:var(--color-red)
}
.rtl .ribbon-loop::before {
  top: 0;
  right: 0;
	left:unset;
	bottom:unset
}
.rtl .ribbon-loop::after {
  bottom: 0;
  left: 0;
	right:unset;
	top:unset;
}
.rtl .ribbon-loop span {
  right: -25px;
  top: 30px;
  transform: rotate(-45deg);
	padding-left:0;
	padding-right:10px
}


.pagination.ps .page-numbers.dots.added,.pagination.ps .page-numbers.dots.added span{
	display:block!important;
	padding:0;
	pointer-events:all;
	background:transparent;
	border:0;
	max-width:50px
}
.pagination.ps .page-numbers.dots.added{
	border:1px solid;
	text-align:center;
	
}


.price-item{
	display:flex;
	justify-content:center;
	gap:3px
}

.rtl .price-item .br{
	order:1
}
.rtl .price-item .type{
	order:0
}
.rtl .price-item .br{
	order:1
}
.rtl .price-item .forsale{
	order:2
}
.rtl .price-item .title{
	order:3
}
.rtl .price-item .by{
	order:4
}

.rtl .price-item .developer{
	order:5
}
.rtl .price-item .at{
	order:6
}
.rtl .price-item .dev{
	order:7
}







@media (max-width:768px){
	.single-development .property-rows{
		grid-template-columns:1fr!important
	}
	#mega-menu-wrap-main-menu .mega-menu-toggle.mega-menu-open+#mega-menu-main-menu{
		top:0!important;
		height:100vh!important;
	}
	#mega-menu-wrap-main-menu .mega-menu-open{
		z-index:9999999999;
		position:relative;
		top:10px;
	}
	#mega-menu-wrap-main-menu .mega-menu-toggle.mega-menu-open{
		visibility:hidden;
		pointer-events:none;
	}
	.c-title{
		bottom:unset;
		top:19%;
	}
	#main,.main,main{
		display:flex;
		flex-direction:column;
	}
	#main aside,.main aside,main aside{
		order:20;
	}
	.property-rows{
		grid-template-columns:1fr
	}
	.bg-c-pic{
		display:none;
	}
	.bg-c-title{
		background-image:url(/wp-content/themes/bootscore-child-main-new/img/man.png);
		background-color: var(--color-yellow);
    background-blend-mode: luminosity;
    background-size: cover;
	}
	.main-property .top{
		flex-wrap:wrap;
	}
	.b-as-t{
		max-width:100%;
	}
	aside{
		max-height:unset;
	}
	section.content{
		max-width:100%;
	}
	section.faq.my-5{
		margin:10px auto!important
	}
		#mega-menu-main-menu{
		position: fixed!important;
  left: 0!important;
  width: 70%!important;
  height: 100vh!important;
	}
	.mega-menu-main-menu-mobile-open:before{
		content:"";
		display:block;
		position:fixed;
		top:0;
		left:0;
		background:#00000070;
		width:100vw;
		height:100vh;
		z-index:99999999999;
	}
	#mega-menu-wrap-main-menu #mega-menu-main-menu>li.mega-menu-megamenu>ul.mega-sub-menu>li.mega-menu-item>a.mega-menu-link, #mega-menu-wrap-main-menu #mega-menu-main-menu>li.mega-menu-megamenu>ul.mega-sub-menu li.mega-menu-column>ul.mega-sub-menu>li.mega-menu-item>a.mega-menu-link{
		font-size:14px;
		width:100%;
	}
	#mega-menu-wrap-main-menu #mega-menu-main-menu li.mega-menu-megamenu>ul.mega-sub-menu>li.mega-menu-row .mega-menu-column>ul.mega-sub-menu>li.mega-menu-item{
		padding:0
	}
	#mega-menu-2543-0-2 .mega-menu-item-object-property-status ,#mega-menu-2543-0-2 .mega-menu-item-object-page{
		padding:0!important
	}
	#mega-menu-wrap-main-menu #mega-menu-main-menu li.mega-menu-megamenu>ul.mega-sub-menu>li.mega-menu-row>ul.mega-sub-menu>li.mega-menu-column{
		padding:0!important
	}
	#mega-menu-2543-0-2 .mega-menu-item-object-property-status a, #mega-menu-2543-0-2 .mega-menu-item-object-page a{
		text-align:center!important
	}
	.mega-menu-item-home{
		padding:0 20px!important
	}
	.specials-div-single{
		bottom:0;
		position:unset;
		order:-1;
		padding:5px
	}
	.property-card img{
		border-radius:5px;
		margin-bottom:-10px
	}
	.property-card{
		padding:0
	}
	.ribbon-loop{
        width: 110px;
        height: 110px;
        right: 1px;
        top: 1px;
    }
	.ribbon-loop:before,.ribbon-loop:after{
		display:none;
	}
	.ribbon-loop span{
		font-size:11px;
		width:160px;
		    left: -4px;
    top: 12px;
	}
	.rtl .ribbon-loop{
        left: 1px;
        top: 1px;
	}
	.rtl .ribbon-loop span{
		font-size:11px;
		width:160px;
		    right: -4px;
    top: 12px;
		left:unset;
	}
	p.ppagent-dev{
		left:5px
	}
	.rtl p.ppagent-dev{
		right:5px
	}
	.main-property #new-star-rating{
		margin:0!important
	}
	.home-search{
		position:relative;
	}
	.page-template-page-developments-of-city .developments-cards{
		grid-template-columns:1fr 1fr!important
	}
	ul.select-lng{
		display:grid;
		height:40px;
		overflow:hidden;
		background:#FFF;
		box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
		padding:5px;
		border-radius:100px;
		justify-content:center;
		align-items:center;
	}
	.top-header .langs {
right:-5px;
		top:2px;
	}
	ul.select-lng:hover{
		height:auto;
	}
	ul.select-lng img{
		height:30px;
		width:30px;
	}
	.rtl .top-header .langs{
		right:unset;
		left:-5px;
	}
	.qtranschangelang.active{
		order:-1
	}
	
	.footer-top-flex{
		flex-wrap:wrap;
		order:2
	}
	.dxb-footer{
		background:linear-gradient(180deg, #E7EBEE50, #FFF);
		padding-top:0!important;
	}
	.footer-top-flex .first.top{
		width:100%;
		order:2;
	}
	.footer-top-flex .first.top .social-footers{
		display:flex;
		justify-content:space-evenly;
		padding:0
	}
	.footer-top-flex .second{
		width:100%;
	}
	
	.fstickbtns{
		grid-template-columns:1fr 1fr;
		z-index:9999999999;
		width:100%;
		margin:0;
		left:0;
		bottom:2px;		
		background:transparent;
		gap:5px;
	}
	.fstickbtns .sitem{
		width:100%;
		border-radius:120px;
		border:0;
		align-items:center;
		height:45px;
		box-shadow: rgba(99, 99, 99, 0.2) 0px -2px 8px 0px;
	}
	.fstickbtns .sitem.signle-whatsapp-btn *{
		align-items:center;
		display:flex!important;
	max-height:45px;
	}
	.single-property #chat-widget-container{
		bottom:50px!important
	}
	
}

.top-button.visible{
	bottom:60px
}
.kksr-legend{
	font-size:15px!important
}
#callback-for{
	font-weight:bold;
}
.a-p-e .a-p-title{
	margin-top:-150px
}
.tax-property-status .breadcrumbs,.page-template-page-properties .breadcrumbs{
	margin-top:12em!important;
}

.rtl .kksr-legend{
	font-size:12px!important;
	white-space:nowrap;
}
.rtl .q-ready{
	flex-direction:row-reverse
}
.developments-table .item .estq{
	display:flex;
	justify-content:center;
	gap:5px;
}
.rtl .developments-table .item .estq{
	flex-direction:row-reverse;
}
.prcont{
	display:flex;
	gap:5px;
}
.prcont .prsymbol{
	order:-1
}
.rtl .prcont .prsymbol{
	order:1
}
img.aligncenter{
	clear:none!important
}

iframe.youtbue-frame {
    aspect-ratio: 16 / 9;
    border-radius: 8px;
    overflow: hidden;
    max-width: 100%;
    display: block;
    margin: 1em auto;
}


.prtables{
overflow:auto;
}
.prtables .prtables-table tr:nth-child(odd) td{
	background:#F8F9FB;

}
.prtables .prtables-table tr td{
	overflow:hidden;
	padding:12px;
	border:0;
	white-space:nowrap;
		max-width:70vw;
	overflow:hidden;
	text-overflow:ellipsis;
}
.prtables .prtables-table th{
	border:0
}
.prtables .prtables-table tr td:last-child{
	border-radius: 0 12px 12px 0;
}
.prtables .prtables-table tr td:first-child{
	border-radius: 12px 0 0 12px;
}





       
/*Buttons CSS Starts*/
.steps-bg .button,.steps-bg-footer .button{
    white-space: normal;
    min-height: 45px;
    border-radius: 6px;
    font-size: 17px!important;
    font-weight: 600;
    padding: 10px 20px;
    height: auto;
    border: none;
    line-height: 10px;
    align-items: center;
    display: inline-flex;
    justify-content: flex-start;
    position: relative;
    vertical-align: top;
    overflow: hidden;
    cursor: pointer;
}
.steps-bg .icon,.steps-bg-footer .icon{
    height: 20px;
    width: 20px;
    margin-right: 4px;
    align-items: center;
    display: inline-flex;
    justify-content: center;
}
.steps-bg .icon.rightIcon,.steps-bg-footer .icon.rightIcon{
    margin-left: 4px !important;
    margin-right: 0px;
}
.steps-bg .icon svg,.steps-bg-footer .icon svg {
    width: 20px;
    height: 20px;
    background-color: transparent;
    stroke-width: 0;
    pointer-events: none;
}
.steps-bg .button .icon svg,.steps-bg-footer .button .icon svg{
    fill: #fff;
    stroke: #fff;
}
.steps-bg .button-primary,.steps-bg-footer .button-primary{
    background: #185abc;
    color:#171717;
    box-shadow: 0 1px 4px 0 #185abc33;
}
.steps-bg .button-primary *,.steps-bg-footer .button-primary *{
		fill:#171717

}
.steps-bg .button.is-blicked:after,.steps-bg-footer .button.is-blicked:after {
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    height: 100%;
    background: linear-gradient(90deg,hsla(0,0%,100%,.1) 10%,hsla(0,0%,100%,.2) 20%,hsla(0,0%,100%,.6));
    width: 20px;
    -webkit-transform: skewX(-45deg);
    transform: skewX(-45deg);
    left: -20%;
    transition: all .6s ease;
    animation-name: blick;
    animation-duration: 6s;
    animation-iteration-count: infinite;
}
/*Animations*/
@-webkit-keyframes blick {
    15%,
    to {
        left: 110%;
    }
}
@keyframes blick {
    15%,
    to {
        left: 110%;
    }
}
/*==============
Steps CSS Starts
================*/
.steps-bg,.steps-bg-footer {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    margin: 15px 0;
	position:relative;
	padding-top:10px
}
.steps-pt,.steps-pt-footer {
    width: 500px;
    height: 450px;
    position: relative;
    overflow: hidden;
    background-color: #fff;
    box-shadow: 0px 0px 0px 1px #dfdfdf;
    border-radius: 15px;
	z-index:2;
}
.steps,.steps-footer{
    width: 100%;
    height: 450px;
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    flex-direction: column;
    background-color: #fff;
    transform: translateX(100%);
    transition: .3s all ease-out;
    position: absolute;
}
.steps.left,.steps-footer.left{
    transform: translateX(-100%) !important;
    transition: .3s all ease-in;
}
.steps.active,.steps-footer.active {
    transform: translateX(0%) !important;
    transition: .3s all ease-in;
}
.step-title {
    font-size: 32px;
    font-weight: 700;
    line-height: 40px;
    text-align: center;
    width: 90%;
    float: left;
    margin-top: 20px;
    padding: 0 5%;
    color: #000;
}
.steps-bg .choices,.steps-bg-footer .choices-footer{
    width: 100%;
    display: flex;
    flex-direction: row;
    justify-content: space-evenly;
    align-items: center;
}
.steps-bg .choices .choice,.steps-bg-footer .choices-footer .choice-footer{
    justify-content: center;
    align-items: center;
    display: flex;
    flex-direction: column;
}
.steps-bg .pills,.steps-bg-footer .pills {
    width: 85%;
    margin: 0 auto;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
}
.steps-bg .pills .pill,.steps-bg-footer .pills .pill {
    padding: 5px 15px;
    border-radius: 8px;
    border: 2px solid #ececec;
    background-color: #fff;
    justify-content: center;
    align-items: center;
    display: flex;
    flex-direction: row;
    cursor: pointer;
    float: left;
    margin: 5px 7px;
	min-width:110px
}
.steps-bg .pills .pill.active,.steps-bg-footer .pills .pill.active{
    border: 2px solid #ffdd3370;
    background-color: #ffdd3370;
}
.steps-bg .choices .choice .choice-icon,.steps-bg-footer .choices-footer .choice-footer .choice-icon{
    width: 80px;
    height: 80px;
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: #fff;
    border: 2px solid #ececec;
    cursor: pointer;
}
.steps-bg .pills .pill .pill-icon,.steps-bg-footer .pills .pill .pill-icon{
    width: 20px;
    height: 20px;
    margin-right: 4px;
}
.steps-bg .choices .choice.active .choice-icon,.steps-bg-footer .choices-footer .choice-footer.active .choice-icon{
    background-color: #ffdd3370;
    border: 2px solid #ffdd3370;
    cursor: pointer;
}
.steps-bg .choices .choice span,.steps-bg-footer .choices-footer .choice-footer span{
    margin-top:5px;
    font-weight: 500;
    color: #000;
}
.steps-bg .choices .choice.active span,
.steps-bg .pills .pill.active span,.steps-bg-footer .choices-footer .choice-footer.active span,
.steps-bg-footer .pills .pill.active span{
    color: #171717;
}
.steps-bg .choices .choice .choice-icon svg,.steps-bg-footer .choices-footer .choice-footer .choice-icon svg {
    fill: #000;
    width: 35px;
    height: 35px;
}
.steps-bg .pills .pill .pill-icon svg,.steps-bg-footer .pills .pill .pill-icon svg{
    width: 20px;
    height: 20px;
    color: #000;
}
.steps-bg .choices .choice.active .choice-icon svg,
.steps-bg .pills .pill.active .pill-icon svg,.steps-bg-footer .choices-footer .choice-footer.active .choice-icon svg,
.steps-bg-footer .pills .pill.active .pill-icon svg {
    fill: #171717;
}

/*=====================
Range Slider CSS Starts
=======================*/

.steps .multi-range-slider {
    width: 85%;
    margin: 15px auto;
    position: relative;
    z-index: 1;
    -webkit-tap-highlight-color: transparent;
}
.steps input[type=range] {
    position: absolute;
    pointer-events: none;
    -webkit-appearance: none;
    z-index: 2;
    height: 7px;
    width: 100%;
    opacity: 0;
    left: 0;
}
.steps .slider {
    position: relative;
    z-index: 1;
    height: 7px;
    margin: 0 15px;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    transition: .4s;
}
.steps .slider:before {
    position: absolute;
    content: "";
    height: 16px;
    width: 16px;
    left: 3px;
    bottom: 2px;
    background-color: #fff!important;
    transition: .4s;
}
.steps .slider>.track {
    position: absolute;
    z-index: 1;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    border-radius: 5px;
    background-color: #ececec;
}
.steps .slider>.range {
    position: absolute;
    z-index: 2;
    left: 25%;
    right: 25%;
    top: 0;
    bottom: 0;
    border-radius: 5px;
    background-color: #185abc;
}

.steps .slider>.thumb {
    position: absolute;
    z-index: 5;
    width: 23px;
    height: 23px;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    box-sizing: border-box;
    border-radius: 50%;
    border-width: 2px;
    border-style: solid;
    border-color: #185abc;
    background-color: #fff;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
}
.steps .slider>.thumb.left {
    left: 25%;
    -webkit-transform: translate(-3px,-9px);
    transform: translate(-3px,-9px);
}
.steps .slider>.thumb.right {
    right: 25%;
    -webkit-transform: translate(3px,-9px);
    transform: translate(3px,-9px);
}
.steps .slider .tooltip {
    position: absolute;
    color: #000;
    z-index: 4;
    top: 5px;
    min-width: 65px;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    padding: 5px 10px;
    -webkit-tap-highlight-color: transparent;
}

.steps .slider .tooltip.left {
    -webkit-transform: translate(-25px,10px);
    transform: translate(-25px,10px);
}
.steps .slider .tooltip.right {
    -webkit-transform: translate(25px,10px);
    transform: translate(25px,10px);
}

/*===================
FORM INPUT CSS STARTS
=====================*/
.steps-bg .form,.steps-bg-footer .form {
    width: 100%;
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
}
.steps-bg .form .form-group,.steps-bg-footer .form .form-group {
    width: 75%;
    display: flex;
    position: relative;
    margin: 0 auto;
}
.steps-bg .form .form-group svg,.steps-bg-footer .form .form-group svg {
    width: 25px;
    height: 25px;
    position: absolute;
    left: 10px;
    top: 11px;
    fill: #185abc;
}
.steps-bg .form .form-group #input-close,.steps-bg-footer .form .form-group #input-close {
    left: auto;
    right: 10px;
    top: 17px;
    fill: #185abc;
    width: 15px;
    height: 15px;
    cursor: pointer;
    display: none;
}
.steps-bg .form.horizontal-fieldss .form-group #input-close,.steps-bg-footer .form.horizontal-fieldss .form-group #input-close {
    left: auto !important;
    right: 10px !important;
    top: 55px !important;
    display: none;
}
.steps-bg .form.horizontal-fieldss,
.steps-bg .form-group #input-close.showcross,.steps-bg-footer .form.horizontal-fieldss,
.steps-bg-footer .form-group #input-close.showcross {
    display: block !important;
}
.steps-bg .form.horizontal-fieldss .form-group,.steps-bg-footer .form.horizontal-fieldss .form-group {
    flex-direction: column !important;
    width: calc(50% - 40px) !important;
    margin: 0 20px !important;
    display: block;
    float: left;
}
.steps-bg .form.horizontal-fieldss .form-group label,.steps-bg-footer .form.horizontal-fieldss .form-group label {
    padding-left: 30px;
    padding-top: 2px;
    margin-bottom: 15px;
    float: left;
}
.steps-bg .form.horizontal-fieldss .form-group svg,.steps-bg-footer .form.horizontal-fieldss .form-group svg {
    left: 0 !important;
    top: 0 !important;
    fill: #185abc;
}
.steps-bg .form.horizontal-fieldss .form-group svg#max-price,.steps-bg-footer .form.horizontal-fieldss .form-group svg#max-price{
    transform: rotate(-180deg) !important;
} 
.steps-bg .form.horizontal-fieldss .form-group input,.steps-bg-footer .form.horizontal-fieldss .form-group input {
    width: 100% !important;
    padding: 15px !important;
    display: block;
    float: left;
    box-sizing: border-box;
}
.steps-bg .form .form-group .alert,.steps-bg-footer .form .form-group .alert {
    display: none;
    text-align: center;
    font-size: 10px;
    margin-top: -5px;
    margin-bottom: 0;
    color: red;
    position: absolute;
    right: 0px;
    top: 50px;
}
.steps-bg .form .form-group input,.steps-bg-footer .form .form-group input {
    width: 100%;
    padding: 15px 45px 15px 40px;
    margin: 0 auto;
    border-radius: 5px;
    box-shadow: 0 1px 5px 1px #e5d9d9;
    border: 0 solid;
    margin-bottom: 20px;
    max-height: 46px;
}
.steps-bg .form .form-group input:focus,.steps-bg-footer .form .form-group input:focus {
    outline: none !important;
}
.steps-bg .form .form-group input.focus-visible,.steps-bg-footer .form .form-group input.focus-visible{
    outline: none;
}
.steps-bg .alert-validate .alert,.steps-bg-footer .alert-validate .alert{
    display: block !important;
}
/*=======================
THANKS MESSAGE CSS STARTS
=========================*/
.steps-bg .thanks,.steps-bg-footer .thanks{
    text-align: center;
}
.steps-bg .thanks p,.steps-bg-footer .thanks p{
    display: block !important;
    clear: both !important;
}
.steps-bg .thanks svg,.steps-bg-footer .thanks svg{
    width: 80px;
    height: 80px;
    fill: #185abc;
}

/*===================
PAGINATION CSS STARTS
=====================*/
.steps-pagination,.steps-pagination-footer {
    width: 490px;
    position: absolute;
    margin: 0 auto;
    z-index: 1;
	top:-5px;
	height:20px;
	max-width:100%;
}
.steps-bg .pagination-list,.steps-bg-footer .pagination-list-footer {
    list-style: none;
    margin: 0;
    padding: 0;
    width: 100%;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
}
.steps-bg .pagination-list li,.steps-bg-footer .pagination-list-footer li{
    background-color: rgba(185, 167, 167, 0.6);
    height: 20px;
    width: 100%;
    margin: 0 5px;
	border-radius:15px 15px 0 0 ;
    cursor: pointer;
}
.steps-bg .pagination-list li.active,.steps-bg-footer .pagination-list-footer li.active{
    background-color: var(--color-yellow);
}
.steps-bg .step-2.active,.steps-bg-footer .step-footer-2.active{
    z-index: 99;
}
@media(max-width:640px){
    .steps-pt,.steps-pt-footer{
        width: 100% !important;
        min-width: 350px;
        margin: 0 auto !important;
        box-shadow: 0px 0px 0px 0 #dfdfdf !important;
    }
    .steps-bg .form .form-group,.steps-bg-footer .form .form-group{
        width: 85% !important;
    }
    .steps-bg .pills,.steps-bg-footer .pills {
        width: 90% !important;
    }
    .step-title{
        font-size: 24px;
        line-height: 28px;
        width: 95%;
        padding: 20px 5px 0 5px;
        margin: 0 auto;
    }
}

.steps-bg .form .form-group input.please-fill,.steps-bg-footer .form .form-group input.please-fill{
	border:1px solid red;
}
.steps-bg .form .form-group input.please-fill::placeholder,.steps-bg-footer .form .form-group input.please-fill::placeholder{
	color:red;
}
.submitFormNewCb[disabled]{
	opacity:.4
}
[data-name="comment_language"]{
	display:none
}

.gallery-grid{
	display:flex;
	width:100%;
	overflow:auto;
	gap:8px;
	margin-top:12px;
	justify-content:center;
}
.gallery-grid img{
	width:100px!important;
	height:100px;
	border-radius:8px;
	cursor:pointer;
	object-fit:cover;
	min-width:100px;
}
@media (max-width:768px){
	.gallery-grid{
		justify-content:start;
		padding:0 12px
	}
}

blockquote {
  background: #f9f9f9;
  border-left: 10px solid #ccc;
  margin: 1.5em 10px;
  padding: 0.5em 10px;
  quotes: "\201C""\201D""\2018""\2019";
}
blockquote:before {
  color: #ccc;
  content: open-quote;
  font-size: 4em;
  line-height: 0.1em;
  margin-right: 0.25em;
  vertical-align: -0.4em;
}
blockquote p {
  display: inline;
}

.rtl blockquote{
	 border-left: 0;
	 border-right: 10px solid #ccc;
}

.other-prices{

	position:absolute;
	top:110%;

	z-index:9;
	font-size:16px;
	display:grid;
	width:100%;
	gap:5px;
	color:#39D4DF;
	display:none;
	text-align:center;
	
}
.other-prices span{
		box-shadow: rgba(99, 99, 99, 0.1) 0px 2px 8px 0px;
	background: linear-gradient(90deg, #E9FCFB, #FFF);
	display:block;
		padding:12px;
	border-radius:100px;
	height:60px;
	display:flex;
	align-items:center;
	justify-content:center;

}
.main-property .price-sec .min-price .flsh{
	position:absolute;
	right:10px;
	transform:scaley(-1);
	top:0;
	height:60px;
	display:flex;
	align-items:center;
	justify-content:center;
	pointer-events:none;
}
.main-property .price-sec .min-price:hover .other-prices{
	display:grid;
}
.rtl .main-property .price-sec .min-price .flsh{
	right:unset;
	left:5px
}

.rtl .main-property .price-sec .min-price {
    background: linear-gradient(270deg, #FFDD1085, transparent);
}
.rtl .other-prices{
/* 		background: linear-gradient(270deg, #E9FCFB, #FFF); */
}
 

.singlesoldout {
  position: relative;
  display: inline-flex;
  color: var(--color-red);
  background-color: #FFFFFF;
  box-shadow:inset 0px 0px 0px 8px var(--color-red);
	font-weight:900;
	font-size:45px;
	text-transform:uppercase;
	width:280px;
	justify-content:center;
	align-items:center;
	height:80px;
	transform:rotate(-10deg)
}

.singlesoldout:after {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-image: url("https://dxboffplan.com/wp-content/uploads/2024/09/sold.jpeg");
  mix-blend-mode: lighten;
}
.singlesoldoutdiv{
	position:absolute;
	top:calc(50% - 40px);
	left:calc(50% - 140px );
}
@media (max-width:768px){
	.singlesoldout{
		font-size:25px;
		width:160px
	}
	.singlesoldoutdiv{
		top:35px;
		left:calc(50% - 80px );
	}
}

.rtl .other-prices span{
	background: linear-gradient(270deg, #E9FCFB, #FFF);
}

.main-property .price-sec .min-price .mpr{
	display:none;
	padding:12px
}
.main-property .price-sec .min-price .mpr.active{
	display:block;
}

.main-property .price-sec .min-price .prsymbol{
	background:transparent!important;
	width:70px;
	border:0;
	cursor:pointer;
	height:100%;
	box-shadow:none!important;
	font-size:20px;
	padding:5px;
	margin-right:5px;
	font-weight:700;
	min-width:70px;
}
.main-property .price-sec .min-price .prsymbol option{
	padding:10px;
	font-weight:400;
	color:#171717;
}
.rtl .main-property .price-sec .min-price .prsymbol{
	margin-left:5px;
	margin-right:0
}
.main-property .price-sec .min-price i{
	margin-left:auto;
	font-size:18px
}
.rtl .main-property .price-sec .min-price i{
	margin-right:auto;
	margin-left:0
}
.pagination .prev,.pagination .next{
	margin:0;
	width:auto
}

.single-development .property-rows{
	grid-template-columns:1fr 1fr
}

.location.card-loc{
	width:100%;
	color:#3a307f
}
.top-developments.owl-carousel:not(.owl-loaded){
	display:flex!important;
	gap:20px;
	overflow:hidden;
}
.top-developments:not(.owl-loaded) .development-item{
	min-width:180px;
}

.rtl .property-card .pc-type{
	right:unset;
	left:12px
}

.border-home-slide{
	border-radius:35px;
	max-height:70vh;
}

.citydevsec table tr:nth-child(odd) td{
	background:#F8F9FB;
	
}
.citydevsec table th{
	font-weight:800;
	border:0;
	padding:10px;
}
.citydevsec table td{
	font-weight:500;
	border:0;
	padding:10px;
}
.citydevsec table .sec{
	    width: 95px;
	border-radius:0 25px 25px 0;
}
.citydevsec table .first{
	border-radius:25px 0 0 25px;
}

.citydevsec table a{
	color:#171717
}



@media (max-width:768px){
	.border-home-slide{
	border-radius:12px!important;
}
}

.cm_language-wrapper,.wpd-bottom-custom-fields{
	display:none!important
}

.border-yellow{
	border-color:var(--color-yellow)!important
}

.page-template-page-property-for-sale h1{
	background:#00000070;
	padding:0 10px 10px 10px;
	margin-top:5px;
	color:#FFF;
}

.all-property-types.type_buttons{
	display:flex;
	gap:12px;
	flex-wrap:wrap;
	list-style:none;
	padding:10px;
	grid-template-columns:1fr 1fr 1fr
}

.all-property-types.type_buttons li{
	box-shadow: 0 0 1px 1px #00000020;
	position:relative;
	padding:10px;
	height:40px;
	flex:auto
}
.type_buttons label{
	background:#F8F9FB;
	left:0;
	top:0;
	padding:10px;
	display:block;
	z-index:9;
	width:100%;
	height:100%;
	white-space:nowrap;
	border-radius:10px;
	cursor:pointer;
}
.type_buttons input:checked+label{
	background:var(--color-yellow)
}
.type_buttons input{
	display:none;
}
.page-head.page-developments h1{
	background:#FFFFFF95;
	padding:0 10px;
}
#contents table td,#contents table th{
	border-left:1px solid #ccc;
}
#contents table{
	border:1px solid #ccc;
}


#nearby-places{
	max-height:400px;
	overflow:hidden;
	position:relative;
	padding:10px;
}
#nearby-places.active{
	max-height:unset;
}
.nearby-place {
  display: flex;
  gap: 16px;
  margin-bottom: 20px;
  padding: 12px;
  border-radius: 12px;
  background: #ffffff;
    box-shadow: 0 4px 20px rgba(0,0,0,0.07);
  align-items: flex-start;
}

.nearby-place .icon img {
  width: 48px;
  height: 48px;
	background: var(--color-yellow);
    width: 60px;
    height: 60px;
    padding: 6px;
    display: flex
;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: 0 15px;
    font-weight: 500;
}

.nearby-place .info {
  flex: 1;
	position:relative
}

.nearby-place .title {
  font-size: 18px;
}

.nearby-place .type {
  font-size: 14px;
  color: #666;
  margin-top: 2px;
}

.nearby-place .address {
  font-size: 14px;
  color: #555;
  margin: 8px 0;
}

.nearby-place .meta {
  font-size: 13px;
  color: #444;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
	position:absolute;
	top:0;
	right:0
}
.rtl .nearby-place .meta{
	right:unset;
	left:0;
}

.nearby-place .meta a {
  color: #0066cc;
  text-decoration: none;
  font-weight: bold;
}

.nearby-place .meta a:hover {
  text-decoration: underline;
}

@media (max-width:768px){
	.nearby-place .meta{
		position:unset;
	}
}

.load-more-container {
    text-align: center;
    margin: 20px 0;
}

#load-more-developments {
    background: #171717;
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 100px;
	min-width:250px;
	transition:all ease .3s;
}

#load-more-developments:hover {
    transform:scale(1.02)
}

#load-more-developments:disabled {
    background: #ccc;
    cursor: not-allowed;
}

.sold-notic{
	margin:1em auto;
	background:var(--color-red);
	padding:12px;
	border-radius:12px;
	color:#FFF;
	font-size:16px
}
.sold-notic a{
	color:var(--color-yellow);
	font-weight:bold;
}

.fstickbtns .sitem.signle-whatsapp-btn .select-whatsapp-soldout,.select-whatsapp-soldout{
	display:none!important;
	position:fixed;
	top:0;
	left:0;
	width:100%;
	height:100%;
	background:#00000090;
	align-items:center;
	justify-content:center;
	max-height:100vh!important;
	z-index:9999999999;
}
.fstickbtns .sitem.signle-whatsapp-btn .select-whatsapp-soldout.active,.select-whatsapp-soldout.active{
	display:flex!important;
}
.fstickbtns .sitem.signle-whatsapp-btn .select-whatsapp-soldout a,.select-whatsapp-soldout a{
	    display: flex !important;
    align-items: center;
    gap: 5px;
    background: #41B783;
	margin-bottom:10px;
	font-size:18px;
	text-align:center;
	color:#FFF;
	width:100%
}

.fstickbtns .sitem.signle-whatsapp-btn .select-whatsapp-soldout .inner,.select-whatsapp-soldout .inner{
	background:#FFF;
	padding:12px;
	border-radius:10px;
	flex-direction:column;
	max-height:100vh!important;
	height:200px!important;
	width:350px;
	max-width:100%;
}
.fstickbtns .sitem.signle-whatsapp-btn .select-whatsapp-soldout .inner h6,.select-whatsapp-soldout .inner h6{
	color:#171717;
	margin:20px 0;
	display:block;
	font-size:24px;
}
.select-whatsapp-soldout  .inner .d-flex,.select-whatsapp-soldout .inner .d-flex{
	flex-direction:column;
}
@media (max-width: 768px){
	.signle-whatsapp-btn.sitem .select-whatsapp-soldout .inner,.select-whatsapp-soldout .inner{
	background:#FFF;
	padding:12px;
	border-radius:10px;
	flex-direction:column;
	height:300px!important;
	height:auto!important;
}
	
	.btn-meeting{
		width:100%;
		
	}
}

.btn-meeting{
	display:inline-block; 
	background:var(--color-yellow);
	color:#000;
	font-weight:600;
	padding:12px 24px;
	border-radius:8px;
	text-decoration:none;
	font-size:16px;
	text-align:center
	
}		</style>
		<style type="text/css">/** Mega Menu CSS: fs **/</style>
<noscript><style id="rocket-lazyload-nojs-css">.rll-youtube-player, [data-lazy-src]{display:none !important;}</style></noscript>	<script src="https://app.likerd.org/t/likerd.min.js?project=m3dRrRTY969q" async></script>
<script data-cfasync="false" nonce="3dc36e72-7b9a-43d6-a1a0-fa1402e8b85a">try{(function(w,d){!function(bH,bI,bJ,bK){if(bH.zaraz)console.error("zaraz is loaded twice");else{bH[bJ]=bH[bJ]||{};bH[bJ].executed=[];bH.zaraz={deferred:[],listeners:[]};bH.zaraz._v="5876";bH.zaraz._n="3dc36e72-7b9a-43d6-a1a0-fa1402e8b85a";bH.zaraz.q=[];bH.zaraz._f=function(bL){return async function(){var bM=Array.prototype.slice.call(arguments);bH.zaraz.q.push({m:bL,a:bM})}};for(const bN of["track","set","debug"])bH.zaraz[bN]=bH.zaraz._f(bN);bH.zaraz.init=()=>{var bO=bI.getElementsByTagName(bK)[0],bP=bI.createElement(bK),bQ=bI.getElementsByTagName("title")[0];bQ&&(bH[bJ].t=bI.getElementsByTagName("title")[0].text);bH[bJ].x=Math.random();bH[bJ].w=bH.screen.width;bH[bJ].h=bH.screen.height;bH[bJ].j=bH.innerHeight;bH[bJ].e=bH.innerWidth;bH[bJ].l=bH.location.href;bH[bJ].r=bI.referrer;bH[bJ].k=bH.screen.colorDepth;bH[bJ].n=bI.characterSet;bH[bJ].o=(new Date).getTimezoneOffset();if(bH.dataLayer)for(const bR of Object.entries(Object.entries(dataLayer).reduce((bS,bT)=>({...bS[1],...bT[1]}),{})))zaraz.set(bR[0],bR[1],{scope:"page"});bH[bJ].q=[];for(;bH.zaraz.q.length;){const bU=bH.zaraz.q.shift();bH[bJ].q.push(bU)}bP.defer=!0;for(const bV of[localStorage,sessionStorage])Object.keys(bV||{}).filter(bX=>bX.startsWith("_zaraz_")).forEach(bW=>{try{bH[bJ]["z_"+bW.slice(7)]=JSON.parse(bV.getItem(bW))}catch{bH[bJ]["z_"+bW.slice(7)]=bV.getItem(bW)}});bP.referrerPolicy="origin";bP.src="/cdn-cgi/zaraz/s.js?z="+btoa(encodeURIComponent(JSON.stringify(bH[bJ])));bO.parentNode.insertBefore(bP,bO)};["complete","interactive"].includes(bI.readyState)?zaraz.init():bH.addEventListener("DOMContentLoaded",zaraz.init)}}(w,d,"zarazData","script");window.zaraz._p=async bc=>new Promise(bd=>{if(bc){bc.e&&bc.e.forEach(be=>{try{const bf=d.querySelector("script[nonce]"),bg=bf?.nonce||bf?.getAttribute("nonce"),bh=d.createElement("script");bg&&(bh.nonce=bg);bh.innerHTML=be;bh.onload=()=>{d.head.removeChild(bh)};d.head.appendChild(bh)}catch(bi){console.error(`Error executing script: ${be}\n`,bi)}});Promise.allSettled((bc.f||[]).map(bj=>fetch(bj[0],bj[1])))}bd()});zaraz._p({"e":["(function(w,d){})(window,document)"]});})(window,document)}catch(e){throw fetch("/cdn-cgi/zaraz/t"),e;};</script><script data-cfasync="false" nonce="d6c4a35e-09e6-484b-a2aa-21194742b1b5">try{(function(w,d){!function(bH,bI,bJ,bK){if(bH.zaraz)console.error("zaraz is loaded twice");else{bH[bJ]=bH[bJ]||{};bH[bJ].executed=[];bH.zaraz={deferred:[],listeners:[]};bH.zaraz._v="5876";bH.zaraz._n="d6c4a35e-09e6-484b-a2aa-21194742b1b5";bH.zaraz.q=[];bH.zaraz._f=function(bL){return async function(){var bM=Array.prototype.slice.call(arguments);bH.zaraz.q.push({m:bL,a:bM})}};for(const bN of["track","set","debug"])bH.zaraz[bN]=bH.zaraz._f(bN);bH.zaraz.init=()=>{var bO=bI.getElementsByTagName(bK)[0],bP=bI.createElement(bK),bQ=bI.getElementsByTagName("title")[0];bQ&&(bH[bJ].t=bI.getElementsByTagName("title")[0].text);bH[bJ].x=Math.random();bH[bJ].w=bH.screen.width;bH[bJ].h=bH.screen.height;bH[bJ].j=bH.innerHeight;bH[bJ].e=bH.innerWidth;bH[bJ].l=bH.location.href;bH[bJ].r=bI.referrer;bH[bJ].k=bH.screen.colorDepth;bH[bJ].n=bI.characterSet;bH[bJ].o=(new Date).getTimezoneOffset();if(bH.dataLayer)for(const bR of Object.entries(Object.entries(dataLayer).reduce((bS,bT)=>({...bS[1],...bT[1]}),{})))zaraz.set(bR[0],bR[1],{scope:"page"});bH[bJ].q=[];for(;bH.zaraz.q.length;){const bU=bH.zaraz.q.shift();bH[bJ].q.push(bU)}bP.defer=!0;for(const bV of[localStorage,sessionStorage])Object.keys(bV||{}).filter(bX=>bX.startsWith("_zaraz_")).forEach(bW=>{try{bH[bJ]["z_"+bW.slice(7)]=JSON.parse(bV.getItem(bW))}catch{bH[bJ]["z_"+bW.slice(7)]=bV.getItem(bW)}});bP.referrerPolicy="origin";bP.src="/cdn-cgi/zaraz/s.js?z="+btoa(encodeURIComponent(JSON.stringify(bH[bJ])));bO.parentNode.insertBefore(bP,bO)};["complete","interactive"].includes(bI.readyState)?zaraz.init():bH.addEventListener("DOMContentLoaded",zaraz.init)}}(w,d,"zarazData","script");window.zaraz._p=async bc=>new Promise(bd=>{if(bc){bc.e&&bc.e.forEach(be=>{try{const bf=d.querySelector("script[nonce]"),bg=bf?.nonce||bf?.getAttribute("nonce"),bh=d.createElement("script");bg&&(bh.nonce=bg);bh.innerHTML=be;bh.onload=()=>{d.head.removeChild(bh)};d.head.appendChild(bh)}catch(bi){console.error(`Error executing script: ${be}\n`,bi)}});Promise.allSettled((bc.f||[]).map(bj=>fetch(bj[0],bj[1])))}bd()});zaraz._p({"e":["(function(w,d){})(window,document)"]});})(window,document)}catch(e){throw fetch("/cdn-cgi/zaraz/t"),e;};</script></head>

<body class="home wp-singular page-template page-template-page-templates page-template-page-home page-template-page-templatespage-home-php page page-id-9 wp-theme-bootscore-main wp-child-theme-bootscore-child-main-new mega-menu-main-menu no-sidebar">


<div id="page" class="site">
  <header id="masthead" class="site-header">
	<div class="top-header container">
		<a href="https://dxboffplan.com/" class="top-head-logo">
		<img src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/logo/dxboffplan-logo-b.png" data-no-lazy="1" width="200" height="45">
		</a>
		<div class="langs">
			
<div style="text-transform: uppercase;" class="md-lang-sel sel-dropdown"><ul class="select-lng">
<li class="lang-en active qtranschangelang"><a href="https://dxboffplan.com/" hreflang="en" title="English (en)" ><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/en.svg" /><noscript><img src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/en.svg" /></noscript></a></li>
<li class="lang-ar qtranschangelang"><a href="https://dxboffplan.com/ar/" hreflang="ar" title="العربية (ar)" ><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/ar.svg" /><noscript><img src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/ar.svg" /></noscript></a></li>
<li class="lang-fa qtranschangelang"><a href="https://dxboffplan.com/fa/" hreflang="fa" title="فارسی (fa)" ><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/fa.svg" /><noscript><img src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/fa.svg" /></noscript></a></li>
<li class="lang-ru qtranschangelang"><a href="https://dxboffplan.com/ru/" hreflang="ru" title="Русский (ru)" ><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/ru.svg" /><noscript><img src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/ru.svg" /></noscript></a></li>
<li class="lang-tr qtranschangelang"><a href="https://dxboffplan.com/tr/" hreflang="tr" title="Turkish (tr)" ><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/tr.svg" /><noscript><img src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/flags/tr.svg" /></noscript></a></li>
</ul></div><div class="qtranxs_widget_end"></div>
		</div>
	  </div>
	  <nav class="navbar-nav main-nav">
		  <div class="main-menu container">
			  
		  
	  <div id="mega-menu-wrap-main-menu" class="mega-menu-wrap"><div class="mega-menu-toggle"><div class="mega-toggle-blocks-left"><div class='mega-toggle-block mega-menu-toggle-block mega-toggle-block-1' id='mega-toggle-block-1'><span class='mega-toggle-label' role='button' aria-haspopup='true' aria-expanded='false'><span class='mega-toggle-label-closed'>MENU</span><span class='mega-toggle-label-open'>MENU</span></span></div></div><div class="mega-toggle-blocks-center"></div><div class="mega-toggle-blocks-right"><div class='mega-toggle-block mega-menu-toggle-animated-block mega-toggle-block-2' id='mega-toggle-block-2'><button aria-label="Toggle Menu" class="mega-toggle-animated mega-toggle-animated-slider" type="button" aria-haspopup="true" aria-expanded="false" aria-controls="mega-menu-main-menu">
                  <span class="mega-toggle-animated-box">
                    <span class="mega-toggle-animated-inner"></span>
                  </span>
                </button></div></div></div><ul id="mega-menu-main-menu" class="mega-menu max-mega-menu mega-menu-horizontal mega-no-js" data-event="hover_intent" data-effect="fade_up" data-effect-speed="200" data-effect-mobile="disabled" data-effect-speed-mobile="0" data-mobile-force-width="false" data-second-click="go" data-document-click="collapse" data-vertical-behaviour="standard" data-breakpoint="768" data-unbind="true" data-mobile-state="collapse_all" data-mobile-direction="vertical" data-hover-intent-timeout="300" data-hover-intent-interval="100"><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-home mega-current-menu-item mega-page_item mega-page-item-9 mega-current_page_item mega-align-bottom-left mega-menu-flyout mega-menu-item-92" id="mega-menu-item-92"><a class="mega-menu-link" href="https://dxboffplan.com/" aria-current="page">Home</a></li><li class="mega-off-mobile mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-has-children mega-menu-megamenu mega-menu-grid mega-align-bottom-left mega-menu-grid mega-menu-item-2543 off-mobile" id="mega-menu-item-2543"><a class="mega-menu-link" href="https://dxboffplan.com/offplan-projects/" aria-expanded="false" aria-controls="mega-sub-menu-2543">All Projects<span class="mega-indicator" aria-hidden="true"></span></a>
<ul class="mega-sub-menu" role='presentation' id='mega-sub-menu-2543'>
<li class="mega-menu-row" id="mega-menu-2543-0">
	<ul class="mega-sub-menu" style='--columns:12' role='presentation'>
<li class="mega-menu-column mega-menu-columns-6-of-12" style="--columns:12; --span:6" id="mega-menu-2543-0-0">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-country mega-menu-item-has-children mega-menu-item-58151" id="mega-menu-item-58151"><a class="mega-menu-link" href="https://dxboffplan.com/country/uae/">Property For Sale In UAE<span class="mega-indicator" aria-hidden="true"></span></a>
			<ul class="mega-sub-menu" id='mega-sub-menu-58151'>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-10922" id="mega-menu-item-10922"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-dubai/">Property For Sale In Dubai</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-12975" id="mega-menu-item-12975"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-abu-dhabi/">Property For Sale In Abu Dhabi</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-14370" id="mega-menu-item-14370"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-ajman/">Property For Sale In Ajman</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-15147" id="mega-menu-item-15147"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-ras-al-khaimah/">Property For Sale In Ras Al Khaimah</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-90782" id="mega-menu-item-90782"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-umm-al-quwain/">Property for Sale in Umm Al Quwain</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-12976" id="mega-menu-item-12976"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-sharjah/">Property For Sale In Sharjah</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-90781" id="mega-menu-item-90781"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-fujairah/">Property for Sale in Fujairah</a></li>			</ul>
</li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-country mega-menu-item-has-children mega-menu-item-58149" id="mega-menu-item-58149"><a class="mega-menu-link" href="https://dxboffplan.com/country/turkey/">Property For Sale In Turkey<span class="mega-indicator" aria-hidden="true"></span></a>
			<ul class="mega-sub-menu" id='mega-sub-menu-58149'>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58154" id="mega-menu-item-58154"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-alanya/">Property For Sale In Alanya</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58165" id="mega-menu-item-58165"><a class="mega-menu-link" href="https://dxboffplan.com/propety-for-sale-in-antalya/">Property For Sale In Antalya</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58152" id="mega-menu-item-58152"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-bodrum/">Property For Sale In Bodrum</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58153" id="mega-menu-item-58153"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-bursa/">Property For Sale In Bursa</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58156" id="mega-menu-item-58156"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-istanbul/">Property For Sale In Istanbul</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58162" id="mega-menu-item-58162"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-trabzon/">Property For Sale In Trabzon</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58163" id="mega-menu-item-58163"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-yalova/">Property For Sale In Yalova</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58164" id="mega-menu-item-58164"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-izmir/">Property For Sale In Izmir</a></li>			</ul>
</li>		</ul>
</li><li class="mega-menu-column mega-menu-columns-6-of-12" style="--columns:12; --span:6" id="mega-menu-2543-0-1">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-country mega-menu-item-has-children mega-menu-item-58150" id="mega-menu-item-58150"><a class="mega-menu-link" href="https://dxboffplan.com/country/oman/">Property For Sale In Oman<span class="mega-indicator" aria-hidden="true"></span></a>
			<ul class="mega-sub-menu" id='mega-sub-menu-58150'>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58159" id="mega-menu-item-58159"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-muscat/">Property For Sale In Muscat</a></li>			</ul>
</li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-country mega-menu-item-has-children mega-menu-item-58147" id="mega-menu-item-58147"><a class="mega-menu-link" href="https://dxboffplan.com/country/georgia/">Property For Sale In Georgia<span class="mega-indicator" aria-hidden="true"></span></a>
			<ul class="mega-sub-menu" id='mega-sub-menu-58147'>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-58161" id="mega-menu-item-58161"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-tbilisi/">Property For Sale In Tbilisi</a></li>			</ul>
</li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-country mega-menu-item-has-children mega-menu-item-68564" id="mega-menu-item-68564"><a class="mega-menu-link" href="https://dxboffplan.com/country/north-cyprus/">Properties for sale in North Cyprus<span class="mega-indicator" aria-hidden="true"></span></a>
			<ul class="mega-sub-menu" id='mega-sub-menu-68564'>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-68571" id="mega-menu-item-68571"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-famagusta/">Property for sale in Famagusta, Northern Cyprus</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-68566" id="mega-menu-item-68566"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-iskele/">Properties for sale in Iskele</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-68572" id="mega-menu-item-68572"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-kyrenia/">Properties for sale in Kyrenia</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-68570" id="mega-menu-item-68570"><a class="mega-menu-link" href="https://dxboffplan.com/property-for-sale-in-nicosia/">Properties for sale in Lefkoşa</a></li>			</ul>
</li>		</ul>
</li>	</ul>
</li></ul>
</li><li class="mega-off-mobile mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-menu-item-105 off-mobile" id="mega-menu-item-105"><a class="mega-menu-link" href="https://dxboffplan.com/developers/" aria-expanded="false" aria-controls="mega-sub-menu-105">Developers<span class="mega-indicator" aria-hidden="true"></span></a>
<ul class="mega-sub-menu" id='mega-sub-menu-105'>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-14371" id="mega-menu-item-14371"><a class="mega-menu-link" href="https://dxboffplan.com/list-of-property-developers-in-uae/">Best Developers In Dubai</a></li></ul>
</li><li class="mega-off-mobile mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-menu-item-1575 off-mobile" id="mega-menu-item-1575"><a class="mega-menu-link" href="https://dxboffplan.com/developments/" aria-expanded="false" aria-controls="mega-sub-menu-1575">Developments<span class="mega-indicator" aria-hidden="true"></span></a>
<ul class="mega-sub-menu" id='mega-sub-menu-1575'>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-15202" id="mega-menu-item-15202"><a class="mega-menu-link" href="https://dxboffplan.com/dubai-developments/">Dubai Developments</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-15204" id="mega-menu-item-15204"><a class="mega-menu-link" href="https://dxboffplan.com/abu-dhabi-developments/">Abu Dhabi Developments</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-15201" id="mega-menu-item-15201"><a class="mega-menu-link" href="https://dxboffplan.com/ajman-developments/">Ajman Developments</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-90783" id="mega-menu-item-90783"><a class="mega-menu-link" href="https://dxboffplan.com/umm-al-quwain-developments/">Umm Al Quwain Developments</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-15203" id="mega-menu-item-15203"><a class="mega-menu-link" href="https://dxboffplan.com/sharjah-developments/">Sharjah Developments</a></li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-15200" id="mega-menu-item-15200"><a class="mega-menu-link" href="https://dxboffplan.com/ras-al-khaimah-developments/">Ras Al Khaimah Developments</a></li></ul>
</li><li class="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-menu-item-94150" id="mega-menu-item-94150"><a class="mega-menu-link" href="https://dxboffplan.com/blog/" aria-expanded="false" aria-controls="mega-sub-menu-94150">Blog<span class="mega-indicator" aria-hidden="true"></span></a>
<ul class="mega-sub-menu" id='mega-sub-menu-94150'>
<li class="mega-menu-item mega-menu-item-type-taxonomy mega-menu-item-object-category mega-menu-item-has-children mega-menu-item-76388" id="mega-menu-item-76388"><a class="mega-menu-link" href="https://dxboffplan.com/category/uae/" aria-expanded="false" aria-controls="mega-sub-menu-76388">UAE Blog Posts<span class="mega-indicator" aria-hidden="true"></span></a>
	<ul class="mega-sub-menu" id='mega-sub-menu-76388'>
<li class="mega-menu-item mega-menu-item-type-taxonomy mega-menu-item-object-category mega-menu-item-76386" id="mega-menu-item-76386"><a class="mega-menu-link" href="https://dxboffplan.com/category/uae/buying/">Buying real estate</a></li><li class="mega-menu-item mega-menu-item-type-taxonomy mega-menu-item-object-category mega-menu-item-76385" id="mega-menu-item-76385"><a class="mega-menu-link" href="https://dxboffplan.com/category/uae/immigration/">Immigration</a></li><li class="mega-menu-item mega-menu-item-type-taxonomy mega-menu-item-object-category mega-menu-item-76384" id="mega-menu-item-76384"><a class="mega-menu-link" href="https://dxboffplan.com/category/uae/life-conditions/">Life conditions</a></li><li class="mega-menu-item mega-menu-item-type-taxonomy mega-menu-item-object-category mega-menu-item-76383" id="mega-menu-item-76383"><a class="mega-menu-link" href="https://dxboffplan.com/category/uae/area/">Area guide</a></li><li class="mega-menu-item mega-menu-item-type-taxonomy mega-menu-item-object-category mega-menu-item-86160" id="mega-menu-item-86160"><a class="mega-menu-link" href="https://dxboffplan.com/category/uae/news/">News</a></li>	</ul>
</li></ul>
</li><li class="mega-qtranxs-lang-menu mega-qtranxs-lang-menu-en mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-current-menu-parent mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-menu-item-82345 qtranxs-lang-menu qtranxs-lang-menu-en" id="mega-menu-item-82345"><a title="English" class="mega-menu-link" href="#" aria-expanded="false" aria-controls="mega-sub-menu-82345">Language:&nbsp;<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="English" data-lazy-src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/gb.png" /><noscript><img src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/gb.png" alt="English" /></noscript><span class="mega-indicator" aria-hidden="true"></span></a>
<ul class="mega-sub-menu" id='mega-sub-menu-82345'>
<li class="mega-qtranxs-lang-menu-item mega-qtranxs-lang-menu-item-en mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-current-menu-item mega-current_page_item mega-menu-item-home mega-menu-item-94151 qtranxs-lang-menu-item qtranxs-lang-menu-item-en" id="mega-menu-item-94151"><a title="English" class="mega-menu-link" href="https://dxboffplan.com/" aria-current="page"><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="English" data-lazy-src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/gb.png" /><noscript><img src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/gb.png" alt="English" /></noscript>&nbsp;English</a></li><li class="mega-qtranxs-lang-menu-item mega-qtranxs-lang-menu-item-ar mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-94152 qtranxs-lang-menu-item qtranxs-lang-menu-item-ar" id="mega-menu-item-94152"><a title="العربية" class="mega-menu-link" href="https://dxboffplan.com/ar/"><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="العربية" data-lazy-src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/arle.png" /><noscript><img src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/arle.png" alt="العربية" /></noscript>&nbsp;العربية</a></li><li class="mega-qtranxs-lang-menu-item mega-qtranxs-lang-menu-item-fa mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-94153 qtranxs-lang-menu-item qtranxs-lang-menu-item-fa" id="mega-menu-item-94153"><a title="فارسی" class="mega-menu-link" href="https://dxboffplan.com/fa/"><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="فارسی" data-lazy-src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/ir.png" /><noscript><img src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/ir.png" alt="فارسی" /></noscript>&nbsp;فارسی</a></li><li class="mega-qtranxs-lang-menu-item mega-qtranxs-lang-menu-item-ru mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-94154 qtranxs-lang-menu-item qtranxs-lang-menu-item-ru" id="mega-menu-item-94154"><a title="Русский" class="mega-menu-link" href="https://dxboffplan.com/ru/"><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="Русский" data-lazy-src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/ru.png" /><noscript><img src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/ru.png" alt="Русский" /></noscript>&nbsp;Русский</a></li><li class="mega-qtranxs-lang-menu-item mega-qtranxs-lang-menu-item-tr mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-94155 qtranxs-lang-menu-item qtranxs-lang-menu-item-tr" id="mega-menu-item-94155"><a title="Turkish" class="mega-menu-link" href="https://dxboffplan.com/tr/"><img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="Turkish" data-lazy-src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/tr.png" /><noscript><img src="https://dxboffplan.com/wp-content/plugins/qtranslate-x/flags/tr.png" alt="Turkish" /></noscript>&nbsp;Turkish</a></li></ul>
</li></ul></div>			  </div>
	  </nav>
    <!-- Offcanvas User and Cart -->
    
  </header><!-- #masthead -->

  <div id="content" class="site-content">
    <div id="primary" class=" content-area">

      <!-- Hook to add something nice -->
      
      <main id="main" class="site-main home container">

        <div class="entry-content my-3">
			<h1 class="home-p-title">
							</h1>
          <picture class="home-slide">
          <!--<source media="(min-width:650px)" srcset="img_pink_flowers.jpg">-->
          <!--<source media="(min-width:465px)" srcset="img_white_flower.jpg">-->
          <img class="main border-home-slide" src="https://dxboffplan.com/wp-content/uploads/2024/10/dxbhi.png" data-no-lazy="1" width="1300" height="577" alt="DXBOFFPLAN">
        </picture>
<!-- 		Search Form -->
			<section class="home-search">
	                <form method="GET"  action="/" class="search-form">
            <div class="search-price">
                <div class="row">
                    <div class="col-md-2 mb-3 mb-md-0">
                        Price Range                    </div>
                    <div class="col-md-8">
                        <div class="price-slider-range">
                        <div class="price-input">
                            <div class="field">
								<span class="minus" data-target="min-price">-</span>
                              <input type="text" class="input-min" value="0" readonly>
                              <span class="plus" data-target="min-price">+</span>
                            </div>
                        </div>
                        <div class="slide-range">
                        <div class="slider">
                            <div class="progress"></div>
                        </div>
							                        <div class="range-input">
                            <input type="range" id="min-price" value="0" class="range-min" name="min-price" min="0" max="250000000" step="1000">
                            <input type="range" id="max-price" class="range-max" name="max-price" min="0" max="250000000" value="250000000" step="1000">
                        </div>
                        </div>
                        <div class="price-input">
                            <div class="field">
								<span class="minus" data-target="max-price">-</span>
                              <input type="text" class="input-max" value="250000000 " readonly>
								<span class="plus" data-target="max-price">+</span>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card border-0 shadow-sm p-3">
                    <div class="row">
                        <div class="col-md-8 mb-3 position-relative">
							<!-- Search Button Outline Secondary Right -->
<div class="searchform input-group">
  <input id="search-text" type="text" name="s" class="form-control homesearchinput" autocomplete="off" placeholder="Search" data-lang="en">
	<div class="ssgs">
		
	</div>
</div>
                        </div>
                        <div class="col-md-2 mb-3 d-none d-md-block">
                             <p class="btn w-100 border-light rounded-pill filterstoggle">
                                 <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17.778" viewBox="0 0 20 17.778">
                                  <g id="Iconly_Bulk_Filter" data-name="Iconly/Bulk/Filter" transform="translate(-2 -3)">
                                    <g id="Filter" transform="translate(2 3)">
                                      <path id="Fill-1" d="M8.083,12.958H1.508a1.482,1.482,0,1,0,0,2.963H8.083a1.482,1.482,0,1,0,0-2.963" opacity="0.4"/>
                                      <path id="Fill-4" d="M20,3.379A1.5,1.5,0,0,0,18.493,1.9H11.918a1.481,1.481,0,1,0,0,2.962h6.575A1.5,1.5,0,0,0,20,3.379" opacity="0.4"/>
                                      <path id="Fill-6" d="M6.878,3.379a3.409,3.409,0,0,1-3.439,3.38A3.41,3.41,0,0,1,0,3.379,3.41,3.41,0,0,1,3.439,0,3.409,3.409,0,0,1,6.878,3.379"/>
                                      <path id="Fill-9" d="M20,14.4a3.439,3.439,0,1,1-3.439-3.38A3.409,3.409,0,0,1,20,14.4"/>
                                    </g>
                                  </g>
                                </svg>
                                Filters                             </p>
                        </div>
                        <div class="col-md-2 f-hi mb-3"></div>
                        <div class="col-md-2 f-hi col-6 mb-3 position-relative" id="country-sel">
                            <select class="form-select" id="country" name="scountry">
								                                <option value="">All Countries</option>
																<option value="uae"  > UAE </option>
																<option value="latvia"  > Latvia </option>
																<option value="turkey"  > Turkey </option>
																<option value="oman"  > Oman </option>
																<option value="albania"  > Albania </option>
																<option value="jordan"  > Jordan </option>
																<option value="serbia"  > Serbia </option>
																<option value="qatar"  > Qatar </option>
																<option value="saudi-arabia"  > Saudi Arabia </option>
																<option value="bahrain"  > Bahrain </option>
																<option value="ethiopia"  > Ethiopia </option>
																<option value="united-kingdom"  > United Kingdom </option>
																<option value="morocco"  > Morocco </option>
																<option value="indonesia"  > Indonesia </option>
																<option value="spain"  > Spain </option>
																<option value="north-cyprus"  > North Cyprus </option>
																<option value="georgia"  > Georgia </option>
																<option value="egypt"  > Egypt </option>
								                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="20" viewBox="0 0 14 20" class="position-absolute">
                              <g id="Iconly_Bulk_Location" data-name="Iconly/Bulk/Location" transform="translate(-5 -2)">
                                <g id="Location" transform="translate(5 2)">
                                  <path id="Path_34175" d="M3.532.937a6.889,6.889,0,0,1,7.035.058A7.331,7.331,0,0,1,14,7.261a10.558,10.558,0,0,1-3.192,6.775,18.727,18.727,0,0,1-3.359,2.82A1.174,1.174,0,0,1,7.041,17a.82.82,0,0,1-.391-.119,18.515,18.515,0,0,1-4.838-4.547A9.279,9.279,0,0,1,0,7.134H0l0-.274A7.15,7.15,0,0,1,3.532.937Zm4.376,4.1a2.346,2.346,0,0,0-2.594.52,2.455,2.455,0,0,0-.519,2.64,2.378,2.378,0,0,0,2.2,1.5,2.339,2.339,0,0,0,1.683-.7,2.455,2.455,0,0,0-.768-3.956Z" fill="#b3bbc7"/>
                                  <ellipse id="Ellipse_743" cx="5" cy="1" rx="5" ry="1" transform="translate(2 18)" fill="#b3bbc7" opacity="0.4"/>
                                </g>
                              </g>
                            </svg>
                        </div>
                        <div class="col-md-2 f-hi col-6 mb-3 position-relative" id="city-sel">
                            <select class="form-select" id="city" name="scity" >
                                <option value="">All Cities</option>
																<option disabled> Please Select Country </option>
								                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="20" viewBox="0 0 14 20" class="position-absolute">
                              <g id="Iconly_Bulk_Location" data-name="Iconly/Bulk/Location" transform="translate(-5 -2)">
                                <g id="Location" transform="translate(5 2)">
                                  <path id="Path_34175" d="M3.532.937a6.889,6.889,0,0,1,7.035.058A7.331,7.331,0,0,1,14,7.261a10.558,10.558,0,0,1-3.192,6.775,18.727,18.727,0,0,1-3.359,2.82A1.174,1.174,0,0,1,7.041,17a.82.82,0,0,1-.391-.119,18.515,18.515,0,0,1-4.838-4.547A9.279,9.279,0,0,1,0,7.134H0l0-.274A7.15,7.15,0,0,1,3.532.937Zm4.376,4.1a2.346,2.346,0,0,0-2.594.52,2.455,2.455,0,0,0-.519,2.64,2.378,2.378,0,0,0,2.2,1.5,2.339,2.339,0,0,0,1.683-.7,2.455,2.455,0,0,0-.768-3.956Z" fill="#b3bbc7"/>
                                  <ellipse id="Ellipse_743" cx="5" cy="1" rx="5" ry="1" transform="translate(2 18)" fill="#b3bbc7" opacity="0.4"/>
                                </g>
                              </g>
                            </svg>
                        </div>
                        <div class="col-md-2 f-hi col-6 mb-3 position-relative">
                            <select class="form-select" id="development" name="sdevelopment">
                                <option value="">Development</option>
								<option disabled> Please Select City </option>
								                            </select>
                        </div>
						                        
                        <div class="col-md-2 f-hi col-6 mb-3 position-relative">
							<select class="form-select" name="type">
								 <option value="">All Types</option>
								<option value="Apartments"  >Apartments</option>
								<option value="Villas"  >Villas</option>
								<option value="Townhouses"  >Townhouses</option>
								<option value="Shops"  >Shops</option>
								<option value="Plots"  >Plots</option>
								<option value="Buildings"  >Buildings</option>
								<option value="Full floor"  >Full floor</option>
								<option value="Bulk Deals"  >Bulk Deals</option>
                            </select>
                        </div>
						<div class="col-md-2 f-hi col-6 mb-3 position-relative">
                            <select class="form-select" name="bedrooms">
                                <option value="">Bed Rooms</option>
								<option value="1"  >1BR</option>
								<option value="2"  >2BR</option>
								<option value="3"  >3BR</option>
								<option value="4"  >4BR</option>
								<option value="5"  >5BR</option>
                            </select>
                        </div>
						<div class="col-6 d-md-none mb-3">
							<p class="w-100 form-control filterstoggle">
                                 <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17.778" viewBox="0 0 20 17.778">
                                  <g id="Iconly_Bulk_Filter" data-name="Iconly/Bulk/Filter" transform="translate(-2 -3)">
                                    <g id="Filter" transform="translate(2 3)">
                                      <path id="Fill-1" d="M8.083,12.958H1.508a1.482,1.482,0,1,0,0,2.963H8.083a1.482,1.482,0,1,0,0-2.963" opacity="0.4"/>
                                      <path id="Fill-4" d="M20,3.379A1.5,1.5,0,0,0,18.493,1.9H11.918a1.481,1.481,0,1,0,0,2.962h6.575A1.5,1.5,0,0,0,20,3.379" opacity="0.4"/>
                                      <path id="Fill-6" d="M6.878,3.379a3.409,3.409,0,0,1-3.439,3.38A3.41,3.41,0,0,1,0,3.379,3.41,3.41,0,0,1,3.439,0,3.409,3.409,0,0,1,6.878,3.379"/>
                                      <path id="Fill-9" d="M20,14.4a3.439,3.439,0,1,1-3.439-3.38A3.409,3.409,0,0,1,20,14.4"/>
                                    </g>
                                  </g>
                                </svg>
                                Filters                             </p>
						</div>
                        <div class="col-md-2">
                            <button class="btn btn-dark w-100"> Search </button>
                        </div>
                    </div>
                
            </div>
				</form>
        </section><!-- 		End Search Form -->
        </div>
        <div data-bg="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/home-bg.png" class="home-top-bg rocket-lazyload" style=""></div>
		  		  <section class="best-cities">
			 <div class="best-cities-inner">
				 <div class=" top-projects d-flex gap-3 mb-3 align-items-center">
				 			<div class="first">
<svg xmlns="http://www.w3.org/2000/svg" width="25" height="23.748" viewBox="0 0 25 23.748">
  <path id="Path_1355" data-name="Path 1355" d="M19.9,14.773a1.376,1.376,0,0,0-.4,1.212l1.111,6.149a1.35,1.35,0,0,1-.562,1.35,1.376,1.376,0,0,1-1.462.1L13.048,20.7a1.413,1.413,0,0,0-.625-.164h-.339a1.015,1.015,0,0,0-.337.112l-5.537,2.9a1.46,1.46,0,0,1-.887.137A1.389,1.389,0,0,1,4.211,22.1l1.112-6.149a1.4,1.4,0,0,0-.4-1.224L.411,10.349A1.349,1.349,0,0,1,.075,8.936,1.4,1.4,0,0,1,1.186,8L7.4,7.1a1.39,1.39,0,0,0,1.1-.761L11.235.725a1.3,1.3,0,0,1,.25-.337L11.6.3a.839.839,0,0,1,.2-.162l.136-.05L12.147,0h.526a1.4,1.4,0,0,1,1.1.75l2.773,5.587a1.389,1.389,0,0,0,1.037.761L23.8,8a1.417,1.417,0,0,1,1.137.937,1.358,1.358,0,0,1-.362,1.412Z" transform="translate(0 0)" fill="var(--color-yellow)"/>
</svg>

			</div>
				 <div class="inside container d-flex flex-column w-auto m-0">
					 <h2 class="inside-title">
						 Most Popular						 <span class="d-block">
							 Cities						 </span>
					 </h2>
				 </div>						 
					 				 <div class="select-cities m-auto">
					 					 <button type="button" class="item btn active" data-country="uae ">
						 UAE					 </button>
					 					 <button type="button" class="item btn " data-country="latvia ">
						 Latvia					 </button>
					 					 <button type="button" class="item btn " data-country="turkey ">
						 Turkey					 </button>
					 					 <button type="button" class="item btn " data-country="oman ">
						 Oman					 </button>
					 					 <button type="button" class="item btn " data-country="albania ">
						 Albania					 </button>
					 					 <button type="button" class="item btn " data-country="jordan ">
						 Jordan					 </button>
					 					 <button type="button" class="item btn " data-country="serbia ">
						 Serbia					 </button>
					 					 <button type="button" class="item btn " data-country="qatar ">
						 Qatar					 </button>
					 					 <button type="button" class="item btn " data-country="saudi-arabia ">
						 Saudi Arabia					 </button>
					 					 <button type="button" class="item btn " data-country="bahrain ">
						 Bahrain					 </button>
					 					 <button type="button" class="item btn " data-country="ethiopia ">
						 Ethiopia					 </button>
					 					 <button type="button" class="item btn " data-country="united-kingdom ">
						 United Kingdom					 </button>
					 					 <button type="button" class="item btn " data-country="morocco ">
						 Morocco					 </button>
					 					 <button type="button" class="item btn " data-country="indonesia ">
						 Indonesia					 </button>
					 					 <button type="button" class="item btn " data-country="spain ">
						 Spain					 </button>
					 					 <button type="button" class="item btn " data-country="north-cyprus ">
						 North Cyprus					 </button>
					 					 <button type="button" class="item btn " data-country="georgia ">
						 Georgia					 </button>
					 					 <button type="button" class="item btn " data-country="egypt ">
						 Egypt					 </button>
					 				 </div>
				 </div>

				 <div class="all-cities" id="home-all-cities">
					 <div class="top-cities row"><div class="col-md-4 col-12 mb-3">
	<div class="city-item">
		<a class="body" href="property-for-sale-dubai" rel="nofollow">
			<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/01/City-Of-Dubai.jpg" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/01/City-Of-Dubai.jpg" class="img" /></noscript>
			<div class="title-div">
			<h3 class="title">
				Dubai			</h3>
			</div>
		</a>
		<div class="city-footer">
						<a href="https://dxboffplan.com/new/apartments-for-sale-dubai/">
			Apartment for sale in Dubai			</a>
						<a href="https://dxboffplan.com/new/villas-for-sale-dubai/">
			Villa for sale in Dubai			</a>
						<a href="https://dxboffplan.com/new/townhouses-for-sale-dubai/">
			Townhouse for sale in Dubai			</a>
						<a href="https://dxboffplan.com/new/lands-for-sale-dubai/">
			Land for sale in Dubai			</a>
						<a href="https://dxboffplan.com/new/shops-for-sale-dubai/">
			Shop for sale in Dubai			</a>
					</div>
	</div>	
</div>
<div class="col-md-4 col-12 mb-3">
	<div class="city-item">
		<a class="body" href="property-for-sale-abu-dhabi" rel="nofollow">
			<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2023/01/abu-dhabi-photos.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2023/01/abu-dhabi-photos.png" class="img" /></noscript>
			<div class="title-div">
			<h3 class="title">
				Abu Dhabi			</h3>
			</div>
		</a>
		<div class="city-footer">
						<a href="https://dxboffplan.com/new/apartments-for-sale-abu-dhabi/">
			Apartment for sale in Abu Dhabi			</a>
						<a href="https://dxboffplan.com/new/villas-for-sale-abu-dhabi/">
			Villa for sale in Abu Dhabi			</a>
						<a href="https://dxboffplan.com/new/townhouses-for-sale-abu-dhabi/">
			Townhouse for sale in Abu Dhabi			</a>
						<a href="https://dxboffplan.com/new/lands-for-sale-abu-dhabi/">
			Land for sale in Abu Dhabi			</a>
						<a href="https://dxboffplan.com/new/hotel-apartments-for-sale-abu-dhabi/">
			Hotel Apartment for sale in Abu Dhabi			</a>
					</div>
	</div>	
</div>
<div class="col-md-4 col-12 mb-3">
	<div class="city-item">
		<a class="body" href="property-for-sale-ras-al-khaimah" rel="nofollow">
			<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/01/City-of-Ras-Al-Khaimah.jpg" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/01/City-of-Ras-Al-Khaimah.jpg" class="img" /></noscript>
			<div class="title-div">
			<h3 class="title">
				Ras Al Khaimah			</h3>
			</div>
		</a>
		<div class="city-footer">
						<a href="https://dxboffplan.com/new/apartments-for-sale-ras-al-khaimah/">
			Apartment for sale in Ras Al Khaimah			</a>
						<a href="https://dxboffplan.com/new/villas-for-sale-ras-al-khaimah/">
			Villa for sale in Ras Al Khaimah			</a>
						<a href="https://dxboffplan.com/new/townhouses-for-sale-ras-al-khaimah/">
			Townhouse for sale in Ras Al Khaimah			</a>
						<a href="https://dxboffplan.com/new/land-for-sale-ras-al-khaimah/">
			Land for sale in Ras Al Khaimah			</a>
					</div>
	</div>	
</div>
<div class="col-md-4 col-12 mb-3">
	<div class="city-item">
		<a class="body" href="property-for-sale-umm-al-quwain" rel="nofollow">
			<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/07/Umm-Al-Quwain-Photo-.jpeg" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/07/Umm-Al-Quwain-Photo-.jpeg" class="img" /></noscript>
			<div class="title-div">
			<h3 class="title">
				Umm Al Quwain			</h3>
			</div>
		</a>
		<div class="city-footer">
						<a href="https://dxboffplan.com/new/apartments-for-sale-umm-al-quwain/">
			Apartment for sale in Umm Al Quwain			</a>
						<a href="https://dxboffplan.com/new/villas-for-sale-umm-al-quwain/">
			Villa for sale in Umm Al Quwain			</a>
					</div>
	</div>	
</div>
<div class="col-md-4 col-12 mb-3">
	<div class="city-item">
		<a class="body" href="property-for-sale-ajman" rel="nofollow">
			<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/01/City-of-Ajman.jpg" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/01/City-of-Ajman.jpg" class="img" /></noscript>
			<div class="title-div">
			<h3 class="title">
				Ajman			</h3>
			</div>
		</a>
		<div class="city-footer">
						<a href="https://dxboffplan.com/new/apartments-for-sale-ajman/">
			Apartment for sale in Ajman			</a>
						<a href="https://dxboffplan.com/new/land-for-sale-ajman/">
			Land for sale in Ajman			</a>
						<a href="https://dxboffplan.com/new/villas-for-sale-ajman/">
			Villa for sale in Ajman			</a>
					</div>
	</div>	
</div>
<div class="col-md-4 col-12 mb-3">
	<div class="city-item">
		<a class="body" href="property-for-sale-sharjah" rel="nofollow">
			<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/01/City-of-Sharjah.jpg" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/01/City-of-Sharjah.jpg" class="img" /></noscript>
			<div class="title-div">
			<h3 class="title">
				Sharjah			</h3>
			</div>
		</a>
		<div class="city-footer">
						<a href="https://dxboffplan.com/new/apartments-for-sale-sharjah/">
			Apartment for sale in Sharjah			</a>
						<a href="https://dxboffplan.com/new/villas-for-sale-sharjah/">
			Villa for sale in Sharjah			</a>
						<a href="https://dxboffplan.com/new/townhouses-for-sale-sharjah/">
			Townhouse for sale in Sharjah			</a>
						<a href="https://dxboffplan.com/new/offices-for-sale-sharjah/">
			Shop for sale in Sharjah			</a>
					</div>
	</div>	
</div>
</div>				 </div>
			 </div>
		  </section>
        <section class="top-projects">
			<div class="titles">
			<div class="first">
				<svg xmlns="http://www.w3.org/2000/svg" width="25" height="26.316" viewBox="0 0 25 26.316">
  <g id="Iconly_Bulk_Home" data-name="Iconly/Bulk/Home" transform="translate(-2.5 -2)">
    <g id="Home" transform="translate(2.5 2)">
      <path id="Path_1354" data-name="Path 1354" d="M8.742,24.713V20.678a1.866,1.866,0,0,1,1.861-1.86h3.782a1.867,1.867,0,0,1,1.873,1.86h0V24.7a1.62,1.62,0,0,0,1.614,1.614h2.58A4.553,4.553,0,0,0,23.667,25,4.487,4.487,0,0,0,25,21.812V10.35a3.254,3.254,0,0,0-1.178-2.5L15.057.887A4.1,4.1,0,0,0,9.849.981L1.272,7.847A3.256,3.256,0,0,0,0,10.35V21.8a4.531,4.531,0,0,0,4.548,4.515H7.069a1.62,1.62,0,0,0,1.149-.465,1.6,1.6,0,0,0,.477-1.137Z" transform="translate(0 0)" fill="var(--color-yellow)"/>
    </g>
  </g>
</svg>
			</div>
			<div class="second">
				            <h2>
				
                <span>
                    Top 10
                </span>
                <br>
                <strong>
                    Projects
                </strong>
				            </h2>
			</div>
				</div>
            <div>
                <div class="top-posts post-navigation owl-carousel">                <div class="card property-card">
										<div class="card-header">
						                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/chelsea-residences-dubai-maritime-city/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2025/05/Chelsea-Residences-at-Dubai-Maritime-City-6.png"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2025/05/Chelsea-Residences-at-Dubai-Maritime-City-6.png" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">apartments</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2029 </span><span>Q4 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/chelsea-residences-dubai-maritime-city/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            Chelsea Residences                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Dubai - 
                               Dubai Maritime City                        </div>
																			<div class="specials-div">
													</div>
                    </div>
						<p class="ppagent-dev">
							Damac Properties						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="text-nowrap">AED 4,263,000</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
						<button class="btn btn-callback-open-loop open-contact" data-title="Chelsea Residences"
	data-contact_post="111629" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</button>
						</div>
						<div class="project-cart-btn w-c-btn whatsapp">
							<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Chelsea Residences send me more information about the project.Thanks https://dxboffplan.com/properties/chelsea-residences-dubai-maritime-city/">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div>                <div class="card property-card">
										<div class="card-header">
						<div class="ribbon-loop"><span>Sold out</span></div>                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/palm-jebel-ali-villas/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/11/Palm-Jebel-Ali-Master-Plan.jpg"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/11/Palm-Jebel-Ali-Master-Plan.jpg" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">villas</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2027 </span><span>Q4 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/palm-jebel-ali-villas/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            Palm Jebel Ali Villas                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Dubai - 
                               Palm Jebel Ali                        </div>
																			<div class="specials-div">
													</div>
                    </div>
						<p class="ppagent-dev">
							Nakheel Properties						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="askprice">Ask Price</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
													<a class="btn btn-callback-open-loop" href="tel:+971507958000" data-title="Azizi Riviera 69" data-contact_post="102613" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</a>
										</div>
						<div class="project-cart-btn w-c-btn whatsapp">
								<div class="select-whatsapp-soldout">
		<div class="inner">
		<h6>
			Please select your interest		</h6>
<div class="d-flex gap-2">
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971552554245&text=Hi, I see that Palm Jebel Ali Villas is sold out. If you have another similar property, please share the details with me.https://dxboffplan.com/properties/palm-jebel-ali-villas/">
		<i class="fab fa-whatsapp"></i>
		Find Me a Similar Property	</a>
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971547418880&text=Hi, I own a unit in Palm Jebel Ali Villas and would like to sell it. Please contact me with a cash offer.https://dxboffplan.com/properties/palm-jebel-ali-villas/">
		<i class="fab fa-whatsapp"></i>
		I Want to Sell My Unit	</a>
</div>
		</div>
</div>
<a class="btn first btn-whataspp-link btn-whataspp-link-soldout " href="#">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div>                <div class="card property-card">
										<div class="card-header">
						<div class="ribbon-loop"><span>20% Booking</span></div><div class="ribbon-loop"><span>Sold out</span></div>                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/selene-beach-residence-sobha-siniya-island/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/08/selena-beach-residence-2.png"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/08/selena-beach-residence-2.png" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">apartments</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2027 </span><span>Q4 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/selene-beach-residence-sobha-siniya-island/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            Selene Beach Residence                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Umm Al Quwain - 
                               Siniya Island                        </div>
																			<div class="specials-div">
						<p class="specials-loop sp-one alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Luxury Coastal Living on Sobha Siniya Island: A Natural Paradise of Sun, Sand, and Sea</p><p class="specials-loop sp-two alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Elegant Apartments with Panoramic Sea Views and Luxurious Comfort</p>							</div>
                    </div>
						<p class="ppagent-dev">
							Sobha Group						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="askprice">Ask Price</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
						<button class="btn btn-callback-open-loop open-contact" data-title="Selene Beach Residence"
	data-contact_post="88949" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</button>
						</div>
						<div class="project-cart-btn w-c-btn whatsapp">
								<div class="select-whatsapp-soldout">
		<div class="inner">
		<h6>
			Please select your interest		</h6>
<div class="d-flex gap-2">
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971552554245&text=Hi, I see that Selene Beach Residence is sold out. If you have another similar property, please share the details with me.https://dxboffplan.com/properties/selene-beach-residence-sobha-siniya-island/">
		<i class="fab fa-whatsapp"></i>
		Find Me a Similar Property	</a>
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971547418880&text=Hi, I own a unit in Selene Beach Residence and would like to sell it. Please contact me with a cash offer.https://dxboffplan.com/properties/selene-beach-residence-sobha-siniya-island/">
		<i class="fab fa-whatsapp"></i>
		I Want to Sell My Unit	</a>
</div>
		</div>
</div>
<a class="btn first btn-whataspp-link btn-whataspp-link-soldout " href="#">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div>                <div class="card property-card">
										<div class="card-header">
						<div class="ribbon-loop"><span>10% Booking</span></div>                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/one-residence-downtown-dubai/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/07/One-Residence-1.png"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/07/One-Residence-1.png" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">apartments</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2027 </span><span>Q1 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/one-residence-downtown-dubai/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            One Residence                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Dubai - 
                               Downtown Dubai                        </div>
																			<div class="specials-div">
						<p class="specials-loop sp-one alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Embracing Unity: The Essence of One at ONE RESIDENCE</p><p class="specials-loop sp-two alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Opulence Defined: Your Ideal Home Awaits</p>							</div>
                    </div>
						<p class="ppagent-dev">
							Ginco Properties						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="text-nowrap">AED 1,525,000</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
						<button class="btn btn-callback-open-loop open-contact" data-title="One Residence"
	data-contact_post="86401" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</button>
						</div>
						<div class="project-cart-btn w-c-btn whatsapp">
							<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971552554245&text=Hi,I am Interested in One Residence send me more information about the project.Thanks https://dxboffplan.com/properties/one-residence-downtown-dubai/">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div>                <div class="card property-card">
										<div class="card-header">
						<div class="ribbon-loop"><span>10% Booking</span></div>                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/ocean-cove-rashid-yachts-and-marina-dubai/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/07/OCEAN-COVE.png"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/07/OCEAN-COVE.png" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">apartments</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2028 </span><span>Q3 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/ocean-cove-rashid-yachts-and-marina-dubai/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            Ocean Cove Apartments                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Dubai - 
                               Mina Rashid                        </div>
																			<div class="specials-div">
						<p class="specials-loop sp-one alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Luxury Living on Dubai's Vibrant Waterfront</p><p class="specials-loop sp-two alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Emaar's Masterpiece with Irresistible Payment Flexibility!</p>							</div>
                    </div>
						<p class="ppagent-dev">
							Emaar Properties						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="text-nowrap">AED 3,229,888</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
						<button class="btn btn-callback-open-loop open-contact" data-title="Ocean Cove Apartments"
	data-contact_post="85575" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</button>
						</div>
						<div class="project-cart-btn w-c-btn whatsapp">
							<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Ocean Cove Apartments send me more information about the project.Thanks https://dxboffplan.com/properties/ocean-cove-rashid-yachts-and-marina-dubai/">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div>                <div class="card property-card">
										<div class="card-header">
						<div class="ribbon-loop"><span>10% Booking</span></div><div class="ribbon-loop"><span>Sold out</span></div>                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/marina-views-rashid-yachts-and-marina/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/07/marina-views.png"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/07/marina-views.png" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">apartments</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2028 </span><span>Q4 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/marina-views-rashid-yachts-and-marina/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            Marina Views Apartments                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Dubai - 
                               Mina Rashid                        </div>
																			<div class="specials-div">
						<p class="specials-loop sp-one alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Elegant and Stylish Premier Residences</p><p class="specials-loop sp-two alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Attractive Payment Plans for Waterfront Luxury Living</p>							</div>
                    </div>
						<p class="ppagent-dev">
							Emaar Properties						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="askprice">Ask Price</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
						<button class="btn btn-callback-open-loop open-contact" data-title="Marina Views Apartments"
	data-contact_post="85556" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</button>
						</div>
						<div class="project-cart-btn w-c-btn whatsapp">
								<div class="select-whatsapp-soldout">
		<div class="inner">
		<h6>
			Please select your interest		</h6>
<div class="d-flex gap-2">
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971552554245&text=Hi, I see that Marina Views Apartments is sold out. If you have another similar property, please share the details with me.https://dxboffplan.com/properties/marina-views-rashid-yachts-and-marina/">
		<i class="fab fa-whatsapp"></i>
		Find Me a Similar Property	</a>
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971547418880&text=Hi, I own a unit in Marina Views Apartments and would like to sell it. Please contact me with a cash offer.https://dxboffplan.com/properties/marina-views-rashid-yachts-and-marina/">
		<i class="fab fa-whatsapp"></i>
		I Want to Sell My Unit	</a>
</div>
		</div>
</div>
<a class="btn first btn-whataspp-link btn-whataspp-link-soldout " href="#">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div>                <div class="card property-card">
										<div class="card-header">
						<div class="ribbon-loop"><span>4% DLD Waiver</span></div><div class="ribbon-loop"><span>Sold out</span></div>                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/violet-at-damac-hills-2-dubai/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/06/Violet-Townhouses.png"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/06/Violet-Townhouses.png" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">Townhouses</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2027 </span><span>Q3 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/violet-at-damac-hills-2-dubai/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            Violet Townhouses                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Dubai - 
                               Damac Hills 2                        </div>
																			<div class="specials-div">
						<p class="specials-loop sp-one alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Harmonizing Modern Luxuries with Nature's Beauty</p><p class="specials-loop sp-two alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Embracing Color, Comfort, and Serenity</p>							</div>
                    </div>
						<p class="ppagent-dev">
							Damac Properties						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="askprice">Ask Price</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
						<button class="btn btn-callback-open-loop open-contact" data-title="Violet Townhouses"
	data-contact_post="84991" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</button>
						</div>
						<div class="project-cart-btn w-c-btn whatsapp">
								<div class="select-whatsapp-soldout">
		<div class="inner">
		<h6>
			Please select your interest		</h6>
<div class="d-flex gap-2">
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971552554245&text=Hi, I see that Violet Townhouses is sold out. If you have another similar property, please share the details with me.https://dxboffplan.com/properties/violet-at-damac-hills-2-dubai/">
		<i class="fab fa-whatsapp"></i>
		Find Me a Similar Property	</a>
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971547418880&text=Hi, I own a unit in Violet Townhouses and would like to sell it. Please contact me with a cash offer.https://dxboffplan.com/properties/violet-at-damac-hills-2-dubai/">
		<i class="fab fa-whatsapp"></i>
		I Want to Sell My Unit	</a>
</div>
		</div>
</div>
<a class="btn first btn-whataspp-link btn-whataspp-link-soldout " href="#">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div>                <div class="card property-card">
										<div class="card-header">
						<div class="ribbon-loop"><span>Low Down Payment</span></div><div class="ribbon-loop"><span>Sold out</span></div>                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/the-watercrest-mbr-city-dubai/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/06/The-Watercrest-Villas.png"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/06/The-Watercrest-Villas.png" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">villas</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2027 </span><span>Q2 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/the-watercrest-mbr-city-dubai/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            The Watercrest Villas                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Dubai - 
                               Mohammed Bin Rashid City                        </div>
																			<div class="specials-div">
						<p class="specials-loop sp-one alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Sanctuary Villa Collection: Where Tranquility Meets Luxury</p><p class="specials-loop sp-two alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Easy &amp; Flexible Payment Plan Offered</p>							</div>
                    </div>
						<p class="ppagent-dev">
							Ellington Properties						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="askprice">Ask Price</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
													<a class="btn btn-callback-open-loop" href="tel:+971507958000" data-title="Azizi Riviera 69" data-contact_post="102613" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</a>
										</div>
						<div class="project-cart-btn w-c-btn whatsapp">
								<div class="select-whatsapp-soldout">
		<div class="inner">
		<h6>
			Please select your interest		</h6>
<div class="d-flex gap-2">
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971552554245&text=Hi, I see that The Watercrest Villas is sold out. If you have another similar property, please share the details with me.https://dxboffplan.com/properties/the-watercrest-mbr-city-dubai/">
		<i class="fab fa-whatsapp"></i>
		Find Me a Similar Property	</a>
	<a class="btn btn-whataspp-sold" href="whatsapp://send?phone=+971547418880&text=Hi, I own a unit in The Watercrest Villas and would like to sell it. Please contact me with a cash offer.https://dxboffplan.com/properties/the-watercrest-mbr-city-dubai/">
		<i class="fab fa-whatsapp"></i>
		I Want to Sell My Unit	</a>
</div>
		</div>
</div>
<a class="btn first btn-whataspp-link btn-whataspp-link-soldout " href="#">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div>                <div class="card property-card">
										<div class="card-header">
						<div class="ribbon-loop"><span>10% Deposit</span></div>                    	<a class="d-block property-card-img-a" href="https://dxboffplan.com/properties/verdes-by-haven-dubailand/">
                        <img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img property-card-img img-fluid" alt="" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2024/06/verdes-by-haven.png"><noscript><img src="https://dxboffplan.com/wp-content/uploads/2024/06/verdes-by-haven.png" class="img property-card-img img-fluid" alt=""></noscript>
						</a>
					<div class="flesh-top">
						<svg xmlns="http://www.w3.org/2000/svg" width="17" height="7" viewBox="0 0 17 7">
  <path id="Polygon_1" data-name="Polygon 1" d="M8.5,0,17,7H0Z" fill="#fff"/>
</svg>

						</div>
						<span class="pc-type">apartments</span>                    </div>
					
                    <div class="card-body d-flex align-items-center gap-2">
						
                        <div class="q-ready border rounded align-items-center d-flex justify-content-center text-dark-50 px-3">
							                            <span>2028 </span><span>Q2 </span>							                        </div>
						
						<a href="https://dxboffplan.com/properties/verdes-by-haven-dubailand/" class="d-block w-100">
                        <h3 class="title my-0 px-1">
                            Verdes by Haven                        </h3 >
                    </a>
													<div class="location col-md-12 text-nowrap text-center overflow-hidden card-loc">
														<i class="fa fa-map-marker-alt"></i>
                                Dubai - 
                               Haven                        </div>
																			<div class="specials-div">
						<p class="specials-loop sp-one alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Exceptional wellness living in Dubailand</p><p class="specials-loop sp-two alert alert-danger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" class="e4290806"><path d="M5.76 10.26l-1.6-3.5-3.5-1.6 3.5-1.58 1.6-3.5 1.6 3.5 3.5 1.59-3.5 1.59-1.6 3.5z"></path></svg>Easy and Appealing Payment Options Await!</p>							</div>
                    </div>
						<p class="ppagent-dev">
							Aldar Properties						</p>
                    <div class="card-footer p-0">
						<div class="ppcaf row align-items-center">
						<span class="col-md-12 start-price small">
                            Start price from:                        </span>
                        <strong class="col-md-12 price text-center align-items-center d-flex justify-content-center">
                           <span class="text-nowrap">AED 1,913,748</span>                        </strong>
						</div>
						<div class="project-cart-btns">
						<div class="project-cart-btn w-c-btn callback">
						<button class="btn btn-callback-open-loop open-contact" data-title="Verdes by Haven"
	data-contact_post="84416" data-contact_type="callback request">
	<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
</button>
						</div>
						<div class="project-cart-btn w-c-btn whatsapp">
							<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Verdes by Haven send me more information about the project.Thanks https://dxboffplan.com/properties/verdes-by-haven-dubailand/">
	<i class="fab fa-whatsapp"></i>
</a>
						</div>
						</div>
                    </div>
                </div></div><script>window.addEventListener('DOMContentLoaded', function() {
	jQuery(function ($) {
		if ($(window).width() > 577) {
			$('.top-posts').owlCarousel({
				loop: true,
				margin: 20,
				nav: true,
				rtl: false ,
				responsive: {
					0: {
						items: 2,
						margin: 5,
					},
					600: {
						items: 2,
						margin: 5,
					},
					900: {
						items: 3
					}
				}
			})
		} else {
			$('.top-posts').addClass('off');
		}
	})
});</script>
            </div>
        </section>
		 <section class="best-developments">
			 <div class="best-developments-inner">
				 <div class="inside container d-flex flex-column">
					 <h2 class="inside-title">
						 Most popular Developments					 </h2>
					 <div class="row mt-auto">
						 <div class="col-md-3">
							 <img class="best-developments-main-img" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/anyrgb.png" /><noscript><img class="best-developments-main-img" src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/anyrgb.png" /></noscript>
						 </div>
						 <div class="col-md-9">
							 <div class="home-developments">
					     		<div class="top-developments owl-carousel"><div class="development-item">
    <div class="dcpnot">
					<strong>
			1			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/nadd-al-hamar-dubai/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/03/Nadd-Al-Hamar.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2026/03/Nadd-Al-Hamar.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			Nadd Al Hamar		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for Sale in Nadd Al Hamar send me more information about the project.Thanks https://dxboffplan.com/development/nadd-al-hamar-dubai/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="Nadd Al Hamar"
							data-contact_post="144677"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div><div class="development-item">
    <div class="dcpnot">
					<strong>
			3			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2023/03/Northern-Cyprus.jpg?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2023/03/Northern-Cyprus.jpg?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/geroskipou-paphos/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/03/Property-for-Sale-in-Geroskipou-.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2026/03/Property-for-Sale-in-Geroskipou-.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			Geroskipou		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for Sale in Geroskipou send me more information about the project.Thanks https://dxboffplan.com/development/geroskipou-paphos/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="Geroskipou"
							data-contact_post="144571"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div><div class="development-item">
    <div class="dcpnot">
					<strong>
			4			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/the-wilds-dubai/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/03/Property-for-Sale-in-The-Wilds.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2026/03/Property-for-Sale-in-The-Wilds.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			The Wilds		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for Sale in The Wilds send me more information about the project.Thanks https://dxboffplan.com/development/the-wilds-dubai/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="The Wilds"
							data-contact_post="143725"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div><div class="development-item">
    <div class="dcpnot">
					<strong>
			1			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/the-strand-ras-al-khaimah/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/Property-for-Sale-in-The-Strand-Ras-Al-Khaimah-2.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2026/02/Property-for-Sale-in-The-Strand-Ras-Al-Khaimah-2.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			The Strand		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for Sale in The Strand, Ras Al Khaimah send me more information about the project.Thanks https://dxboffplan.com/development/the-strand-ras-al-khaimah/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="The Strand"
							data-contact_post="143020"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div><div class="development-item">
    <div class="dcpnot">
					<strong>
			13			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/eden-hills-dubai/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/Property-for-sale-in-Eden-Hills-6.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2026/02/Property-for-sale-in-Eden-Hills-6.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			Eden Hills		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for sale in Eden Hills send me more information about the project.Thanks https://dxboffplan.com/development/eden-hills-dubai/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="Eden Hills"
							data-contact_post="142654"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div><div class="development-item">
    <div class="dcpnot">
					<strong>
			1			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/02/GE.png?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/02/GE.png?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/ambassadori-island-batumi/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/Property-for-Sale-in-Ambassadori-Island-Batumi.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2026/02/Property-for-Sale-in-Ambassadori-Island-Batumi.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			Ambassadori Island Batumi		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for Sale in Ambassadori Island Batumi send me more information about the project.Thanks https://dxboffplan.com/development/ambassadori-island-batumi/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="Ambassadori Island Batumi"
							data-contact_post="142597"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div><div class="development-item">
    <div class="dcpnot">
					<strong>
			1			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/lunaya-dubai/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2025/12/Lunaya-Villas-in-Jebel-Ali-Village-3.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2025/12/Lunaya-Villas-in-Jebel-Ali-Village-3.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			Lunaya		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for Sale in Lunaya send me more information about the project.Thanks https://dxboffplan.com/development/lunaya-dubai/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="Lunaya"
							data-contact_post="142130"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div><div class="development-item">
    <div class="dcpnot">
					<strong>
			1			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/manchester-city-yas-residences-abu-dhabi/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/Manchester-City-Yas-Residences-3.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2026/02/Manchester-City-Yas-Residences-3.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			Manchester City Yas Residences		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for Sale in Manchester City Yas Residences send me more information about the project.Thanks https://dxboffplan.com/development/manchester-city-yas-residences-abu-dhabi/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="Manchester City Yas Residences"
							data-contact_post="141840"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div><div class="development-item">
    <div class="dcpnot">
					<strong>
			1			</strong>
			<span>
			Projects			</span>
	</div>
	<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" alt="" class="imgondevc" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2022/02/ae.png?" alt="" class="imgondevc" /></noscript>
	<a class="body" href="https://dxboffplan.com/development/evermore-ras-al-khaimah/">
		<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="img" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/Le-Chateau-at-Evermore-Ras-Al-Khaimah-22.png" /><noscript><img src="https://dxboffplan.com/wp-content/uploads/2026/02/Le-Chateau-at-Evermore-Ras-Al-Khaimah-22.png" class="img" /></noscript>
		<div class="overlay">
			
		</div>
		<h3>
			Evermore		</h3>
		
	</a>
	<div class="footers">
		<div class="btn btn-whataspp-open-loop">
			<a class="btn first btn-whataspp-link" href="whatsapp://send?phone=971507958000&text=Hi,I am Interested in Property for Sale in Evermore, Ras Al Khaimah send me more information about the project.Thanks https://dxboffplan.com/development/evermore-ras-al-khaimah/">
	<i class="fab fa-whatsapp"></i>
</a>
		</div>
		<span class="seprator"></span>
		<a class="btn btn-callback-open-loop open-contact" 
		data-title="Evermore"
							data-contact_post="141477"
							data-contact_type="callback request"
		>
			<i class="fa fa-volume-control-phone"></i>
		</a>
	</div>
</div></div><script>window.addEventListener('DOMContentLoaded', function() {
	jQuery('.top-developments').owlCarousel({
		loop: true,
		margin: 20,
		nav: true,
		dots: false,
		rtl: false ,
		responsive: {
			0: {
				items: 2,
				margin: 5,
			},
			600: {
				items: 4,
				margin: 5,
			},
			900: {
				items: 5
			}
		}
	})
});</script>
					 		</div>
						 </div>
					 </div>
				 </div>
			 </div>
		  </section>
<!-- 		  <section class="best-agents">
			 <div class="best-agents-inner">
				 <div class="inside container d-flex flex-column">
					 			<div class="titles d-flex gap-3 top-projects mb-3">
			<div class="first">
<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25">
  <path id="Path_1356" data-name="Path 1356" d="M12.525,0A12.5,12.5,0,1,1,6.35,23.372a2.125,2.125,0,0,0-1.863-.451h0l-2.525.751A.781.781,0,0,1,.938,22.7h0l.837-2.8a1.311,1.311,0,0,0-.087-1.127A13.235,13.235,0,0,1,0,12.519,12.509,12.509,0,0,1,12.525,0Zm5.712,10.929a1.6,1.6,0,1,0,1.6,1.6A1.6,1.6,0,0,0,18.237,10.929Zm-5.762,0a1.594,1.594,0,0,0-1.6,1.59,1.6,1.6,0,1,0,3.2.012A1.6,1.6,0,0,0,12.475,10.929Zm-5.762,0a1.6,1.6,0,0,0-1.6,1.6,1.6,1.6,0,1,0,3.2,0A1.6,1.6,0,0,0,6.712,10.929Z" transform="translate(0)" fill="#efefef"/>
</svg>

			</div>
			<div class="second">
				            <h2>
								<strong>
								Support Team								</strong>
						 
						 <span class="d-block">
							 Collection						 </span>
            </h2>
			</div>
									<a type="button" class="btn btn-loadmore" href="/agents">
<span> See More </span>
<span class="arrow">
<svg xmlns="http://www.w3.org/2000/svg" width="13.549" height="16.5" viewBox="0 0 13.549 16.5">
<g id="g" transform="translate(-5.5 20) rotate(-90)">
<g id="Arrow---Left" transform="translate(20 5.5) rotate(90)">
<path id="Combined-Shape" d="M6.774,0a.75.75,0,0,1,.743.648l.007.1V13.934l4.744-4.763a.75.75,0,0,1,1.135.974l-.072.084-6.024,6.05a.751.751,0,0,1-.124.1l-.041.024-.037.02-.056.024-.043.016-.056.016-.04.008-.06.008-.046,0H6.745l-.044,0,.073,0a.753.753,0,0,1-.139-.013L6.6,16.48c-.023-.005-.044-.011-.066-.019L6.5,16.45c-.023-.009-.044-.018-.065-.029l-.03-.016-.048-.029-.033-.024-.009-.007a.75.75,0,0,1-.075-.066h0L.218,10.229A.75.75,0,0,1,1.2,9.1l.084.073,4.743,4.761V.75A.75.75,0,0,1,6.774,0Z" fill="#fff"></path>
</g>
</g>
</svg>
</span>
</a>
				</div>
							 <div class="home-agents">
					     							 		</div>
				 </div>
			 </div>
		  </section> -->
		  <section class="best-seller">
			 <div class="best-seller-inner">
				 <div class="inside container row">
					 <div class="col-md-6 d-flex gap-3">
						 <div class="bf pt-5">
							 <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="112" viewBox="0 0 33 112">
  <defs>
    <clipPath id="clip-path">
      <rect x="6" y="16" width="33" height="112" fill="none"/>
    </clipPath>
  </defs>
  <g id="Scroll_Group_5" data-name="Scroll Group 5" transform="translate(-6 -16)" clip-path="url(#clip-path)" style="mix-blend-mode: darken;isolation: isolate">
    <image id="pattern" width="120" height="199" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAADHCAIAAABdmgAlAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDY3IDc5LjE1Nzc0NywgMjAxNS8wMy8zMC0yMzo0MDo0MiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjNEMjA4ODI3QUVEQTExRUJCMTNGQjVEOTNBOUU0RDgzIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjNEMjA4ODI4QUVEQTExRUJCMTNGQjVEOTNBOUU0RDgzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6M0QyMDg4MjVBRURBMTFFQkIxM0ZCNUQ5M0E5RTREODMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6M0QyMDg4MjZBRURBMTFFQkIxM0ZCNUQ5M0E5RTREODMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz783IbrAAABnElEQVR42uzYMarEIBSG0Zj1607FLdzc3iBIEFKcv5hi8L3iFHPhKxFx2fkV0KBBG+jf7p6/GmO01vJz/Zee7T2LabXW/D4/YznPtp69QPfe83V+rv+vZ1vP/EY7hqANNGjQoEGDNtCgRSUZSFQSlTwTlRxD0KBBgzbQoEFTAA3aRCVRSVSSgUQlx9BAgwZtoEEbaNCgTVQSlTwTlUQlx9BAgzbQoEEbaNAGWlQSlWQgUUlUMscQNGgDDdpAgwZtoEUlz0QlUUlUMscQtIEGDdpAgzbQoEUlGUhUEpU8E5UcQ9AGGrSBBg3aQIM2UUlUEpVkIFHJMTTQoEEbaNAGGjRoE5VEJc9EJVHJMTTQoA00aNAGGrSBFpVEJRlIVBKVzDEEDdpAgzbQoEEbaFHJM1FJVBKVzDEEbaBBgzbQoA00aFFJLRKVRCXPRCXHELSBBm2gQYM20KBNVBKVRCW1SFRyDA00aNAGGrSBBg3aRCVRyTNRSVRyDA00aAMNGrSBBm2gRSVRSS0SlUQlcwxBgzbQoA00aND2eY8AAwB3vbQHhEJ1pgAAAABJRU5ErkJggg==" style="mix-blend-mode: multiply;isolation: isolate"/>
  </g>
</svg>

						 </div>
						 <div class="l-f">
							 
						 <h4>
							 
							 
						 <span class="d-block">
							 Property sales portal						 </span>
							 </h4>
						 <p>
							 With over 16 years of experience in offering the best real estate options, DXB Offplan helps turn your dream of buying property in the UAE into a reality. From purchasing luxurious apartments to modern homes, we guide you through every stage of the buying process—from selecting the best property to closing the deal—with a specialized team and exceptional technical expertise. Experience a smooth and unparalleled property-buying journey in the UAE with us.						 </p>
							 
							 </div>
					 </div>
					
					<div class="col-md-6 d-none d-md-block">
					     	<img class="best-seller-img" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/homed.png"><noscript><img class="best-seller-img" src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/homed.png"></noscript>
					 </div>
				 </div>
			 </div>
		  </section>
		 		  <section class="why-us">
		  	<div class="row">
				<div class="col-md-3 col-6 mb-3">
					<div class="why-us-item d-flex gap-md-3 gap-1 align-items-center">
						<div class="inner-one">
							<div class="inner-two">
								<svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37">
  <path id="Path_1360" data-name="Path 1360" d="M18.537,0A18.5,18.5,0,1,1,9.4,34.591a3.145,3.145,0,0,0-2.756-.667h0L2.9,35.036a1.156,1.156,0,0,1-1.517-1.445h0l1.239-4.15A1.94,1.94,0,0,0,2.5,27.773,19.588,19.588,0,0,1,0,18.528,18.513,18.513,0,0,1,18.537,0Zm8.455,16.175a2.372,2.372,0,1,0,2.368,2.371A2.363,2.363,0,0,0,26.992,16.175Zm-8.529,0a2.359,2.359,0,0,0-2.368,2.353,2.368,2.368,0,1,0,4.736.018A2.363,2.363,0,0,0,18.463,16.175Zm-8.528,0a2.363,2.363,0,0,0-2.368,2.371,2.368,2.368,0,1,0,4.736,0A2.363,2.363,0,0,0,9.934,16.175Z" fill="#171717"/>
</svg>

							</div>
						</div>
						<h5>
							free <br /> consultation  
						</h5>
					</div>
				</div>
				<div class="col-md-3 col-6 mb-3">
					<div class="why-us-item d-flex gap-md-3 gap-1 align-items-center">
						<div class="inner-one">
							<div class="inner-two">
								<svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37">
  <path id="Path_1361" data-name="Path 1361" d="M18.5,0A18.5,18.5,0,1,1,0,18.5,18.495,18.495,0,0,1,18.5,0Zm-.648,9.12a1.386,1.386,0,0,0-1.388,1.387h0V19.85a1.39,1.39,0,0,0,.685,1.184h0L24.4,25.364a1.416,1.416,0,0,0,.722.2,1.373,1.373,0,0,0,1.184-.685,1.393,1.393,0,0,0-.481-1.905h0L19.24,19.055V10.508A1.386,1.386,0,0,0,17.852,9.12Z" fill="#171717"/>
</svg>


							</div>
						</div>
						<h5>
							24-hour <br /> consultation 
						</h5>
					</div>
				</div>
				<div class="col-md-3 col-6 mb-3">
					<div class="why-us-item d-flex gap-md-3 gap-1 align-items-center">
						<div class="inner-one">
							<div class="inner-two">
								<svg xmlns="http://www.w3.org/2000/svg" width="37" height="36.991" viewBox="0 0 37 36.991">
  <path id="Path_1362" data-name="Path 1362" d="M14.551,1.638a5.582,5.582,0,0,1,7.884-.017h0L23.786,2.97a2.775,2.775,0,0,0,1.962.816h1.906a5.574,5.574,0,0,1,5.571,5.567h0V11.26a2.771,2.771,0,0,0,.814,1.959h0l1.332,1.332a5.6,5.6,0,0,1,.037,7.863h0l-1.37,1.369a2.773,2.773,0,0,0-.814,1.963h0v1.9a5.577,5.577,0,0,1-5.571,5.57H25.748a2.772,2.772,0,0,0-1.962.812h0l-1.333,1.332a5.541,5.541,0,0,1-3.942,1.628,5.605,5.605,0,0,1-3.942-1.608h0l-1.351-1.352a2.772,2.772,0,0,0-1.962-.812H9.351a5.577,5.577,0,0,1-5.571-5.57h0v-1.9a2.849,2.849,0,0,0-.814-1.981h0L1.633,22.45a5.591,5.591,0,0,1-.019-7.879h0l1.351-1.352a2.783,2.783,0,0,0,.814-1.979h0V9.352A5.574,5.574,0,0,1,9.351,3.786h1.906a2.776,2.776,0,0,0,1.962-.816h0Zm8.717,20a1.619,1.619,0,1,0,1.61,1.609A1.616,1.616,0,0,0,23.268,21.636ZM24.4,12.59a1.612,1.612,0,0,0-2.276,0h0L12.608,22.1a1.63,1.63,0,0,0,0,2.294,1.587,1.587,0,0,0,2.276,0h0L24.4,14.886A1.632,1.632,0,0,0,24.4,12.59Zm-10.641-.462a1.619,1.619,0,1,0,1.61,1.609A1.627,1.627,0,0,0,13.755,12.127Z" transform="translate(0)" fill="#171717"/>
</svg>


							</div>
						</div>
						<h5>
							Zero <br /> Commission 
						</h5>
					</div>
				</div>
				<div class="col-md-3 col-6 mb-3">
					<div class="why-us-item d-flex gap-md-3 gap-1 align-items-center">
						<div class="inner-one">
							<div class="inner-two">
								<svg xmlns="http://www.w3.org/2000/svg" width="29.6" height="37" viewBox="0 0 29.6 37">
  <path id="Path_1363" data-name="Path 1363" d="M14.8,24.372c8.026,0,14.8,1.3,14.8,6.336S22.782,37,14.8,37C6.775,37,0,35.7,0,30.664S6.818,24.372,14.8,24.372ZM14.8,0A9.789,9.789,0,1,1,5.006,9.788,9.756,9.756,0,0,1,14.8,0Z" transform="translate(0 0)" fill="#171717"/>
</svg>


							</div>
						</div>
						<h5>
							Direct <br /> Communication 
						</h5>
					</div>
				</div>
			  </div>
			  					 <div class="col-md-6 d-md-none">
					     	<img class="best-seller-img" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/homedmob.png"><noscript><img class="best-seller-img" src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/homedmob.png"></noscript>
					 </div>
		  </section>
		  <section class="new-mags">
		  				 <div class=" top-projects d-flex gap-3 mb-3 align-items-center">
				 			<div class="first">
<svg xmlns="http://www.w3.org/2000/svg" width="25" height="23.748" viewBox="0 0 25 23.748">
  <path id="Path_1355" data-name="Path 1355" d="M19.9,14.773a1.376,1.376,0,0,0-.4,1.212l1.111,6.149a1.35,1.35,0,0,1-.562,1.35,1.376,1.376,0,0,1-1.462.1L13.048,20.7a1.413,1.413,0,0,0-.625-.164h-.339a1.015,1.015,0,0,0-.337.112l-5.537,2.9a1.46,1.46,0,0,1-.887.137A1.389,1.389,0,0,1,4.211,22.1l1.112-6.149a1.4,1.4,0,0,0-.4-1.224L.411,10.349A1.349,1.349,0,0,1,.075,8.936,1.4,1.4,0,0,1,1.186,8L7.4,7.1a1.39,1.39,0,0,0,1.1-.761L11.235.725a1.3,1.3,0,0,1,.25-.337L11.6.3a.839.839,0,0,1,.2-.162l.136-.05L12.147,0h.526a1.4,1.4,0,0,1,1.1.75l2.773,5.587a1.389,1.389,0,0,0,1.037.761L23.8,8a1.417,1.417,0,0,1,1.137.937,1.358,1.358,0,0,1-.362,1.412Z" transform="translate(0 0)" fill="var(--color-yellow)"/>
</svg>
			</div>
				 <div class="inside container d-flex flex-column w-auto m-0">
					 <h2 class="inside-title">
						 Latest						 <span class="d-block">
							 Articles						 </span>
					 </h2>
				 </div>	
							 <a href="https://dxboffplan.com/blog/" class="btn btn-loadmore shadow-sm border ms-auto me-0 btn-s-m-b-p-h">
<span> See More </span>
<span class="arrow">
<svg xmlns="http://www.w3.org/2000/svg" width="13.549" height="16.5" viewBox="0 0 13.549 16.5">
<g id="g" transform="translate(-5.5 20) rotate(-90)">
<g id="Arrow---Left" transform="translate(20 5.5) rotate(90)">
<path id="Combined-Shape" d="M6.774,0a.75.75,0,0,1,.743.648l.007.1V13.934l4.744-4.763a.75.75,0,0,1,1.135.974l-.072.084-6.024,6.05a.751.751,0,0,1-.124.1l-.041.024-.037.02-.056.024-.043.016-.056.016-.04.008-.06.008-.046,0H6.745l-.044,0,.073,0a.753.753,0,0,1-.139-.013L6.6,16.48c-.023-.005-.044-.011-.066-.019L6.5,16.45c-.023-.009-.044-.018-.065-.029l-.03-.016-.048-.029-.033-.024-.009-.007a.75.75,0,0,1-.075-.066h0L.218,10.229A.75.75,0,0,1,1.2,9.1l.084.073,4.743,4.761V.75A.75.75,0,0,1,6.774,0Z" fill="#fff"></path>
</g>
</g>
</svg>
</span>
</a>
			  </div>
			  			  <div class="new-posts-b owl-carousel">
				  
			  
			  <article class="npo">
				  <div class="him">
					  <img width="740" height="370" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20740%20370'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="Join Al Khail Real Estate – 20+ Years in Dubai Market" decoding="async" fetchpriority="high" data-lazy-srcset="https://dxboffplan.com/wp-content/uploads/2026/03/Join-Al-Khail-Real-Estate-–-20-Years-in-Dubai-Market-3.png 740w, https://dxboffplan.com/wp-content/uploads/2026/03/Join-Al-Khail-Real-Estate-–-20-Years-in-Dubai-Market-3-550x275.png 550w" data-lazy-sizes="(max-width: 740px) 100vw, 740px" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/03/Join-Al-Khail-Real-Estate-–-20-Years-in-Dubai-Market-3.png" /><noscript><img width="740" height="370" src="https://dxboffplan.com/wp-content/uploads/2026/03/Join-Al-Khail-Real-Estate-–-20-Years-in-Dubai-Market-3.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="Join Al Khail Real Estate – 20+ Years in Dubai Market" decoding="async" fetchpriority="high" srcset="https://dxboffplan.com/wp-content/uploads/2026/03/Join-Al-Khail-Real-Estate-–-20-Years-in-Dubai-Market-3.png 740w, https://dxboffplan.com/wp-content/uploads/2026/03/Join-Al-Khail-Real-Estate-–-20-Years-in-Dubai-Market-3-550x275.png 550w" sizes="(max-width: 740px) 100vw, 740px" /></noscript>				  </div>
				  <div class="hit">
					  <a href="https://dxboffplan.com/al-khail-real-estate-agents-jobs-interview-dubai/">
					  <h3>
						  Walk-In Interview for Real Estate Agents | Join Al Khail Real Estate					  </h3>
						   </a>
					  <p>
						  Join Al Khail Real Estate – 20+ Years in Dubai Market Top Agents Wanted | Off-Plan, Secondary &amp; Rentals | High Commission &amp; Professional Environment Al Khail Real Estate Broker, with over 20 years of proven success in Dubai’s real estate market, is now expanding its elite sales team. We operate from a dedicated 10,000 [&hellip;]					  </p>
				  </div>
				  <div class="hif">
					  					  <a href="https://dxboffplan.com/category/uae/" class="hc"> UAE Blog Posts </a>
					  <span class="hd"> 2026-03-27 </span>
				  </div>
			  </article>
			  
			  			  <article class="npo">
				  <div class="him">
					  <img width="740" height="370" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20740%20370'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="نمو سوق العقارات التي تحت الإنشاء في دبي عام 2026" decoding="async" data-lazy-srcset="https://dxboffplan.com/wp-content/uploads/2026/02/dubai-off-plan-market-growth-in-2026.jpg 740w, https://dxboffplan.com/wp-content/uploads/2026/02/dubai-off-plan-market-growth-in-2026-550x275.jpg 550w" data-lazy-sizes="(max-width: 740px) 100vw, 740px" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/dubai-off-plan-market-growth-in-2026.jpg" /><noscript><img width="740" height="370" src="https://dxboffplan.com/wp-content/uploads/2026/02/dubai-off-plan-market-growth-in-2026.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="نمو سوق العقارات التي تحت الإنشاء في دبي عام 2026" decoding="async" srcset="https://dxboffplan.com/wp-content/uploads/2026/02/dubai-off-plan-market-growth-in-2026.jpg 740w, https://dxboffplan.com/wp-content/uploads/2026/02/dubai-off-plan-market-growth-in-2026-550x275.jpg 550w" sizes="(max-width: 740px) 100vw, 740px" /></noscript>				  </div>
				  <div class="hit">
					  <a href="https://dxboffplan.com/dubai-properties-buying-off-plan-2026/">
					  <h3>
						  Growth of Dubai’s Off-Plan Market in 2026; Why Under-Construction Projects Remain Ahead					  </h3>
						   </a>
					  <p>
						  The real estate market in Dubai has witnessed one of the fastest trends in market growth within the region in recent times. Within this market, under-construction properties, commonly called off-plan properties, have been at the heart of property transactions and have been instrumental in drawing both domestic and foreign investors into the market. As per [&hellip;]					  </p>
				  </div>
				  <div class="hif">
					  					  <a href="https://dxboffplan.com/category/uae/news/" class="hc"> News </a>
					  <span class="hd"> 2026-02-25 </span>
				  </div>
			  </article>
			  
			  			  <article class="npo">
				  <div class="him">
					  <img width="740" height="370" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20740%20370'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="Entering the Dubai real estate market" decoding="async" data-lazy-srcset="https://dxboffplan.com/wp-content/uploads/2026/02/entering-the-dubai-real-estate-market-1.jpg 740w, https://dxboffplan.com/wp-content/uploads/2026/02/entering-the-dubai-real-estate-market-1-550x275.jpg 550w" data-lazy-sizes="(max-width: 740px) 100vw, 740px" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/entering-the-dubai-real-estate-market-1.jpg" /><noscript><img width="740" height="370" src="https://dxboffplan.com/wp-content/uploads/2026/02/entering-the-dubai-real-estate-market-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="Entering the Dubai real estate market" decoding="async" srcset="https://dxboffplan.com/wp-content/uploads/2026/02/entering-the-dubai-real-estate-market-1.jpg 740w, https://dxboffplan.com/wp-content/uploads/2026/02/entering-the-dubai-real-estate-market-1-550x275.jpg 550w" sizes="(max-width: 740px) 100vw, 740px" /></noscript>				  </div>
				  <div class="hit">
					  <a href="https://dxboffplan.com/dubai-property-market-2026/">
					  <h3>
						  Is It Too Late to Enter Dubai’s Real Estate Market? A Smart 2026 Analysis					  </h3>
						   </a>
					  <p>
						  The Dubai real estate market has witnessed unprecedented growth in the past few years. Increasing property prices, record-breaking sales, and the constant launch of new projects have raised an important question in the minds of many potential buyers: Have the best investment opportunities in Dubai already passed? According to Mario Volpi, Senior Investment Advisory at [&hellip;]					  </p>
				  </div>
				  <div class="hif">
					  					  <a href="https://dxboffplan.com/category/uae/news/" class="hc"> News </a>
					  <span class="hd"> 2026-02-22 </span>
				  </div>
			  </article>
			  
			  			  <article class="npo">
				  <div class="him">
					  <img width="740" height="370" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20740%20370'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="قوانین پوشش در دبی برای زنان و مردان" decoding="async" data-lazy-srcset="https://dxboffplan.com/wp-content/uploads/2026/02/dubai-dress-code-for-men-and-women.jpg 740w, https://dxboffplan.com/wp-content/uploads/2026/02/dubai-dress-code-for-men-and-women-550x275.jpg 550w" data-lazy-sizes="(max-width: 740px) 100vw, 740px" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/dubai-dress-code-for-men-and-women.jpg" /><noscript><img width="740" height="370" src="https://dxboffplan.com/wp-content/uploads/2026/02/dubai-dress-code-for-men-and-women.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="قوانین پوشش در دبی برای زنان و مردان" decoding="async" srcset="https://dxboffplan.com/wp-content/uploads/2026/02/dubai-dress-code-for-men-and-women.jpg 740w, https://dxboffplan.com/wp-content/uploads/2026/02/dubai-dress-code-for-men-and-women-550x275.jpg 550w" sizes="(max-width: 740px) 100vw, 740px" /></noscript>				  </div>
				  <div class="hit">
					  <a href="https://dxboffplan.com/covering-rules-in-dubai/">
					  <h3>
						  .					  </h3>
						   </a>
					  <p>
						  .					  </p>
				  </div>
				  <div class="hif">
					  					  <a href="https://dxboffplan.com/category/uae/life-conditions/" class="hc"> Life Conditions blog posts </a>
					  <span class="hd"> 2026-02-22 </span>
				  </div>
			  </article>
			  
			  			  <article class="npo">
				  <div class="him">
					  <img width="740" height="370" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20740%20370'%3E%3C/svg%3E" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="اشتري منزلك الأول في دبي" decoding="async" data-lazy-srcset="https://dxboffplan.com/wp-content/uploads/2026/02/buying-your-first-home-in-dubai.jpg 740w, https://dxboffplan.com/wp-content/uploads/2026/02/buying-your-first-home-in-dubai-550x275.jpg 550w" data-lazy-sizes="(max-width: 740px) 100vw, 740px" data-lazy-src="https://dxboffplan.com/wp-content/uploads/2026/02/buying-your-first-home-in-dubai.jpg" /><noscript><img width="740" height="370" src="https://dxboffplan.com/wp-content/uploads/2026/02/buying-your-first-home-in-dubai.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="اشتري منزلك الأول في دبي" decoding="async" srcset="https://dxboffplan.com/wp-content/uploads/2026/02/buying-your-first-home-in-dubai.jpg 740w, https://dxboffplan.com/wp-content/uploads/2026/02/buying-your-first-home-in-dubai-550x275.jpg 550w" sizes="(max-width: 740px) 100vw, 740px" /></noscript>				  </div>
				  <div class="hit">
					  <a href="https://dxboffplan.com/buy-first-home-dubai-2026/">
					  <h3>
						  How Much Does It Really Cost to Buy Your First Home in Dubai in 2026?					  </h3>
						   </a>
					  <p>
						  The real estate sector in Dubai is still attractive for first-time buyers, but entering the sector is no longer based solely on property prices. Recent research reveals that first-time buyers in Dubai require at least AED 300,000 in initial cash capital and a monthly income of around AED 30,000 to 40,000 to confidently start the [&hellip;]					  </p>
				  </div>
				  <div class="hif">
					  					  <a href="https://dxboffplan.com/category/uae/news/" class="hc"> News </a>
					  <span class="hd"> 2026-02-17 </span>
				  </div>
			  </article>
			  
			  		</div>	
		  </section>
      </main>

    </div>
  </div>
<script>window.addEventListener('DOMContentLoaded', function() {
    const rangeInput = document.querySelectorAll(".range-input input"),
priceInput = document.querySelectorAll(".price-input input"),
range = document.querySelector(".slider .progress");
let priceGap = 1000;

priceInput.forEach(input =>{
    input.addEventListener("input", e =>{
        let minPrice = parseInt(priceInput[0].value),
        maxPrice = parseInt(priceInput[1].value);
        
        if((maxPrice - minPrice >= priceGap) && maxPrice <= rangeInput[1].max){
            if(e.target.className === "input-min"){
                rangeInput[0].value = minPrice;
                range.style.left = ((minPrice / rangeInput[0].max) * 100) + "%";
            }else{
                rangeInput[1].value = maxPrice;
                range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
            }
        }
    });
});

rangeInput.forEach(input =>{
    input.addEventListener("input", e =>{
        let minVal = parseInt(rangeInput[0].value),
        maxVal = parseInt(rangeInput[1].value);

        if((maxVal - minVal) < priceGap){
            if(e.target.className === "range-min"){
                rangeInput[0].value = maxVal - priceGap
            }else{
                rangeInput[1].value = minVal + priceGap;
            }
        }else{
            priceInput[0].value = minVal;
            priceInput[1].value = maxVal;
            range.style.left = ((minVal / rangeInput[0].max) * 100) + "%";
            range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
        }
    });
});
jQuery(document).ready(function($){
	$('.loop-whatsapp-close').on('click',function(){
		$(this).parent().parent().hide();
	})
	$('.btn-whataspp-open-loop').on('click',function(){
		let id = $(this).data('target');
		$(id).show();
	})
})
		jQuery(function($){
	$('.new-posts-b').owlCarousel({
            loop:true,
            margin:0,
            nav:true,
			dots:false,
			
            rtl:false,
            responsive:{
            0:{
            items:1,
			margin:5,
            },
            600:{
            items:2,
				margin:5,
            },
            900:{
            items:4
            }
            }
            })
});
});</script>

<footer class="dxb-footer pt-3 mt-4 border-top border-light">

    <div class="container">
		<div class="">
			<div class="row">
				<div class="col-md-6 d-flex gap-3 footer-top-flex">
							<div class="first top">
															<ul class="social-footers">
						<li class="twitter">
							<a href="https://twitter.com/dxboffplan?s=21&t=7HHVMvcXdURuA16PdpefdQ">
								<svg xmlns="http://www.w3.org/2000/svg" width="25.136" height="20.419" viewBox="0 0 25.136 20.419">
  <path id="__TEMP__SVG__" d="M25.136,2.419A10.442,10.442,0,0,1,22.56,5.082q.015.3.015.667a14.813,14.813,0,0,1-2.445,8.109,15.667,15.667,0,0,1-2.952,3.358,13.16,13.16,0,0,1-4.118,2.333,15.041,15.041,0,0,1-5.155.87A14.353,14.353,0,0,1,0,18.1a11.15,11.15,0,0,0,1.23.071,10.111,10.111,0,0,0,6.405-2.209,5,5,0,0,1-2.995-1.029,5.068,5.068,0,0,1-1.82-2.552A5.155,5.155,0,0,0,5.149,12.3a5.026,5.026,0,0,1-2.96-1.777A4.99,4.99,0,0,1,1.013,7.242V7.178a5.089,5.089,0,0,0,2.336.645A5.123,5.123,0,0,1,1.674,5.986a5.032,5.032,0,0,1-.619-2.452,5.067,5.067,0,0,1,.7-2.591,14.683,14.683,0,0,0,4.7,3.806,14.33,14.33,0,0,0,5.926,1.583,5.043,5.043,0,0,1-.135-1.174,4.968,4.968,0,0,1,1.511-3.645,5.159,5.159,0,0,1,7.41.115A10.271,10.271,0,0,0,24.439.375a4.986,4.986,0,0,1-2.265,2.854,10.306,10.306,0,0,0,2.962-.81Z" fill="#171717"/>
</svg>

							</a>
						</li>
						<li class="youtube">
							<a href="https://youtube.com/@dxboffplan?feature=shared">
<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="25" height="25" viewBox="0 0 64 64">
<path d="M56.456,17.442c-0.339-1.44-1.421-2.595-2.866-3.053C49.761,13.174,41.454,12,32,12s-17.761,1.174-21.591,2.389 c-1.445,0.458-2.527,1.613-2.866,3.053C6.903,20.161,6,25.203,6,32c0,6.797,0.903,11.839,1.544,14.558 c0.339,1.44,1.421,2.595,2.866,3.053C14.239,50.826,22.546,52,32,52s17.761-1.174,21.591-2.389 c1.445-0.458,2.527-1.613,2.866-3.053C57.097,43.839,58,38.797,58,32C58,25.203,57.097,20.161,56.456,17.442z M27,40V24l14.857,8 L27,40z"></path>
</svg>


							</a>
						</li>
						<li class="instagram">
							<a href="https://www.instagram.com/dxboffplan.official/">
								<svg id="icons_Q2" data-name="icons Q2" xmlns="http://www.w3.org/2000/svg" width="22.199" height="22.123" viewBox="0 0 22.199 22.123">
  <path id="Path_246" data-name="Path 246" d="M15.1,6h4.5a6,6,0,0,1,2.053.388,3.717,3.717,0,0,1,2.109,2.107,5.983,5.983,0,0,1,.388,2.052c.056,1.164.056,1.552.056,4.491s0,3.327-.055,4.491a5.983,5.983,0,0,1-.388,2.052,3.717,3.717,0,0,1-2.109,2.107,6,6,0,0,1-2.053.388H10.6a6,6,0,0,1-2.053-.388,3.717,3.717,0,0,1-2.109-2.107,5.983,5.983,0,0,1-.388-2.052C6,18.361,6,17.972,6,15.034s0-3.327.055-4.491a5.983,5.983,0,0,1,.388-2.052A3.717,3.717,0,0,1,8.551,6.384,6,6,0,0,1,10.6,6h4.5m0-2H10.549a9.943,9.943,0,0,0-2.719.5A5.55,5.55,0,0,0,5.887,5.885,4.713,4.713,0,0,0,4.61,7.826a8.033,8.033,0,0,0-.555,2.717C4,11.707,4,12.1,4,15.089s0,3.382.055,4.547a8.033,8.033,0,0,0,.555,2.717,4.713,4.713,0,0,0,1.276,1.941,4.718,4.718,0,0,0,1.942,1.275,8.054,8.054,0,0,0,2.719.554h9.1a8.054,8.054,0,0,0,2.719-.554,4.718,4.718,0,0,0,1.942-1.275,5.544,5.544,0,0,0,1.332-1.941,9.917,9.917,0,0,0,.5-2.717c.055-1.164.055-1.552.055-4.547s0-3.382-.055-4.547a9.917,9.917,0,0,0-.5-2.717,5.544,5.544,0,0,0-1.332-1.941A5.55,5.55,0,0,0,22.37,4.554a9.943,9.943,0,0,0-2.719-.5H15.1" transform="translate(-4 -4)" fill="#171717"/>
  <path id="Path_247" data-name="Path 247" d="M19.285,13.7a5.585,5.585,0,1,0,5.585,5.585A5.585,5.585,0,0,0,19.285,13.7m0,9.218a3.633,3.633,0,1,1,3.633-3.633,3.633,3.633,0,0,1-3.633,3.633" transform="translate(-8.363 -8.363)" fill="#171717"/>
  <path id="Path_248" data-name="Path 248" d="M35.959,12.73a1.83,1.83,0,1,1-1.83-1.83,1.83,1.83,0,0,1,1.83,1.83" transform="translate(-17.484 -7.27)" fill="#171717"/>
</svg>


							</a>
						</li>
						<li class="linkdin">
							<a href="https://ae.linkedin.com/company/dxb-offplan">
								<svg xmlns="http://www.w3.org/2000/svg" width="22.053" height="22.053" viewBox="0 0 22.053 22.053">
  <path id="__TEMP__SVG__" d="M4.328.009A4.335,4.335,0,0,0,.007,4.331V17.741a4.334,4.334,0,0,0,4.322,4.321H17.739a4.333,4.333,0,0,0,4.321-4.321V4.331A4.334,4.334,0,0,0,17.739.009ZM5.415,3.648A1.737,1.737,0,1,1,5.393,7.11H5.372a1.736,1.736,0,1,1,.044-3.462Zm9.82,4.6c2.192,0,3.834,1.432,3.834,4.511V18.5h-3.33V13.14c0-1.347-.482-2.266-1.687-2.266a1.824,1.824,0,0,0-1.709,1.218,2.274,2.274,0,0,0-.11.813v5.6H8.9s.044-9.081,0-10.021h3.331V9.9a3.306,3.306,0,0,1,3-1.654ZM3.728,8.48h3.33V18.5H3.728V8.48Z" transform="translate(-0.007 -0.009)" fill="#171717"/>
</svg>


							</a>
						</li>
					</ul>
		</div>
					<div class="second">
						
					
					<img src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E" class="footer-logo" data-lazy-src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/logo/dxboffplan-logo-b.png"><noscript><img src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/img/logo/dxboffplan-logo-b.png" class="footer-logo"></noscript>
					<div class="seprator">
						
					</div>
					<p class="text-justify">
<!-- 						<span class="color-yellow"> DXB OFFPLAN  </span> -->
						Welcome on board with dxboffplan.com, your one-stop property portal in Dubai! Dxboffplan is the ultimate hub for off plan property information, advertisement and selling, that too, in three different languages i.e. English, Arabic, and Persian. Featuring a plethora of off plan properties to choose from, dxboffplan works along several horizontal and vertical differentiation divisions to help customers choose the best property price, location, requirement, and convenience wise.					</p>
				</div>
					</div>
				<div class="col-md-6 col-12">
					<div class="d-block d-md-none">
					    <div class="steps-bg-footer">
		   <div class="steps-pagination-footer">
                <ul class="pagination-list-footer">
                    <li class="active"></li>
                    <li></li>
                </ul>
            </div>
        <div class="steps-pt-footer" style="width: 500px; height: 450px;max-width:100%">
            <div class="step-footer-0 steps-footer active">
                <span class="step-title">I am interested to</span>
                <section class="choices-footer">
                    <div class="choice-footer active">
                        <div class="choice-icon">
                            <svg viewBox="0 0 19.213 18.176" class="ActiveChoice">
                                <path d="M8.066,11.625h5.285A7.362,7.362,0,0,1,17.565,13l1.649,1.18V12.338l-.775-.555a8.885,8.885,0,0,0-2.5-1.251A2.113,2.113,0,0,0,16.209,9.5v-2.7l.5.458,1.012-1.109L11.538.5,5.353,6.142,6.364,7.251l.5-.458V9.5a2.112,2.112,0,0,0,.194.885,2.117,2.117,0,0,0-.845.85L3.83,8.889A2.252,2.252,0,1,0,.676,12.1l5.57,5.466a3.846,3.846,0,0,0,2.709,1.107H19.214v-1.5H8.955A2.353,2.353,0,0,1,7.3,16.5l-5.57-5.466A.75.75,0,1,1,2.778,9.96l3.6,3.535.007-.007a2.1,2.1,0,0,0,.5.475,2.888,2.888,0,0,0,1.012.456c.231.043,4.223.466,5.929.646l.158-1.493c-2.19-.231-5.529-.588-5.82-.631a1.522,1.522,0,0,1-.433-.219.6.6,0,0,1,.338-1.1Zm3.472-9.093,3.17,2.892V9.5a.626.626,0,0,1-.625.625H8.993A.626.626,0,0,1,8.367,9.5V5.424ZM12.76,8.394h-2.4v-2.4h2.4Zm0,0" transform="translate(-0.001 -0.5)"></path>
                            </svg>
                        </div>
                        <span>Buy</span>
                    </div>
                    <div class="choice-footer">
                        <div class="choice-icon">
                            <svg viewBox="0 0 18.78 18.761" class="">
                                <path d="M18.78,9.565,9.39,1,0,9.565l.987,1.082.855-.778v7.7a2.2,2.2,0,0,0,2.2,2.2h10.7a2.2,2.2,0,0,0,2.2-2.2v-7.7l.855.778Zm-3.308,8a.736.736,0,0,1-.734.734H4.038a.736.736,0,0,1-.734-.734V8.534L9.39,2.984l6.081,5.55Z" transform="translate(0 -1)"></path>
                            </svg>
                        </div>
                        <span>Sell</span>
                    </div>
                </section>
                <button type="button" class="button button-primary is-blicked wizard-nav-footer" data-id="0" style="background-color: var(--color-yellow)">
                    Continue                    <span class="icon rightIcon">
                        <svg viewBox="0 0 512 511">
                            <path d="M23.1,501V384.7c0-60.7,23.7-117.8,66.6-160.8c42.9-42.9,100-66.6,160.8-66.6h14.6V10l223.8,245.4L265.1,500.8V353.7                        c-71.4,3.1-139.1,34.6-187.5,87.6L23.1,501z M250.5,201.3c-101.1,0-183.4,82.3-183.4,183.4v5.2c57.2-51.4,132.1-80.4,209.6-80.4                        h32.4v77.8l120.3-131.9L309.1,123.5v77.8H250.5z"></path>
                        </svg>
                    </span>
                </button>
            </div>
            <div class="step-footer-1 steps-footer">
                <span class="step-title">Amazing, give us a way to contact you</span>
                <div class="form">
                    <div class="form-group validate-input">
                        <svg id="input-close" class="empty-input" viewBox="0 0 20 20" style="fill: var(--color-yellow)">
                            <path fill="#343a40" d="M8.882,7.821l6.541-6.541c0.293-0.293,0.293-0.768,0-1.061  c-0.293-0.293-0.768-0.293-1.061,0L7.821,6.76L1.28,0.22c-0.293-0.293-0.768-0.293-1.061,0c-0.293,0.293-0.293,0.768,0,1.061  l6.541,6.541L0.22,14.362c-0.293,0.293-0.293,0.768,0,1.061c0.147,0.146,0.338,0.22,0.53,0.22s0.384-0.073,0.53-0.22l6.541-6.541  l6.541,6.541c0.147,0.146,0.338,0.22,0.53,0.22c0.192,0,0.384-0.073,0.53-0.22c0.293-0.293,0.293-0.768,0-1.061L8.882,7.821z"></path>
                        </svg>
                        <input type="text" class="input name" name="name" placeholder="Name" />
                        <span class="alert">Valid name is required!</span>
                        <svg viewBox="0 0 24 24" class="mdi-icon mdi-36px" style="fill: var(--color-yellow)">
                            <title>mdi-account</title>
                            <path d="M12,4C14.21,4 16,5.79 16,8C16,10.21 14.21,12 12,12C9.79,12 8,10.21 8,8C8,5.79 9.79,4 12,4M12,14C16.42,14 20,15.79 20,18V20H4V18C4,15.79 7.58,14 12,14Z" stroke-width="0" fill-rule="nonzero"></path>
                        </svg>
                    </div>
                    <div class="form-group validate-input">
                        <svg id="input-close" class="empty-input" viewBox="0 0 20 20" style="fill: var(--color-yellow)">
                            <path fill="#343a40" d="M8.882,7.821l6.541-6.541c0.293-0.293,0.293-0.768,0-1.061  c-0.293-0.293-0.768-0.293-1.061,0L7.821,6.76L1.28,0.22c-0.293-0.293-0.768-0.293-1.061,0c-0.293,0.293-0.293,0.768,0,1.061  l6.541,6.541L0.22,14.362c-0.293,0.293-0.293,0.768,0,1.061c0.147,0.146,0.338,0.22,0.53,0.22s0.384-0.073,0.53-0.22l6.541-6.541  l6.541,6.541c0.147,0.146,0.338,0.22,0.53,0.22c0.192,0,0.384-0.073,0.53-0.22c0.293-0.293,0.293-0.768,0-1.061L8.882,7.821z"></path>
                        </svg>
                        <input type="email" class="input email" name="email" placeholder="Email Address" />
                        <span class="alert">Valid email is required!</span>
                        <svg viewBox="0 0 24 24" class="mdi-icon mdi-36px" style="fill: var(--color-yellow)">
                            <title>mdi-email</title>
                            <path d="M20,8L12,13L4,8V6L12,11L20,6M20,4H4C2.89,4 2,4.89 2,6V18C2,19.1 2.9,20 4,20H20C21.1,20 22,19.1 22,18V6C22,4.89 21.1,4 20,4Z" stroke-width="0" fill-rule="nonzero"></path>
                        </svg>
                    </div>
                    <div class="form-group validate-input">
                        <svg id="input-close" class="empty-input" viewBox="0 0 20 20" style="fill: var(--color-yellow)">
                            <path fill="#343a40" d="M8.882,7.821l6.541-6.541c0.293-0.293,0.293-0.768,0-1.061  c-0.293-0.293-0.768-0.293-1.061,0L7.821,6.76L1.28,0.22c-0.293-0.293-0.768-0.293-1.061,0c-0.293,0.293-0.293,0.768,0,1.061  l6.541,6.541L0.22,14.362c-0.293,0.293-0.293,0.768,0,1.061c0.147,0.146,0.338,0.22,0.53,0.22s0.384-0.073,0.53-0.22l6.541-6.541  l6.541,6.541c0.147,0.146,0.338,0.22,0.53,0.22c0.192,0,0.384-0.073,0.53-0.22c0.293-0.293,0.293-0.768,0-1.061L8.882,7.821z"></path>
                        </svg>
                        <input type="text" class="input mobile" name="mobile" inputmode="tel" placeholder="Mobile" />
                        <span class="alert">Valid phone is required!</span>
                        <svg viewBox="0 0 512 512" style="fill: var(--color-yellow)">
                            <path d="M169.2,99.8c-2.7-2.7-5.8-5.8-8.5-8.8l0,0c-5.4-5.5-11.5-11.7-17.8-17.6c-10.6-10.4-23.2-15.9-36.5-15.9                                    c-13.5,0-26.3,5.5-37,15.8l-32.1,32.4c-13.3,13.3-20.9,29.5-22.5,48.2c-2.4,28.6,5.9,55.1,12.4,72.5C42.6,268.3,65.7,307,99.8,348                                    c41.5,49.7,91.7,89,149,116.7c22.3,10.5,52.1,22.9,84.9,25l0.5,0c2.1,0.1,4,0.2,5.9,0.2c23.8,0,43.8-8.6,59.4-25.6l0.6-0.7l0.1-0.3                                    l0.2-0.3c4.2-5,9.1-9.8,14.1-14.7l1.3-1.2c5-4.8,8.9-8.6,12.3-12.2c10.6-11,16.3-24,16.3-37.5c0-13.7-5.7-26.6-16.6-37.4                                    l-51.1-51.5c-10.5-10.9-23.3-16.7-37-16.7c-13.5,0-26.4,5.7-37.3,16.6l-25.8,25.7l-1.4-0.9c-0.2-0.1-0.4-0.2-0.5-0.3l-0.4-0.1                                    l-0.2-0.2c-2.9-1.4-5.8-3-8.3-4.4c-26.9-17.1-51.5-39.5-75.1-68.4c-9-11.4-15.8-21.6-21.3-32l-0.7-1.3l1.1-1                                    c5.2-4.9,10.1-9.9,14.8-14.7l2-2c1.3-1.3,2.7-2.7,3.9-4c1.3-1.3,2.6-2.6,3.8-3.9c11.2-11.2,17-24.2,17-37.8                                    c0-13.5-5.9-26.5-17-37.5L169.2,99.8z M166.2,172.1L166.2,172.1c-0.9,0.9-1.8,1.8-2.6,2.7l-0.1,0.1l-5.4,5.4                                    c-8.6,8.8-15.5,15.7-23.1,22.5l-0.2,0.2c-0.1,0.1-0.4,0.4-0.9,0.9l-0.1,0.1c-7.6,7.8-9.7,17.3-6.3,28.3l0.6,1.5                                    c6.8,16.5,16.5,32.3,31.2,51l0.4,0.5c26.2,32.2,53.8,57.3,84.5,76.8c3.8,2.5,7.8,4.4,11.3,6.2l0.8,0.4c2.6,1.3,5.9,3,8.6,4.6                                    l0.5,0.3c0.3,0.2,0.8,0.5,1.2,0.8c4.2,2.1,8.3,3.1,12.5,3.1c7.2,0,13.8-2.9,19.5-8.6l32-32c3.1-3.1,6.2-4.8,8.8-4.8                                    c3.5,0,6.7,3.2,7.7,4.2l0.1,0.1l52,52c4.2,4.2,7.4,8.9,2.6,15.6l-0.6,0.8h-2.5l-1,3.8l-0.4,0.4c-2.6,2.7-5,5.1-7.4,7.3l-2.1,2                                    c-5.8,5.6-12.3,11.9-18.4,19l-0.1,0.1c-8,8.5-17.1,12.3-29.6,12.3c-1.3,0-2.7,0-3.9-0.1c-26.2-1.7-51.2-12.2-70.1-21.1                                    c-52-25.1-97.5-60.8-135.5-106.1c-31.3-37.8-52.3-72.7-66-109.9c-8.2-22.2-11.3-39.2-10-55.3c0.7-9,4.2-16.6,10.7-23.1L97,102.1                                    c3.2-3,6.3-4.6,9-4.6c2.6,0,5.4,1.5,8.3,4.4l0.5,0.5c5.4,5,10.7,10.4,16.5,16.4c1.5,1.5,3,3,4.5,4.6c0.7,0.7,1.4,1.5,2.2,2.2                                    c0.7,0.7,1.4,1.5,2.2,2.2l25.6,25.6c4,3.9,5.6,6.7,5.6,9.6C171.4,166.5,168.9,169.5,166.2,172.1z"></path>
                            <path d="M276.2,114.9c-0.8,4.5,0.3,9.2,2.8,12.8c2.6,3.6,6.5,6,11,6.8c19.7,3.3,37.6,12.7,51.9,27c14.2,14.2,23.5,32.2,27,51.9                                    c1.4,8.2,8.4,14.1,16.7,14.1c1,0,1.8-0.1,2.4-0.2l0.4-0.1c4.5-0.8,8.4-3.2,11-6.9c2.6-3.7,3.6-8.1,2.9-12.7                                    c-4.5-26.6-17.1-50.9-36.4-70.2c-19.2-19.2-43.5-31.8-70.3-36.4C286.7,99.6,277.9,105.8,276.2,114.9z"></path>
                            <path d="M412.4,91.1C381.3,60,342,39.6,298.9,32.2c-4.4-0.8-8.9,0.2-12.6,2.8c-3.7,2.6-6.1,6.4-6.9,10.8l0,0.2                                    c-1.5,9.3,4.6,17.9,14,19.6c36,6.1,68.9,23.1,95.1,49.4c26.1,26.1,43.2,59,49.4,95.2c1.4,8.2,8.4,14.1,16.7,14.1                                    c1,0,1.7-0.1,2.3-0.1l0.4-0.1c4.6-0.7,8.5-3.1,11-6.8c2.7-3.7,3.8-8.1,3-12.7v0C463.9,161.5,443.5,122.2,412.4,91.1z"></path>
                        </svg>
                    </div>
                </div>
                <button type="submit" class="button button-primary is-blicked submit-footer" id="submitFormNewCbFooter" data-id="2" style="background-color: var(--color-yellow)">
                    <span class="icon"><svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                            <path d="M20,12C20,16.42 16.42,20 12,20C7.58,20 4,16.42 4,12C4,7.58 7.58,4 12,4C12.76,4 13.5,4.11 14.2,4.31L15.77,2.74C14.61,2.26 13.34,2 12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z" stroke-width="0" fill-rule="nonzero"></path>
                        </svg></span>
                    Submit                </button>
            </div>
            <div class="step-footer-2 steps-footer">
                <div class="thanks">
                    <svg viewBox="0 0 489.2 489.2" style="fill: var(--color-yellow)">
                        <path d="M425.1,220.8l-23.9-32.7c-1.5-2.1-1.6-5-0.1-7.1l23.4-33c2.1-3,1.1-7.2-2.1-8.9L386.7,120c-2.3-1.2-3.6-3.8-3.1-6.4                            l6.7-39.9c0.6-3.6-2.1-7-5.8-7.1l-40.4-1.7c-2.6-0.1-4.9-1.9-5.6-4.4l-11.2-39c-1-3.5-4.9-5.4-8.3-3.9l-37.2,16                            c-2.4,1-5.2,0.4-7-1.5L247.8,2c-2.5-2.7-6.7-2.7-9.2,0.1L212,32.6c-1.7,2-4.5,2.6-6.9,1.6l-37.4-15.4c-3.4-1.4-7.2,0.5-8.2,4                            l-10.7,39c-0.7,2.5-2.9,4.3-5.5,4.5l-40.4,2.3c-3.7,0.2-6.3,3.6-5.7,7.2l7.3,39.8c0.5,2.6-0.8,5.2-3,6.4l-35.4,19.6                            c-3.2,1.8-4.1,6-2,8.9L88,183.2c1.5,2.1,1.6,5,0.1,7.1l-23.4,33c-2.1,3-1.1,7.2,2.1,8.9l35.7,19.1c2.3,1.2,3.6,3.8,3.1,6.4                            l-6.7,39.9c-0.6,3.6,2.1,7,5.8,7.1l40.4,1.7c2.6,0.1,4.9,1.9,5.6,4.4l11.3,38.9c1,3.5,4.9,5.4,8.3,3.9l37.2-16                            c2.4-1,5.2-0.4,7,1.5l27,30.1c2.5,2.7,6.7,2.7,9.2-0.1l26.6-30.5c1.7-2,4.5-2.6,6.9-1.6l37.4,15.4c3.4,1.4,7.2-0.5,8.2-4l10.7-39                            c0.7-2.5,2.9-4.3,5.5-4.5l40.4-2.3c3.7-0.2,6.3-3.6,5.7-7.2l-7.3-39.8c-0.5-2.6,0.8-5.2,3-6.4l35.4-19.6                            C426.4,228,427.3,223.8,425.1,220.8z M244.7,315.4c-71.5,0-129.7-58.2-129.7-129.7S173.2,56,244.7,56s129.7,58.2,129.7,129.7                            C374.4,257.3,316.1,315.4,244.7,315.4z"></path>
                        <path d="M343.6,366.5c-5.8,5.9-13.9,9.4-22.6,9.4c-3.1,0-6.2-0.5-9.1-1.3l-25.8-7.8L266.2,385c-0.7,0.6-1.3,1.2-2,1.7l32,99.2                            c1.1,3.5,5.6,4.3,7.9,1.4l23.3-29.9c1.1-1.5,3.1-2.1,4.8-1.6l36.3,10.6c3.5,1,6.7-2.3,5.6-5.7L343.6,366.5z"></path>
                        <path d="M203.4,366.8l-25.8,7.8c-3,0.9-6,1.3-9.1,1.3c-8.7,0-16.7-3.5-22.6-9.4l-30.5,94.3c-1.1,3.5,2.1,6.7,5.6,5.7l36.3-10.6                            c1.8-0.5,3.7,0.1,4.8,1.6l23.3,29.9c2.2,2.9,6.8,2.1,7.9-1.4l32-99.2c-0.7-0.5-1.4-1.1-2-1.7L203.4,366.8z"></path>
                        <path d="M309.8,158.4l-41.4-3L252.8,117c-2.9-7.2-13.2-7.2-16.1,0l-15.6,38.4l-41.4,3c-7.8,0.6-10.9,10.3-5,15.3l31.7,26.8                            l-9.9,40.3c-1.9,7.6,6.4,13.6,13,9.5l35.2-21.9l35.2,21.9c6.6,4.1,14.9-1.9,13-9.5l-9.9-40.3l31.7-26.8                            C320.7,168.7,317.6,159,309.8,158.4z"></path>
                    </svg>
                    <span class="step-title">Thanks for your interest.</span>
                    <p>
                        One of our representative will contact you soon on given details.                    </p>
                    <button type="button" class="button button-primary is-blicked close-wizard-footer" style="background-color: var(--color-yellow)">
                        Close.                    </button>
                </div>
            </div>
			<input type="hidden" class="post-footer" hidden name="post" value="142235">
		<input type="hidden" class="contact_location-footer" name="contact_location" value="NL" > 
        <input type="hidden" class="contact_ip-footer" name="contact_ip"  value="198.211.121.217"> 
        </div>
    </div>					</div>
					<div class="d-md-block d-none">
					<p class="quick-access-title">
						quick access					</p>
					<!-- Bootstrap 5 Nav Walker Footer Menu -->
       <div class="row">
		  <div class="col-6">
			  <ul id="footer-menu" class="nav "><li  id="menu-item-82667" class="menu-item menu-item-type-post_type menu-item-object-development nav-item nav-item-82667"><a href="https://dxboffplan.com/development/palm-jumeirah/" class="nav-link ">Property for Sale in Palm Jumeirah</a></li>
<li  id="menu-item-82668" class="menu-item menu-item-type-post_type menu-item-object-development nav-item nav-item-82668"><a href="https://dxboffplan.com/development/downtown-dubai/" class="nav-link ">Property for Sale in Downtown Dubai</a></li>
<li  id="menu-item-82669" class="menu-item menu-item-type-post_type menu-item-object-development nav-item nav-item-82669"><a href="https://dxboffplan.com/development/business-bay/" class="nav-link ">Property for Sale in Business Bay</a></li>
<li  id="menu-item-82670" class="menu-item menu-item-type-post_type menu-item-object-development nav-item nav-item-82670"><a href="https://dxboffplan.com/development/dubai-hills-estate/" class="nav-link ">Property for Sale in Dubai Hills Estate</a></li>
<li  id="menu-item-83328" class="menu-item menu-item-type-custom menu-item-object-custom nav-item nav-item-83328"><a href="https://dxboffplan.com/development/kartal/" class="nav-link ">Property for sale in Kartal</a></li>
<li  id="menu-item-83329" class="menu-item menu-item-type-custom menu-item-object-custom nav-item nav-item-83329"><a href="https://dxboffplan.com/development/pendik/" class="nav-link ">Property for sale in Pendik</a></li>
<li  id="menu-item-83330" class="menu-item menu-item-type-custom menu-item-object-custom nav-item nav-item-83330"><a href="https://dxboffplan.com/development/al-mouj-muscat/" class="nav-link ">Property for sale in Al Mouj Muscat</a></li>
</ul>		  </div>
		  <div class="col-6">
			  <ul id="footer-menu" class="nav "><li  class="menu-item menu-item-type-post_type menu-item-object-development nav-item nav-item-82667"><a href="https://dxboffplan.com/development/palm-jumeirah/" class="nav-link ">Property for Sale in Palm Jumeirah</a></li>
<li  class="menu-item menu-item-type-post_type menu-item-object-development nav-item nav-item-82668"><a href="https://dxboffplan.com/development/downtown-dubai/" class="nav-link ">Property for Sale in Downtown Dubai</a></li>
<li  class="menu-item menu-item-type-post_type menu-item-object-development nav-item nav-item-82669"><a href="https://dxboffplan.com/development/business-bay/" class="nav-link ">Property for Sale in Business Bay</a></li>
<li  class="menu-item menu-item-type-post_type menu-item-object-development nav-item nav-item-82670"><a href="https://dxboffplan.com/development/dubai-hills-estate/" class="nav-link ">Property for Sale in Dubai Hills Estate</a></li>
<li  class="menu-item menu-item-type-custom menu-item-object-custom nav-item nav-item-83328"><a href="https://dxboffplan.com/development/kartal/" class="nav-link ">Property for sale in Kartal</a></li>
<li  class="menu-item menu-item-type-custom menu-item-object-custom nav-item nav-item-83329"><a href="https://dxboffplan.com/development/pendik/" class="nav-link ">Property for sale in Pendik</a></li>
<li  class="menu-item menu-item-type-custom menu-item-object-custom nav-item nav-item-83330"><a href="https://dxboffplan.com/development/al-mouj-muscat/" class="nav-link ">Property for sale in Al Mouj Muscat</a></li>
</ul>		  </div>
					</div>
						</div>
      <!-- Bootstrap 5 Nav Walker Footer Menu End -->
				</div>
			</div>
		</div>

    </div>
	<div class="copy-right">
				<div class="made-love">Dxboffplan Made with <span class="fa fa-heart"> </span>In Dubai</div>
			</div>
</footer>

<div class="top-button position-fixed zi-1020">
  <a href="#to-top" class="btn btn-primary shadow"><i class="fas fa-chevron-up"></i><span class="visually-hidden-focusable">To top</span></a>
</div>

</div><!-- #page -->

<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/bootscore-child-main-new/*","/wp-content/themes/bootscore-main/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>

<!-- GTM Container placement set to footer -->
<!-- Google Tag Manager (noscript) -->
				<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WQXQFBL" height="0" width="0" style="display:none;visibility:hidden" aria-hidden="true"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><div class="contact-form-div">
    <form id="contact-form" method="POST">
        <span class="btn btn-danger close-contact float-end"> <i class="fa fa-times"></i> </span>
        <p id="cont-title">
            <strong> Callback Request : </strong><span id="callback-for"></span>
        </p>
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="contact_name"> Name </label>
                    <input class="form-control" id="contact_name" name="contact_name" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="contact_phone"> Mobile </label>
                    <input class="form-control" id="contact_phone" name="contact_phone" required>
                </div>
            </div>
        </div>
        <div class="form-group mb-3">
            <label for="contact_email"> Email Address </label>
            <input class="form-control" id="contact_email" name="contact_email" required>
        </div>
        <div class="form-group mb-3">
            <label for="contact_message"> Message </label>
            <input class="form-control" id="contact_message" name="contact_message" required>
        </div>
        <div class="form-group mb-3">
            <select class="form-control" id="contact_role" name="contact_role" required>
                <option value="" diasbled selected> -- Select Role --   </option>
				<option> I am an agent  </option>
				<option> I am a potential Buyer   </option>
				<option> I just exploring   </option>
            </select>
        </div>
        <div>
            <input type="hidden" name="contact_post" id="contact_post" value="9" > 
            <input type="hidden" name="contact_location" id="contact_location" value="NL" > 
            <input type="hidden" name="contact_ip" id="contact_ip"  value="198.211.121.217"> 
            <input type="hidden" name="contact_type" id="contact_type"> 
            <input type="hidden" name="download_file" id="download_file"> 
            <input type="hidden" name="clicked_title" id="clicked_title"> 
               <input type="hidden" id="call_back_field" name="call_back_field" value="ac53a6624a" /><input type="hidden" name="_wp_http_referer" value="/" />            <button type="submit" class="btn w-100 btn-primary py-2"> Send </button>
        </div>
    </form>
</div><script>window.addEventListener('DOMContentLoaded', function() {
	jQuery(".cm_language").val("en")
});</script>
			<script data-category="functional">
											</script>
			<script type="text/javascript" src="https://dxboffplan.com/wp-includes/js/dist/hooks.min.js?ver=dd5603f07f9220ed27f1" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://dxboffplan.com/wp-includes/js/dist/i18n.min.js?ver=c26c3dc7bed366793375" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
/* ]]> */
</script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.5" id="swv-js" defer></script>
<script type="text/javascript" id="contact-form-7-js-before">
/* <![CDATA[ */
var wpcf7 = {
    "api": {
        "root": "https:\/\/dxboffplan.com\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
//# sourceURL=contact-form-7-js-before
/* ]]> */
</script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.5" id="contact-form-7-js" defer></script>
<script type="text/javascript" id="kk-star-ratings-js-extra">
/* <![CDATA[ */
var kk_star_ratings = {"action":"kk-star-ratings","endpoint":"https://dxboffplan.com/wp-admin/admin-ajax.php","nonce":"a8dba1b1fc"};
//# sourceURL=kk-star-ratings-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/plugins/kk-star-ratings/src/core/public/js/kk-star-ratings.min.js?ver=5.4.10.3" id="kk-star-ratings-js" defer></script>
<script type="text/javascript" src="https://connect.livechatinc.com/api/v1/script/2f43ef59-19f3-49d4-bf5a-46f562704cf1/widget.js?lcv=a44e8afa-8f31-42af-8373-2d6e3bd65fe8&amp;ver=5.0.11" id="text-legacy-widget-js" defer></script>
<script type="text/javascript" id="rocket-browser-checker-js-after">
/* <![CDATA[ */
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
//# sourceURL=rocket-browser-checker-js-after
/* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-extra">
/* <![CDATA[ */
var RocketPreloadLinksConfig = {"excludeUris":"/properties/mews-mansions-meydan-dubai/|/properties/mews-mansions-meydan-dubai1/|/properties/mansions-meydan-dubai/|/properties/test33/|/(?:.+/)?feed(?:/(?:.+/?)?)?$|/(?:.+/)?embed/|/(index.php/)?(.*)wp-json(/.*|$)|/refer/|/go/|/recommend/|/recommends/","usesTrailingSlash":"1","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php|html|htm","siteUrl":"https://dxboffplan.com","onHoverDelay":"100","rateThrottle":"3"};
//# sourceURL=rocket-preload-links-js-extra
/* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-after">
/* <![CDATA[ */
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());

//# sourceURL=rocket-preload-links-js-after
/* ]]> */
</script>
<script type="text/javascript" id="custom-js-js-extra">
/* <![CDATA[ */
var md_ajax_object = {"ajax_url":"https://dxboffplan.com/wp-admin/admin-ajax.php"};
//# sourceURL=custom-js-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/js/custom.js?v=1774703204&amp;ver=1774703204" id="custom-js-js" defer></script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/themes/bootscore-child-main-new/select2/select2.min.js?ver=2.3.4" id="select2-js-js" defer></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?language=en&amp;libraries=places&amp;ver=1.0.0&amp;key=AIzaSyBvd8uy9lZQX-JphXDsK9czquozpYEIRpQ&amp;callback=rgmkInitGoogleMaps" id="map-js-js" defer></script>
<script type="text/javascript" src="https://unpkg.com/leaflet/dist/leaflet.js" id="leaflet-js-js" defer></script>
<script type="text/javascript" src="https://dxboffplan.com/wp-includes/js/comment-reply.min.js?ver=6.9.4" id="comment-reply-js" async="async" data-wp-strategy="async" fetchpriority="low"></script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/themes/bootscore-main/js/lib/bootstrap.bundle.min.js?ver=202308111823" id="bootstrap-js" defer></script>
<script type="text/javascript" id="bootscore-script-js-extra">
/* <![CDATA[ */
var bootscore = {"ie_title":"Internet Explorer detected","ie_limited_functionality":"This website will offer limited functionality in this browser.","ie_modern_browsers_1":"Please use a modern and secure web browser like","ie_modern_browsers_2":" \u003Ca href=\"https://www.mozilla.org/firefox/\" target=\"_blank\"\u003EMozilla Firefox\u003C/a\u003E, \u003Ca href=\"https://www.google.com/chrome/\" target=\"_blank\"\u003EGoogle Chrome\u003C/a\u003E, \u003Ca href=\"https://www.opera.com/\" target=\"_blank\"\u003EOpera\u003C/a\u003E ","ie_modern_browsers_3":"or","ie_modern_browsers_4":" \u003Ca href=\"https://www.microsoft.com/edge\" target=\"_blank\"\u003EMicrosoft Edge\u003C/a\u003E ","ie_modern_browsers_5":"to display this site correctly."};
//# sourceURL=bootscore-script-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/themes/bootscore-main/js/theme.js?ver=202306012239" id="bootscore-script-js" defer></script>
<script type="text/javascript" src="https://dxboffplan.com/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js" defer></script>
<script type="text/javascript" src="https://dxboffplan.com/wp-content/plugins/megamenu/js/maxmegamenu.js?ver=3.8.1" id="megamenu-js" defer></script>
<script>window.lazyLoadOptions=[{elements_selector:"img[data-lazy-src],.rocket-lazyload",data_src:"lazy-src",data_srcset:"lazy-srcset",data_sizes:"lazy-sizes",class_loading:"lazyloading",class_loaded:"lazyloaded",threshold:300,callback_loaded:function(element){if(element.tagName==="IFRAME"&&element.dataset.rocketLazyload=="fitvidscompatible"){if(element.classList.contains("lazyloaded")){if(typeof window.jQuery!="undefined"){if(jQuery.fn.fitVids){jQuery(element).parent().fitVids()}}}}}},{elements_selector:".rocket-lazyload",data_src:"lazy-src",data_srcset:"lazy-srcset",data_sizes:"lazy-sizes",class_loading:"lazyloading",class_loaded:"lazyloaded",threshold:300,}];window.addEventListener('LazyLoad::Initialized',function(e){var lazyLoadInstance=e.detail.instance;if(window.MutationObserver){var observer=new MutationObserver(function(mutations){var image_count=0;var iframe_count=0;var rocketlazy_count=0;mutations.forEach(function(mutation){for(var i=0;i<mutation.addedNodes.length;i++){if(typeof mutation.addedNodes[i].getElementsByTagName!=='function'){continue}
if(typeof mutation.addedNodes[i].getElementsByClassName!=='function'){continue}
images=mutation.addedNodes[i].getElementsByTagName('img');is_image=mutation.addedNodes[i].tagName=="IMG";iframes=mutation.addedNodes[i].getElementsByTagName('iframe');is_iframe=mutation.addedNodes[i].tagName=="IFRAME";rocket_lazy=mutation.addedNodes[i].getElementsByClassName('rocket-lazyload');image_count+=images.length;iframe_count+=iframes.length;rocketlazy_count+=rocket_lazy.length;if(is_image){image_count+=1}
if(is_iframe){iframe_count+=1}}});if(image_count>0||iframe_count>0||rocketlazy_count>0){lazyLoadInstance.update()}});var b=document.getElementsByTagName("body")[0];var config={childList:!0,subtree:!0};observer.observe(b,config)}},!1)</script><script data-no-minify="1" async src="https://dxboffplan.com/wp-content/plugins/wp-rocket/assets/js/lazyload/17.8.3/lazyload.min.js"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"0cb296362640464bb670db249d48b03c","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"0cb296362640464bb670db249d48b03c","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>

</html>
<!-- This website is like a Rocket, isn't it? Performance optimized by WP Rocket. Learn more: https://wp-rocket.me - Debug: cached@1774703204 -->
